# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Lifecycle-safe one-shot launch of Companion onboarding screens."""
from __future__ import annotations

import os
import json
import logging
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import secrets

import bpy

from .. import manifest_version
from ..bake.companion_bundle import validate_bundle
from ..onboarding import SeenState, load_welcome, load_whats_new, version_key
from .addon_identity import addon_preferences

_START_DELAY_SECONDS = 1.25
LOG = logging.getLogger(__name__)
_stale_timers = globals().get("_stale_timers", []) + [
    callback for name in ("_startup_pulse", "_poll_startup")
    if callable(callback := globals().get(name))]
_pending = globals().get("_pending", [])


def _preferences():
    return addon_preferences(bpy.context, __package__)


def _state_path():
    try:
        root = bpy.utils.user_resource('CONFIG')
        return Path(root) / 'cloth_next' / 'onboarding-seen.json' if root else None
    except (AttributeError, TypeError):
        return None


def _merge_seen(a, b):
    versions = tuple(dict.fromkeys((*a.seen_versions, *b.seen_versions)))[-24:]
    highest = max((v for v in (a.highest_version,b.highest_version) if v),
                  key=version_key, default='')
    return SeenState(a.welcome_seen or b.welcome_seen, versions, highest)


def _state(preferences=None) -> SeenState:
    preferences = preferences or _preferences()
    value = SeenState.from_json(getattr(preferences, 'onboarding_state', ''))
    path = _state_path()
    if path is not None:
        try:
            value = _merge_seen(value, SeenState.from_json(path.read_text(encoding='utf-8')))
        except OSError:
            pass
    return value


def _write_state(value: SeenState, preferences=None) -> None:
    preferences = preferences or _preferences()
    value = _merge_seen(_state(preferences), value)
    preferences.onboarding_state = value.to_json()
    path = _state_path()
    if path is not None:
        temporary = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                    dir=path.parent, prefix='.onboarding-seen-', suffix='.tmp', delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(value.to_json())
            os.replace(temporary, path)
        except OSError as exc:
            LOG.warning('Could not persist Cloth NeXt onboarding state: %s', exc)
        finally:
            if temporary is not None: temporary.unlink(missing_ok=True)


def companion_info_command(mode: str, version: str | None = None, *,
                           splash_ms: int = 0,
                           show_after_updates: bool = True,
                           preference_path: Path | None = None,
                           preference_token: str | None = None,
                           account_root: Path | None = None,
                           open_account: bool = False,
                           superhive_connected: bool = False,
                           purchase_detected: bool = False) -> list[str]:
    extension_root = Path(__file__).resolve().parents[1]
    repository_root = extension_root.parent
    try:
        command = [str(validate_bundle(extension_root, manifest_version()))]
    except (OSError, ValueError, KeyError):
        if (os.environ.get("CLOTH_NEXT_DEVELOPER_COMPANION") != "1"
                or not (repository_root / "companion" / "app.py").is_file()):
            raise
        python = os.environ.get("CLOTH_NEXT_COMPANION_PYTHON", sys.executable)
        command = [python, "-m", "companion.app"]
    command += ["--mode", mode]
    command += ["--content-root", str(
        extension_root / "resources" / "onboarding")]
    if version is not None:
        command += ["--version", version]
    if splash_ms:
        command += ["--splash-ms", str(splash_ms)]
    command += ["--show-after-updates", "1" if show_after_updates else "0"]
    if preference_path is not None and preference_token is not None:
        command += ["--preference-path", str(preference_path),
                    f"--preference-token={preference_token}"]
    if account_root is not None:
        command += ['--account-root', str(account_root)]
    if open_account:
        command += ['--open-account']
    if superhive_connected:
        command += ['--superhive-connected']
    if purchase_detected:
        command += ['--purchase-detected']
    return command


def account_root():
    """Location handoff only. Account state is edited exclusively by Companion."""
    try:
        root = bpy.utils.user_resource('CONFIG')
        return Path(root)/'cloth_next'/'polyworks' if root else None
    except (AttributeError, TypeError):
        return None


def launch_screen(mode: str, *, manual: bool = False, open_account: bool = False) -> tuple[bool, str]:
    """Start one independent informational window; never block Blender."""
    version = manifest_version()
    temporary = None
    try:
        if mode == "welcome":
            load_welcome()
        elif mode == "whats-new":
            load_whats_new(version)
        else:
            raise ValueError(f"unknown Companion screen: {mode}")
        temporary = tempfile.TemporaryDirectory(prefix="clothnext-onboarding-")
        ready = Path(temporary.name) / "ready"
        preference = Path(temporary.name) / "preference.json"
        token = secrets.token_hex(16)
        preferences = _preferences()
        from ..superhive_status import repository_status
        repos = getattr(getattr(bpy.context.preferences, 'extensions', None), 'repos', ())
        superhive = repository_status(repos)
        show_after_updates = bool(getattr(
            preferences, "show_whats_new_after_updates", True))
        command = companion_info_command(
            mode, version, splash_ms=2000,
            show_after_updates=show_after_updates,
            preference_path=preference, preference_token=token,
            account_root=account_root(), open_account=open_account,
            superhive_connected=superhive.connected,
            purchase_detected=superhive.purchase_detected)
        env = dict(os.environ, CLOTH_NEXT_INFO_READY_PATH=str(ready),
                   CLOTH_NEXT_INFO_READY_TOKEN=token)
        process = subprocess.Popen(
            command, cwd=Path(__file__).resolve().parents[2], shell=False, env=env)
    except (OSError, ValueError, KeyError) as exc:
        if temporary is not None:
            temporary.cleanup()
        return False, f"Could not open Cloth NeXt {mode}: {exc}"
    if process.poll() is not None:
        temporary.cleanup()
        return False, f"Cloth NeXt {mode} exited during startup."
    _pending.append((process, temporary, ready, token, mode, version, manual,
                     time.monotonic() + 20, preference, False))
    if not bpy.app.timers.is_registered(_poll_startup):
        bpy.app.timers.register(_poll_startup, first_interval=0.1, persistent=True)
    return True, "Welcome opened" if mode == "welcome" else "What's New opened"


def _poll_startup():
    for item in tuple(_pending):
        (process, temporary, ready, token, mode, version, manual, deadline,
         preference, acknowledged_before) = item
        try:
            payload = json.loads(preference.read_text(encoding="utf-8"))
            if payload.get("token") == token and isinstance(
                    payload.get("show_after_updates"), bool):
                _preferences().show_whats_new_after_updates = payload[
                    "show_after_updates"]
                preference.unlink(missing_ok=True)
        except (OSError, ValueError, AttributeError):
            pass
        try:
            acknowledged = ready.is_file() and ready.read_text(encoding="utf-8") == token
        except OSError:
            acknowledged = False
        if acknowledged and not acknowledged_before:
            if not manual:
                preferences = _preferences()
                _write_state(_state(preferences).mark_seen(mode, version), preferences)
            replacement = (*item[:-1], True)
            _pending[_pending.index(item)] = replacement
            item = replacement
        exited = process.poll() is not None
        timed_out = not acknowledged and time.monotonic() >= deadline
        if exited or timed_out:
            try:
                if timed_out and not exited:
                    process.terminate()
                    process.wait(timeout=2)
            finally:
                temporary.cleanup()
                _pending.remove(item)
    return 0.1 if _pending else None


def _startup_pulse() -> None:
    """One-shot callback holding no Blender context or RNA references."""
    if getattr(bpy.app, "background", False) or _pending:
        return None
    try:
        screen = _state().next_screen(manifest_version())
        if (screen == "whats-new" and not getattr(
                _preferences(), "show_whats_new_after_updates", True)):
            _write_state(_state().mark_seen(screen, manifest_version()))
            return None
        if screen:
            ok, message = launch_screen(screen)
            if not ok:
                LOG.warning("Cloth NeXt onboarding launch skipped: %s", message)
    except (KeyError, AttributeError, OSError, ValueError) as exc:
        # Onboarding is optional at runtime; an invalid/missing Companion must
        # never prevent Blender or the add-on from starting.
        LOG.warning("Cloth NeXt onboarding is unavailable: %s", exc)
    return None


def register() -> None:
    for callback in _stale_timers:
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _stale_timers.clear()
    if _pending and not bpy.app.timers.is_registered(_poll_startup):
        bpy.app.timers.register(_poll_startup, first_interval=0.1, persistent=True)
    if not getattr(bpy.app, "background", False) and not bpy.app.timers.is_registered(
            _startup_pulse):
        bpy.app.timers.register(_startup_pulse, first_interval=_START_DELAY_SECONDS)


def unregister() -> None:
    for callback in (*_stale_timers, _startup_pulse, _poll_startup):
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _stale_timers.clear()
    for item in tuple(_pending):
        process, temporary = item[:2]
        try:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=2)
        finally:
            temporary.cleanup()
            _pending.remove(item)


class CLOTHNEXT_OT_open_welcome(bpy.types.Operator):
    bl_idname = "clothnext.open_welcome"
    bl_label = "Open Welcome"
    bl_description = "Open the Cloth NeXt getting-started screen"
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        ok, message = launch_screen("welcome", manual=True)
        self.report({"INFO" if ok else "ERROR"}, message)
        return {"FINISHED" if ok else "CANCELLED"}


class CLOTHNEXT_OT_open_whats_new(bpy.types.Operator):
    bl_idname = "clothnext.open_whats_new"
    bl_label = "What's New"
    bl_description = "Open What's New for this installed Cloth NeXt version"
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        ok, message = launch_screen("whats-new", manual=True)
        self.report({"INFO" if ok else "ERROR"}, message)
        return {"FINISHED" if ok else "CANCELLED"}


CLASSES = (CLOTHNEXT_OT_open_welcome, CLOTHNEXT_OT_open_whats_new)
