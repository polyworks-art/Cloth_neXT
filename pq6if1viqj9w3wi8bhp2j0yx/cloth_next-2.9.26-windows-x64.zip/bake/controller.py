# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Thread-safe state authority for panels, HUD, preview and companion IPC."""

from __future__ import annotations

from collections.abc import Callable
from threading import RLock
import time
import uuid

from .status import BakeSnapshot, BakeState, normalized
from ..core.error_codes import classify_error, valid_error_code
from ..veyra.model import CompanionMode


class InvalidTransition(ValueError):
    pass


_NEXT = {
    BakeState.IDLE: {BakeState.PREPARING},
    BakeState.PREPARING: {BakeState.STARTING_COMPANION, BakeState.STARTING_RUN,
                          BakeState.PREPARING_WATER, BakeState.EXPORTING, BakeState.CANCELLING, BakeState.ERROR},
    BakeState.PREPARING_WATER: {BakeState.PREPARING, BakeState.FINISHED,
                               BakeState.CANCELLING, BakeState.ERROR},
    BakeState.STARTING_COMPANION: {BakeState.WAITING_FOR_COMPANION,
                                   BakeState.CANCELLING, BakeState.ERROR},
    BakeState.WAITING_FOR_COMPANION: {BakeState.COMPANION_READY,
                                      BakeState.CANCELLING, BakeState.ERROR},
    BakeState.COMPANION_READY: {BakeState.STARTING_RUN, BakeState.CANCELLING,
                                BakeState.ERROR},
    BakeState.STARTING_RUN: {BakeState.EXPORTING, BakeState.FINISHED,
                             BakeState.PREPARING_WATER, BakeState.CANCELLING, BakeState.ERROR},
    BakeState.EXPORTING: {BakeState.STARTING_SOLVER, BakeState.CANCELLING, BakeState.ERROR},
    # STARTING_SOLVER -> SIMULATING stays for the display-only UI preview;
    # the real run goes through UPLOADING and BUILDING.
    BakeState.STARTING_SOLVER: {BakeState.UPLOADING, BakeState.SIMULATING,
                                BakeState.CANCELLING, BakeState.ERROR},
    BakeState.UPLOADING: {BakeState.BUILDING, BakeState.CANCELLING, BakeState.ERROR},
    BakeState.BUILDING: {BakeState.IDLE, BakeState.FINISHED,
                         BakeState.SIMULATING, BakeState.FETCHING,
                         BakeState.CANCELLING, BakeState.ERROR},
    # Simulation and incremental frame download interleave.
    BakeState.SIMULATING: {BakeState.FETCHING, BakeState.IMPORTING,
                           BakeState.CANCELLING, BakeState.ERROR},
    BakeState.FETCHING: {BakeState.SIMULATING, BakeState.IMPORTING,
                         BakeState.CANCELLING, BakeState.ERROR},
    BakeState.IMPORTING: {BakeState.FINISHED, BakeState.CANCELLING, BakeState.ERROR},
    BakeState.CANCELLING: {BakeState.CANCELLED, BakeState.ERROR},
    BakeState.FINISHED: {BakeState.IDLE, BakeState.PREPARING},
    BakeState.CANCELLED: {BakeState.IDLE, BakeState.PREPARING},
    BakeState.ERROR: {BakeState.IDLE, BakeState.PREPARING},
}

_ERROR_STAGE = {
    BakeState.PREPARING_WATER: ("Water Flow preparation", "Check the FLIP velocity bake and output folder, then retry."),
    BakeState.PREPARING: ("scene validation", "Correct the highlighted Cloth NeXt scene setting, then retry."),
    BakeState.STARTING_COMPANION: ("Bake window startup", "Restart the Bake window or Blender, then retry."),
    BakeState.WAITING_FOR_COMPANION: ("Bake window handshake", "Close stale Bake windows and retry."),
    BakeState.COMPANION_READY: ("Bake workflow startup", "Retry the Bake; if it repeats, inspect the diagnostic log."),
    BakeState.STARTING_RUN: ("Bake worker startup", "Check cache-folder access and retry."),
    BakeState.EXPORTING: ("scene export", "Check evaluated Cloth and Collider geometry, then retry."),
    BakeState.STARTING_SOLVER: ("solver startup", "Check the installed solver and its diagnostic log, then retry."),
    BakeState.UPLOADING: ("scene upload", "Check the local solver connection and retry."),
    BakeState.BUILDING: ("solver project build", "Check scene geometry and the solver log, then retry."),
    BakeState.SIMULATING: ("simulation", "Inspect the reported frame and solver cause, adjust stability settings, then retry."),
    BakeState.FETCHING: ("result transfer", "Check the solver connection and available disk space, then retry."),
    BakeState.IMPORTING: ("playback cache import", "Check the cache path and Cloth object, then retry."),
    BakeState.CANCELLING: ("cancellation cleanup", "Wait for cleanup; restart Blender only if the process remains stuck."),
}

class BakeController:
    def __init__(self) -> None:
        self._lock = RLock()
        self._snapshot = BakeSnapshot(updated_at=time.time())
        self._listeners: set[Callable[[BakeSnapshot], None]] = set()

    def snapshot(self) -> BakeSnapshot:
        with self._lock:
            return self._snapshot

    def transition(self, state: BakeState, **changes) -> BakeSnapshot:
        with self._lock:
            old = self._snapshot
            if state != old.state and state not in _NEXT[old.state]:
                raise InvalidTransition(f"{old.state.value} -> {state.value}")
            # Create/reset attempt identity only when entering PREPARING.
            # Status/progress updates use the same state; regenerating the id
            # there makes the scheduled Collider capture look stale.
            if state is BakeState.PREPARING and old.state is not BakeState.PREPARING:
                changes.setdefault("job_id", uuid.uuid4().hex)
                changes.setdefault("elapsed_seconds", 0.0)
                changes.setdefault("estimated_remaining_seconds", None)
                changes.setdefault("progress_current", 0)
                changes.setdefault("progress_total", None)
                changes.setdefault("preparation_current", 0)
                changes.setdefault("preparation_total", None)
                changes.setdefault("current_frame", None)
                changes.setdefault("frame_start", None)
                changes.setdefault("frame_end", None)
                changes.setdefault("active_object_name", "")
                changes.setdefault("error_summary", "")
                changes.setdefault("error_details", "")
                changes.setdefault("error_code", "")
                changes.setdefault("solver_mode", "")
                changes.setdefault("solver_version", "")
                changes.setdefault("solver_process_id", None)
                changes.setdefault("solver_name", "")
                changes.setdefault("solver_backend", "")
                changes.setdefault("solver_device", "")
                changes.setdefault("solver_telemetry", {})
                changes.setdefault("activity_label", "")
                changes.setdefault("activity_detail", "")
                changes.setdefault("can_pause", False)
                changes.setdefault("is_paused", False)
                changes.setdefault(
                    "companion_mode",
                    (CompanionMode.VEYRA if changes.get("job_kind") is not None
                     and getattr(changes["job_kind"], "value", "") == "VEYRA"
                     else CompanionMode.BAKE))
                changes.setdefault("veyra_step", None)
                changes.setdefault("veyra_step_index", 0)
                changes.setdefault("veyra_step_current", 0)
                changes.setdefault("veyra_step_total", None)
            if (state != old.state or changes.get("activity_code", old.activity_code)
                    != old.activity_code):
                changes.setdefault("activity_label", "")
            self._snapshot = normalized(old, state=state, **changes)
            listeners = tuple(self._listeners)
            result = self._snapshot
        for listener in listeners:
            listener(result)
        return result

    def continue_veyra_validation(self, **changes) -> BakeSnapshot:
        """Re-enter export inside one active VEYRA BUILD-only session.

        This deliberately is not a general BUILDING -> EXPORTING transition:
        only the same live VEYRA job may use the iterative validation loop.
        """
        with self._lock:
            old = self._snapshot
            if (old.state is not BakeState.BUILDING
                    or old.companion_mode is not CompanionMode.VEYRA
                    or not old.job_id):
                raise InvalidTransition(
                    "Only an active VEYRA BUILDING job can continue validation")
            changes.setdefault("job_id", old.job_id)
            changes.setdefault("companion_mode", CompanionMode.VEYRA)
            changes.setdefault("error_summary", "")
            changes.setdefault("error_details", "")
            changes.setdefault("error_code", "")
            self._snapshot = normalized(
                old, state=BakeState.EXPORTING, **changes)
            listeners = tuple(self._listeners)
            result = self._snapshot
        for listener in listeners:
            listener(result)
        return result

    def update(self, **changes) -> BakeSnapshot:
        return self.transition(self.snapshot().state, **changes)

    def request_cancel(self) -> BakeSnapshot:
        return self.transition(BakeState.CANCELLING,
                               status_message="Cancellation requested")

    def fail(self, summary: str, details: str = "", *,
             error_code: str = "") -> BakeSnapshot:
        current = self.snapshot()
        stage, action = _ERROR_STAGE.get(
            current.state, ("internal operation", "Open the diagnostic log and retry."))
        lines = [] if not details else [details]
        if "Stage:" not in details:
            lines.insert(0, f"Stage: {stage}")
        if "What to do:" not in details and "Recommended:" not in details:
            lines.append(f"What to do: {action}")
        code = (error_code if valid_error_code(error_code)
                else classify_error(current.state, summary, details))
        return self.transition(
            BakeState.ERROR, error_summary=summary,
            error_details="\n".join(lines), status_message=summary,
            error_code=code,
            estimated_remaining_seconds=None,
            activity_detail=stage)

    def reset(self) -> BakeSnapshot:
        state = self.snapshot().state
        if state is BakeState.IDLE:
            return self.snapshot()
        return self.transition(BakeState.IDLE, progress_current=0,
                               progress_total=None, preview=False,
                               status_message="Ready", job_id="",
                               error_code="",
                               estimated_remaining_seconds=None)

    def subscribe(self, listener: Callable[[BakeSnapshot], None]) -> Callable[[], None]:
        with self._lock:
            self._listeners.add(listener)
        return lambda: self._listeners.discard(listener)


shared_controller = BakeController()
