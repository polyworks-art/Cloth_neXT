# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Add-on preferences: the "PPF Contact Solver" section and its operators.

The panel only renders what the pure ``updater.view_model`` module computes.
Downloads never start automatically — not on enable, file open, simulation
start, Blender start, or in the background. Every download begins with the
explicit confirmation dialog of ``CLOTHNEXT_OT_solver_download``. Blocking
work runs in a worker thread; only this module touches ``bpy``.
"""

from __future__ import annotations

import threading
import webbrowser
from dataclasses import replace
from pathlib import Path

import bpy

from ..developer import is_dev_build
from ..superhive_status import repository_status

from ..ppf.compatibility import parse_executable_version
from ..ppf.layout import BundledSolverLayout
from ..ppf.solver_overlay import apply_solver_overlay
from ..updater import addon_updates, view_model
from . import addon_update_operators, icon_registry, viewport_colors
from .addon_identity import addon_preferences, package_addon_id
from ..updater.install_paths import ManagedSolverPaths, read_current
from ..updater.managed import ManagedSolverInstaller
from ..updater.modes import InstallationMode
from ..updater.solver_manifest import (SolverCompatibilityEntry,
                                                load_bundled_manifest)
from ..updater.states import InstallerAction, InstallerState
from ..updater.update_check import solver_update_available
from ..updater.solver_registry import (
    SolverInstallation, SolverRegistry, external_installation_id, load_registry,
    migrate_legacy_current, write_registry)
from ..platform_support import platform_spec

_ADDON_ID = package_addon_id(__package__)
_PLATFORM = platform_spec().solver_platform


class _SolverSession:
    """Session-scoped installer state; never populated at import time."""

    def __init__(self) -> None:
        self.entry: SolverCompatibilityEntry | None = None
        self.entries: tuple[SolverCompatibilityEntry, ...] = ()
        self.target_entry: SolverCompatibilityEntry | None = None
        self.activate_after_install = False
        self.reinstall = False
        self.disabled_reason: str | None = None
        self.installer: ManagedSolverInstaller | None = None
        self.worker: threading.Thread | None = None
        self.worker_status: str | None = None
        self.worker_error: str | None = None
        self.loaded = False

    def load(self) -> None:
        if self.loaded:
            return
        self.loaded = True
        try:
            manifest = load_bundled_manifest()
            self.entry = manifest.entry_for(_PLATFORM)
            self.entries = manifest.releases_for(_PLATFORM)
            if self.entry is None:
                self.disabled_reason = f"no verified release for {_PLATFORM}"
        except (OSError, ValueError) as exc:
            self.entry = None
            self.disabled_reason = str(exc)

    def ensure_installer(self, release_id: str = "") -> ManagedSolverInstaller | None:
        self.load()
        entry = (next((item for item in self.entries
                       if item.release_id == release_id), None)
                 if release_id else self.entry)
        if entry is None or not entry.downloadable:
            return None
        if self.installer is None or self.installer.entry != entry:
            extension_root = Path(__file__).resolve().parents[1]
            self.installer = ManagedSolverInstaller(
                ManagedSolverPaths.default(), entry,
                probe_version=_probe_version, health_check=_health_check,
                forbidden_roots=(extension_root,),
                apply_overlay=apply_solver_overlay)
        self.target_entry = entry
        return self.installer


_session = _SolverSession()


def _probe_version(executable: Path) -> tuple[str, str, str]:
    import subprocess
    completed = subprocess.run([str(executable), "--version"], capture_output=True,
                               text=True, timeout=60, check=True, shell=False)
    return parse_executable_version(completed.stdout + completed.stderr)


def _health_check(executable: Path) -> bool:
    """Real health check: start the server, verify readiness plus status, stop it."""
    from ..updater.health_runner import run_real_health_check
    return run_real_health_check(executable)


def _safe_read_current():
    """Tampered current.json is treated as a repair case, never trusted."""
    try:
        return read_current(ManagedSolverPaths.default()), True
    except ValueError:
        return None, False


def _read_registry() -> tuple[SolverRegistry, str | None]:
    try:
        registry = load_registry(ManagedSolverPaths.default().registry_json)
        supported = tuple(
            installation for installation in registry.installations
            if installation.compatible)
        selected = registry.selected_installation_id
        if not any(item.installation_id == selected for item in supported):
            selected = None
        return SolverRegistry(supported, selected), None
    except ValueError as exc:
        return SolverRegistry(), str(exc)


def _solver_session_active() -> bool:
    try:
        from ..bake.controller import shared_controller
        return bool(shared_controller.snapshot().active)
    except (ImportError, AttributeError):
        return False


_ENGINE_ITEMS: list = []


def _engine_items(_self, _context):
    """AETHER always; GAIA once a GAIA build is installed or access is known;
    Legacy (the upstream PPF solver) always, installed or not.

    Visibility is only a convenience: the server and the installed build's
    identity decide whether GAIA can actually be installed or run.
    """
    from ..updater import engines
    registry, _error = _read_registry()
    show_gaia = bool(engines.installations_for(registry, engines.GAIA)
                     or _gaia_access_granted())
    _ENGINE_ITEMS[:] = [(engines.AETHER, "AETHER", engines.ENGINE_DESCRIPTIONS[engines.AETHER], 0)]
    if show_gaia:
        _ENGINE_ITEMS.append((engines.GAIA, "GAIA", engines.ENGINE_DESCRIPTIONS[engines.GAIA], 1))
    # always listed (Tim, 2.9.65); choosing it without a build says to install it below
    _ENGINE_ITEMS.append((engines.LEGACY, engines.LEGACY_LABEL,
                          engines.ENGINE_DESCRIPTIONS[engines.LEGACY], 2))
    return _ENGINE_ITEMS


def _gaia_access_granted() -> bool:
    try:
        from . import gaia_account
    except ImportError:
        return False
    return gaia_account.access_granted()


def _engine_get(self) -> int:
    """GAIA only while a GAIA build is selected and AETHER was not chosen since;
    Legacy only when the artist chose it and its PPF build is selected.

    AETHER is the native AETHER Engine (testing builds: it replaces the
    upstream PPF build that used this name). Existing GAIA selections stay GAIA."""
    from ..updater import engines
    if bool(getattr(self, "aether_engine_chosen", False)):
        return 0
    registry, _error = _read_registry()
    selected = engines.selected_engine(registry)
    if selected == engines.GAIA:
        return 1
    if bool(getattr(self, "legacy_engine_chosen", False)) and selected == engines.AETHER:
        return 2
    return 0


def _engine_set(self, value: int) -> None:
    """Switch engine only by explicit choice, to that engine's best healthy build."""
    from ..updater import engines
    if _solver_session_active():
        _session.worker_error = "The solver engine cannot change while a Bake is active."
        return
    if value == 0:
        # The native AETHER Engine ships with Cloth NeXt: no installation to select.
        self.aether_engine_chosen = True
        self.legacy_engine_chosen = False
        _session.worker_error = None
        return
    # GAIA, or Legacy: the upstream PPF builds (internal engine id AETHER)
    engine = engines.GAIA if value == 1 else engines.AETHER
    legacy = value == 2
    registry, error = _read_registry()
    if error:
        _session.worker_error = error
        return
    if engines.selected_engine(registry) == engine:
        self.aether_engine_chosen = False
        self.legacy_engine_chosen = legacy
        return
    if _solver_session_active():
        _session.worker_error = "The solver engine cannot change while a Bake is active."
        return
    target = engines.best_installation(registry, engine)
    if target is None:
        name = engines.LEGACY_LABEL if legacy else engine
        _session.worker_error = (
            f"{name} is not installed. Install {name} below; the current engine stays selected.")
        return
    try:
        write_registry(ManagedSolverPaths.default().registry_json,
                       registry.select(target.installation_id))
    except (OSError, ValueError) as exc:
        _session.worker_error = f"Engine change failed: {exc}"
        return
    self.selected_solver_installation_id = target.installation_id
    self.aether_engine_chosen = False
    self.legacy_engine_chosen = legacy
    _session.worker_error = None


# Blender keeps only C pointers to the strings of dynamic EnumProperty items; a
# list built fresh in the callback is freed on return and the menu shows garbled
# or empty labels. Both item callbacks therefore fill module-level lists.
_SOLVER_ITEMS: list = []


def _solver_enum_items(_self, _context):
    from ..updater import engines
    registry, _error = _read_registry()
    engine = engines.selected_engine(registry)
    items = []
    for index, installation in enumerate(registry.installations):
        if engine is not None and engines.engine_of(installation) != engine:
            continue
        status = (
            f"Protocol {installation.protocol_version or '?'} · "
            f"Schema {installation.schema_version or '?'} · "
            f"{'Managed' if installation.managed else 'External'}")
        items.append((
            installation.installation_id,
            installation.display_name,
            status,
            "CHECKMARK" if installation.healthy else "ERROR",
            index))
    if not items:
        items.append(("NONE", "No Solver Selected",
                      "Install or register a compatible solver", "ERROR", 0))
    _SOLVER_ITEMS[:] = items
    return _SOLVER_ITEMS


def _solver_enum_update(self, _context):
    selected = str(getattr(self, "selected_solver_installation_id", "") or "")
    if selected == "NONE" or _solver_session_active():
        return
    paths = ManagedSolverPaths.default()
    registry, error = _read_registry()
    if error or registry.get(selected) is None:
        _session.worker_error = error or "The selected solver installation is missing. Refresh Installations, then retry."
        return
    try:
        write_registry(paths.registry_json, registry.select(selected))
    except (OSError, ValueError) as exc:
        installation = registry.get(selected)
        _session.worker_error = (
            f"Solver selection failed: {exc}. {installation.error or ''}".strip())
        return
    _session.worker_error = None


class CLOTHNEXT_OT_solver_use(bpy.types.Operator):
    """Use this healthy compatible installation for future solver work"""
    bl_idname = "clothnext.solver_use"
    bl_label = "Use"
    bl_description = (
        "Make this verified installation the active solver for new Bakes, "
        "tests, updates and compatible recovery")
    bl_options = {"INTERNAL"}

    installation_id: bpy.props.StringProperty()

    @classmethod
    def poll(cls, _context):
        return not _solver_session_active()

    def execute(self, context):
        paths = ManagedSolverPaths.default()
        registry, error = _read_registry()
        if error:
            self.report({"ERROR"}, error)
            return {"CANCELLED"}
        try:
            registry = registry.select(self.installation_id)
            write_registry(paths.registry_json, registry)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        addon_preferences(
            context, __package__).selected_solver_installation_id = self.installation_id
        self.report({"INFO"}, "Active solver installation changed.")
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_refresh_installations(bpy.types.Operator):
    """Refresh registrations without deleting retired solver installations."""
    bl_idname = "clothnext.solver_refresh_installations"
    bl_label = "Refresh Installations"
    bl_description = (
        "Refresh installation paths and verify the legacy managed solver "
        "registry without downloading or changing the active solver")
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        def refresh():
            manifest = load_bundled_manifest()
            migrate_legacy_current(
                ManagedSolverPaths.default(), manifest,
                probe_version=_probe_version, health_check=_health_check)
        _run_in_worker(refresh, status="Refreshing solver installations")
        self.report({"INFO"}, "Refreshing solver installations in the background.")
        return {"FINISHED"}


def _installer_state() -> InstallerState:
    """Local session state; never touches the network or starts anything.

    An older or legacy managed installation is reported as UPDATE_AVAILABLE
    immediately — comparing ``current.json`` with the bundled compatibility
    manifest needs no GitHub request, no solver process, and no thread.
    """
    installer = _session.installer
    if installer is not None:
        return installer.state
    active, valid = _safe_read_current()
    if not valid:
        return InstallerState.REPAIR_REQUIRED
    if active is not None:
        if solver_update_available(active, _session.entry):
            return InstallerState.UPDATE_AVAILABLE
        return InstallerState.READY
    return InstallerState.NOT_INSTALLED


def _installed_info() -> view_model.InstalledInfo | None:
    _session.load()
    active, _valid = _safe_read_current()
    if active is None or _session.entry is None:
        return None
    return view_model.InstalledInfo(
        InstallationMode.MANAGED_INSTALLATION,
        active.version, _session.entry.protocol_version,
        _session.entry.schema_version, release_label=active.release_label)


def _tag_redraw_preferences() -> None:
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type == "PREFERENCES":
                area.tag_redraw()


def _ui_refresh_pulse() -> float | None:
    """Timer callback: redraw preferences while the installer worker runs."""
    worker = _session.worker
    _tag_redraw_preferences()
    solver_active = bool(worker is not None and worker.is_alive())
    if not solver_active:
        registry, _error = _read_registry()
        selected = registry.selected_installation_id
        if selected:
            try:
                preferences = addon_preferences(bpy.context, __package__)
                preferences.selected_solver_installation_id = selected
            except (KeyError, AttributeError):
                pass
        return None
    return 0.25


def _run_in_worker(target, *, status: str | None = None) -> None:
    if _session.worker is not None and _session.worker.is_alive():
        return
    _session.worker_status = status
    _session.worker_error = None

    def guarded_target():
        try:
            target()
        except (OSError, ValueError, RuntimeError) as exc:
            _session.worker_error = str(exc)
        finally:
            _session.worker_status = None

    _session.worker = threading.Thread(target=guarded_target, daemon=True,
                                       name="clothnext-solver-installer")
    _session.worker.start()
    if not bpy.app.timers.is_registered(_ui_refresh_pulse):
        bpy.app.timers.register(_ui_refresh_pulse, first_interval=0.25)


def shutdown(join_timeout: float = 10.0) -> bool:
    """Cancel installer work without forgetting a worker still winding down."""
    installer = _session.installer
    if installer is not None:
        installer.cancel()
    worker = _session.worker
    if worker is not None and worker.is_alive():
        worker.join(timeout=max(0.0, float(join_timeout)))
    stopped = worker is None or not worker.is_alive()
    if bpy.app.timers.is_registered(_ui_refresh_pulse):
        bpy.app.timers.unregister(_ui_refresh_pulse)
    if not stopped:
        return False
    _session.worker = None
    _session.installer = None
    _session.entry = None
    _session.entries = ()
    _session.target_entry = None
    _session.worker_status = None
    _session.worker_error = None
    _session.disabled_reason = None
    _session.loaded = False
    return True


class _SolverInstallDialog:
    """Shared confirmation-dialog behavior for download and repair.

    Deliberately a plain mixin, NOT a registered Operator subclass:
    registering a subclass of an already registered Operator corrupts
    Blender's RNA↔Python class mapping, after which the parent operator's
    ``invoke`` is silently skipped and its button appears to do nothing.
    """

    def _report_online_access_blocked(self) -> bool:
        if getattr(bpy.app, "online_access", True):
            return False
        self.report({"ERROR"}, "Blender's online access is disabled. Enable "
                    "'Allow Online Access' in Preferences > System to download "
                    "the solver.")
        return True

    def draw(self, _context):
        layout = self.layout
        entry = _session.target_entry or _session.entry
        if entry is None:
            return
        for line in view_model.confirmation_lines(entry, ManagedSolverPaths.default()):
            layout.label(text=line)
        row = layout.row()
        row.operator("clothnext.solver_open_download_page", text="View Official Source")
        row.operator("clothnext.solver_view_licenses", text="View License Information")
        layout.label(text="Click OK to download and install; press Esc to cancel.")

    def execute(self, _context):
        # Keep using the release selected by invoke(). Calling the default
        # installer here would replace the explicitly confirmed release with
        # the manifest default and lose the confirmation state.
        release_id = str(getattr(self, "release_id", "") or "")
        if (_session.target_entry is None
                or _session.target_entry.release_id != release_id):
            self.report({"ERROR"}, "The confirmed solver release changed; retry the download.")
            return {"CANCELLED"}
        installer = _session.ensure_installer(release_id)
        if installer is None:
            return {"CANCELLED"}
        if installer.state is not InstallerState.AWAITING_CONFIRMATION:
            # Never crash the worker with an invalid transition; tell the user.
            self.report({"WARNING"}, "The download was not confirmed; "
                        "nothing was started.")
            return {"CANCELLED"}
        activate = _session.activate_after_install
        _run_in_worker(lambda: installer.install(
            confirmed=True, activate=activate, reinstall=_session.reinstall),
            status="Installing solver release")
        self.report({"INFO"}, "Downloading the official solver in the background.")
        return {"FINISHED"}

    def cancel(self, _context):
        installer = _session.installer
        if installer is not None and installer.state is InstallerState.AWAITING_CONFIRMATION:
            installer.install(confirmed=False)


class CLOTHNEXT_OT_solver_download(_SolverInstallDialog, bpy.types.Operator):
    """Download the compatible simulation solver after explicit confirmation"""
    bl_idname = "clothnext.solver_download"
    bl_label = "Download Official Solver"
    bl_options = {"REGISTER", "INTERNAL"}
    bl_description = (
        "Download and verify this exact official solver release without "
        "overwriting any other installed release")

    release_id: bpy.props.StringProperty(default="")
    activate_after_install: bpy.props.BoolProperty(default=False)
    reinstall: bpy.props.BoolProperty(default=False)

    def invoke(self, context, _event):
        if _solver_session_active():
            self.report({"ERROR"},
                        "Stop the active Bake before installing another solver.")
            return {"CANCELLED"}
        if self._report_online_access_blocked():
            return {"CANCELLED"}
        installer = _session.ensure_installer(self.release_id)
        if installer is None:
            self.report({"ERROR"}, "Automatic download is disabled: "
                        f"{_session.disabled_reason}")
            return {"CANCELLED"}
        if _session.worker is not None and _session.worker.is_alive():
            self.report({"INFO"}, "A solver installation is already running.")
            return {"CANCELLED"}
        installer.request_download()
        _session.activate_after_install = self.activate_after_install
        _session.reinstall = self.reinstall
        return context.window_manager.invoke_props_dialog(self, width=520)


class CLOTHNEXT_OT_solver_cancel(bpy.types.Operator):
    """Cancel the running solver download"""
    bl_idname = "clothnext.solver_cancel"
    bl_label = "Cancel Download"
    bl_description = (
        "Cancel the current solver download; no partial installation is "
        "registered and existing installations remain untouched")
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        if _session.installer is not None:
            _session.installer.cancel()
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_select_existing(bpy.types.Operator):
    """Select an existing external solver installation (never modified)"""
    bl_idname = "clothnext.solver_select_existing"
    bl_label = "Select Existing Installation"
    bl_description = (
        "Register an existing solver executable without copying, deleting or "
        "modifying its external files")
    bl_options = {"INTERNAL"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def invoke(self, context, _event):
        if _solver_session_active():
            self.report({"ERROR"},
                        "Stop the active Bake before registering another solver.")
            return {"CANCELLED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, _context):
        from ..updater.external import validate_external_installation
        _session.load()
        if not _session.entries:
            self.report({"ERROR"}, "No compatibility manifest entry is available.")
            return {"CANCELLED"}
        selected_path = Path(str(self.filepath))

        def register_external():
            package, protocol, schema = _probe_version(
                selected_path if selected_path.is_file()
                else BundledSolverLayout.from_root(
                    selected_path).executable_path)
            matching = next((entry for entry in _session.entries
                             if entry.protocol_version == protocol
                             and entry.schema_version == schema), None)
            if matching is None:
                raise ValueError(
                    f"unsupported protocol {protocol} / schema {schema}")
            result = validate_external_installation(
                selected_path, _probe_version, matching)
            if not result.compatible:
                raise ValueError(
                    f"unsupported protocol {result.protocol_version} / "
                    f"schema {result.schema_version}")
            healthy = _health_check(result.executable)
            paths = ManagedSolverPaths.default()
            registry = load_registry(paths.registry_json)
            existing = registry.find_executable(result.executable)
            if existing is not None:
                return
            installation = SolverInstallation(
                installation_id=external_installation_id(),
                display_name=f"Custom solver {result.package_version}",
                source="external", root_path=str(result.root),
                executable_path=str(result.executable),
                frontend_path=str(result.root / "frontend"),
                package_version=result.package_version,
                protocol_version=result.protocol_version,
                schema_version=result.schema_version,
                official_release_tag=None,
                managed=False, verified=True, healthy=healthy,
                channel=("current" if healthy else "unsupported"),
                error=None if healthy else "Real solver health check failed")
            write_registry(paths.registry_json, registry.register(installation))

        _run_in_worker(register_external,
                       status="Testing and registering external solver")
        self.report({"INFO"}, "Testing the external solver in the background.")
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_open_download_page(bpy.types.Operator):
    """Open the official upstream solver release page"""
    bl_idname = "clothnext.solver_open_download_page"
    bl_label = "Open Official Download Page"
    bl_description = "Open the immutable official release page for this solver"
    bl_options = {"INTERNAL"}
    release_id: bpy.props.StringProperty(default="")

    def execute(self, _context):
        _session.load()
        entry = next((item for item in _session.entries
                      if item.release_id == self.release_id), _session.entry)
        url = (entry.official_release_page if entry
               else "https://github.com/st-tech/ppf-contact-solver/releases")
        webbrowser.open(url)
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_view_licenses(bpy.types.Operator):
    """Open the upstream license information"""
    bl_idname = "clothnext.solver_view_licenses"
    bl_label = "View License Information"
    bl_description = "Open the official upstream solver license information"
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        webbrowser.open("https://github.com/st-tech/ppf-contact-solver/blob/main/LICENSE")
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_health_check(bpy.types.Operator):
    """Run the real health check against the active installation"""
    bl_idname = "clothnext.solver_health_check"
    bl_label = "Run Health Check"
    bl_description = (
        "Start this installation briefly and verify its executable, protocol, "
        "schema and status response")
    bl_options = {"INTERNAL"}
    installation_id: bpy.props.StringProperty(default="")

    def execute(self, _context):
        registry, error = _read_registry()
        installation = registry.get(
            self.installation_id or registry.selected_installation_id)
        if error or installation is None:
            self.report({"ERROR"}, error or "The installation is not registered.")
            return {"CANCELLED"}
        def test_and_store():
            healthy = _health_check(installation.executable)
            paths = ManagedSolverPaths.default()
            current = load_registry(paths.registry_json)
            latest = current.get(installation.installation_id)
            if latest is None:
                raise ValueError("The installation was removed during its health check.")
            updated = replace(
                latest, healthy=healthy,
                error=None if healthy else "Real solver health check failed")
            write_registry(paths.registry_json, current.update(updated))

        _run_in_worker(test_and_store, status="Testing solver installation")
        self.report({"INFO"}, "Health check started in the background.")
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_check_update(bpy.types.Operator):
    """Check whether a manifest-verified compatible update exists"""
    bl_idname = "clothnext.solver_check_update"
    bl_label = "Check for Compatible Update"
    bl_description = (
        "Refresh the official release availability without changing the "
        "active solver installation")
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        installer = _session.ensure_installer()
        if installer is None:
            self.report({"ERROR"}, "No compatibility manifest entry is available.")
            return {"CANCELLED"}
        state = installer.check_for_update()
        self.report({"INFO"},
                    "A compatible update is available."
                    if state is InstallerState.UPDATE_AVAILABLE
                    else "The installed version matches the compatibility manifest.")
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_repair(_SolverInstallDialog, bpy.types.Operator):
    """Repair the managed installation by reinstalling the verified official release"""
    bl_idname = "clothnext.solver_repair"
    bl_label = "Repair Managed Installation"
    bl_description = (
        "Reinstall only the selected managed release from its verified "
        "official archive while preserving every other solver version")
    bl_options = {"REGISTER", "INTERNAL"}

    def invoke(self, context, _event):
        if self._report_online_access_blocked():
            return {"CANCELLED"}
        installer = _session.ensure_installer()
        if installer is None:
            self.report({"ERROR"}, "Automatic download is disabled: "
                        f"{_session.disabled_reason}")
            return {"CANCELLED"}
        try:
            installer.prepare_repair()
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width=520)


class CLOTHNEXT_OT_solver_remove_managed(bpy.types.Operator):
    """Remove the managed solver installation (external installs are never touched)"""
    bl_idname = "clothnext.solver_remove_managed"
    bl_label = "Remove Managed Installation"
    bl_description = (
        "Remove only this managed solver directory, or unregister an external "
        "installation without deleting its files")
    bl_options = {"INTERNAL"}
    installation_id: bpy.props.StringProperty(default="")

    def invoke(self, context, _event):
        return context.window_manager.invoke_confirm(self, _event)

    def execute(self, _context):
        if _solver_session_active():
            self.report({"ERROR"}, "Stop the active Bake before removing a solver.")
            return {"CANCELLED"}
        paths = ManagedSolverPaths.default()
        registry, error = _read_registry()
        installation = registry.get(
            self.installation_id or registry.selected_installation_id)
        if error or installation is None:
            self.report({"ERROR"}, error or "Installation is not registered.")
            return {"CANCELLED"}
        try:
            if installation.managed:
                installer = _session.ensure_installer()
                if installer is None:
                    raise ValueError("No managed installer is available")
                installer.remove(installation.installation_id)
            registry = registry.unregister(installation.installation_id)
            write_registry(paths.registry_json, registry)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, (
            "Managed installation removed." if installation.managed
            else "External installation unregistered; its files were untouched."))
        return {"FINISHED"}


class CLOTHNEXT_OT_solver_open_folder(bpy.types.Operator):
    """Open the managed solver installation folder"""
    bl_idname = "clothnext.solver_open_folder"
    bl_label = "Open Installation Folder"
    bl_description = "Open the managed solver installations folder in File Explorer"
    bl_options = {"INTERNAL"}
    installation_id: bpy.props.StringProperty(default="")

    def execute(self, _context):
        import os
        if self.installation_id:
            registry, error = _read_registry()
            installation = registry.get(self.installation_id)
            if error or installation is None or not installation.root.is_dir():
                self.report({"ERROR"}, error or "The installation folder is missing.")
                return {"CANCELLED"}
            os.startfile(installation.root)
            return {"FINISHED"}
        paths = ManagedSolverPaths.default()
        if not paths.root.is_dir():
            self.report({"ERROR"}, "The managed solver folder does not exist yet.")
            return {"CANCELLED"}
        os.startfile(paths.root)  # noqa: S606 — user-requested folder open
        return {"FINISHED"}


_ACTION_OPERATORS = {
    InstallerAction.DOWNLOAD_OFFICIAL_SOLVER: "clothnext.solver_download",
    InstallerAction.SELECT_EXISTING_INSTALLATION: "clothnext.solver_select_existing",
    InstallerAction.OPEN_OFFICIAL_DOWNLOAD_PAGE: "clothnext.solver_open_download_page",
    InstallerAction.CANCEL: "clothnext.solver_cancel",
    InstallerAction.RUN_HEALTH_CHECK: "clothnext.solver_health_check",
    InstallerAction.CHECK_FOR_COMPATIBLE_UPDATE: "clothnext.solver_check_update",
    InstallerAction.INSTALL_COMPATIBLE_VERSION: "clothnext.solver_download",
    InstallerAction.REPAIR_MANAGED_INSTALLATION: "clothnext.solver_repair",
    InstallerAction.REMOVE_MANAGED_INSTALLATION: "clothnext.solver_remove_managed",
    InstallerAction.OPEN_INSTALLATION_FOLDER: "clothnext.solver_open_folder",
    InstallerAction.SELECT_ANOTHER_INSTALLATION: "clothnext.solver_select_existing",
    InstallerAction.RETRY: "clothnext.solver_download",
}


def _new_look_changed(_self, context):
    from . import floating_simulation
    floating_simulation.sync(context)


LEARNING_CENTER_URL = "https://polyworks-art.github.io/Cloth_neXT/docs/"
_STATUS_ICONS = {"ACTIVE": "CHECKMARK", "OFFLINE_VERIFIED": "CHECKMARK", "EXPIRED": "ERROR",
                 "REVOKED": "ERROR", "SUSPENDED": "ERROR", "INVALID": "ERROR"}
_PROBLEM_STATES = frozenset({"EXPIRED", "REVOKED", "SUSPENDED", "INVALID", "SESSION_EXPIRED",
                             "DEVICE_DEACTIVATED"})


def _wrapped(layout, text: str, width: int = 78, icon: str = "NONE") -> None:
    import textwrap
    for index, line in enumerate(textwrap.wrap(text, width) or [""]):
        layout.label(text=line, icon=icon if index == 0 else "BLANK1")


def _status_row(column, key: str, value: str, icon: str = "NONE") -> None:
    split = column.split(factor=0.3, align=True)
    split.label(text=key)
    split.label(text=value, icon=icon)


def draw_account_card(layout, superhive, view) -> None:
    """One compact read-only card: Classic via Superhive, optional PolyWorks services.

    Every account action lives in the Companion; the single button only opens it.
    """
    from ..polyworks.status import LicenseStatus, format_time
    card = layout.box()
    card.label(text="Account & License", icon="USER")
    classic = card.column(align=True)
    _status_row(classic, "Superhive", "Connected" if superhive.connected else "Not connected",
                "CHECKMARK" if superhive.connected else "X")
    _status_row(classic, "Purchase", "Validated" if superhive.purchase_validated else "Not validated",
                "CHECKMARK" if superhive.purchase_validated else "X")
    card.separator()
    header = card.row()
    header.label(text="PolyWorks Services")
    hint = header.row()
    hint.alignment = "RIGHT"
    hint.label(text="Optional · not needed for Classic simulation")
    if view is None:
        card.label(text="Checking account status…", icon="TIME")
        return
    rows = card.column(align=True)
    signed_in = view.account_label.startswith("Signed in")
    _status_row(rows, "Account", view.account_label + (
        f" · {view.account_identity}" if view.account_identity else ""))
    if signed_in and not view.session_label.startswith("Active"):
        _status_row(rows, "Session", view.session_label)
    if signed_in or view.expires_at is not None or view.status not in (
            LicenseStatus.NOT_SIGNED_IN, LicenseStatus.UNKNOWN):
        details = [view.label, view.tier]
        if view.seats:
            details.append(f"{view.seats} seat" + ("" if view.seats == 1 else "s"))
        _status_row(rows, "Service license", " · ".join(item for item in details if item),
                    _STATUS_ICONS.get(view.status, "NONE"))
        if view.devices_active is not None and view.device_limit is not None:
            _status_row(rows, "Devices", f"{view.devices_active} of {view.device_limit} in use")
        _status_row(rows, "This computer", (
            f"Activated ({view.device_label})" if view.expires_at and view.device_label
            else "Activated" if view.expires_at else "Not activated"))
        if view.expires_at:
            _status_row(rows, "Offline access", view.offline_authorization)
    online = {True: "Online", False: "Offline", None: "Not checked yet"}[view.online]
    _status_row(rows, "Connection", online + (" · Companion open" if view.companion_running else ""))
    if signed_in or view.last_sync_at is not None:
        _status_row(rows, "Last sync", format_time(view.last_sync_at))

    notices = []
    for text in (view.message, *view.warnings, view.connection_problem):
        if text and text not in notices:
            notices.append(text)
    if notices:
        column = card.column(align=True)
        for text in notices:
            _wrapped(column, text, icon="ERROR" if view.status in _PROBLEM_STATES else "INFO")
    footer = card.row()
    footer.alignment = "RIGHT"
    if signed_in:
        footer.operator("clothnext.polyworks_disconnect", text="Disconnect")
    else:
        footer.operator("clothnext.polyworks_connect", text="Connect PolyWorks Account", icon="URL")
    footer.operator("clothnext.open_account_companion", text="Open Cloth NeXt Companion",
                    icon="WINDOW")
    bugs = card.row()
    bugs.alignment = "RIGHT"
    bugs.label(text="Found a problem?")
    from . import icon_registry
    bugs.operator("clothnext.report_bug", text="Report a Bug",
                  **icon_registry.icon_kwargs("cloth_next", "ERROR"))
    from . import bug_report
    bug_report.draw_status(card)


def _gaia_owner_changed(self, context):
    from ..gaia.owner_test import configure
    configure(bpy.path.abspath(self.gaia_owner_manifest) if self.gaia_owner_manifest else '')


def initialize_owner_runtime():
    """Read persisted RNA only in the Blender adapter, after registration."""
    from ..gaia.owner_test import configure
    try:
        prefs = addon_preferences(bpy.context, __package__)
    except (AttributeError, KeyError):
        configure('')
    else:
        value = getattr(prefs, 'gaia_owner_manifest', '')
        configure(bpy.path.abspath(value) if value else '')


def _send_diagnostics_changed(_self, _context) -> None:
    from . import diagnostics_runtime
    diagnostics_runtime.apply_consent()


class CLOTHNEXT_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = _ADDON_ID

    gaia_owner_manifest: bpy.props.StringProperty(
        name="GAIA Owner Runtime", subtype="FILE_PATH", default="",
        description="Manifest for your separate local experimental GAIA runtime; never replaces the official solver",
        update=_gaia_owner_changed)

    new_look: bpy.props.BoolProperty(
        name="New Look", default=True,
        description="Enable floating Cloth NeXt viewport controls; use the viewport shortcut to show or hide the toolbar",
        update=_new_look_changed)

    external_solver_path: bpy.props.StringProperty(
        name="External Solver Path", subtype="DIR_PATH", default="",
        description="Existing Simulation Solver installation selected by you; "
                    "Cloth NeXt never modifies it")
    selected_solver_installation_id: bpy.props.EnumProperty(
        name="Active Solver",
        items=_solver_enum_items, update=_solver_enum_update,
        description="Select the exact installed solver used by future Bakes; "
                    "selection is locked while a session is active")
    solver_engine: bpy.props.EnumProperty(
        name="Engine", items=_engine_items, get=_engine_get, set=_engine_set,
        description="Solver engine for future Bakes. Changing it never happens "
                    "automatically and is locked while a Bake is active")
    legacy_engine_chosen: bpy.props.BoolProperty(
        name="Legacy engine chosen", default=False, options={"HIDDEN"},
        description="The artist chose Legacy (the upstream contact solver) in the Engine selector")
    aether_engine_chosen: bpy.props.BoolProperty(
        name="AETHER Engine chosen", default=False, options={"HIDDEN"},
        description="The artist chose AETHER (the native AETHER Engine) in the Engine selector")
    gaia_reproducible_bake: bpy.props.BoolProperty(
        name="Reproducible Bake", default=False,
        description="GAIA only: run the deterministic solver path so the same scene, "
                    "settings, GPU and driver give bit-identical results. Slower. "
                    "Scenes with static colliders, rigid bodies or translation locks are not covered yet")
    solver_backend_choice: bpy.props.EnumProperty(
        name="Solver Backend",
        items=(("AUTO", "Auto", "Use verified CUDA if available, otherwise CPU"),
               ("CUDA", "CUDA", "Require the NVIDIA CUDA build"),
               ("ROCM", "ROCm", "Require the AMD ROCm build; general AMD support is not yet verified"),
               ("CPU", "CPU", "Require the CPU build")),
        default="AUTO",
        description="Backend for future Bakes; an explicit choice never falls back")

    bake_location: bpy.props.EnumProperty(
        name="Bake Location",
        items=(("LOCAL", "This Computer", "Simulate with the selected solver on this computer"),
               ("CLOUD", "Cloud", "Send the exported Bake to the PolyWorks Cloud and retrieve the result later")),
        default="LOCAL",
        description="Where future Bakes run. Cloth NeXt never switches location by itself")
    cloud_auto_download: bpy.props.BoolProperty(
        name="Download Results Automatically", default=True,
        description="Download finished Cloud results while Blender is running and enough disk space is free; "
                    "otherwise they stay on the server until they expire")

    developer_tools: bpy.props.BoolProperty(
        name="Developer Tools", default=False,
        description="Show internal solver tests and UI diagnostics in the "
                    "Cloth NeXt Cache panel.")
    auto_launch_bake_window: bpy.props.BoolProperty(
        name="Open Bake Window Automatically", default=True,
        description="Require the visible topmost Bake window before locking "
                    "Blender. When disabled, Bake runs in Blender without a "
                    "global modal workflow lock")
    onboarding_state: bpy.props.StringProperty(
        name="Onboarding State", default="",
        description="Internal persistent Welcome and What's-New seen state",
        options={"HIDDEN"})
    show_whats_new_after_updates: bpy.props.BoolProperty(
        name="Show What's New after updates", default=True,
        description="Show release highlights after the startup splash when Cloth NeXt updates",
        options={"HIDDEN"})
    show_role_colors: bpy.props.BoolProperty(
        name="Show Cloth NeXt Role Colors", default=False,
        description="Color Cloth NeXt objects by role. Visible in Solid shading "
                    "with Color > Object; Random and other color modes remain available",
        update=viewport_colors.update_role_colors)
    auto_frame_bake: bpy.props.BoolProperty(
        name="Auto-Frame Cloth During Bake", default=True,
        description="Keep all live-baked deformables comfortably visible in "
                    "open 3D viewports")
    auto_frame_style: bpy.props.EnumProperty(
        name="Framing Motion",
        items=(("SMOOTH", "Smooth", "Responsive, softly damped framing"),
               ("CINEMATIC", "Cinematic",
                "Slower, more deliberate camera drift")),
        default="SMOOTH")
    auto_frame_smoothing: bpy.props.FloatProperty(
        name="Framing Response", default=0.18, min=0.02, max=1.0,
        description="How quickly the viewport follows changes in cloth "
                    "position and size")
    auto_frame_margin: bpy.props.FloatProperty(
        name="Framing Margin", default=1.25, min=1.02, max=3.0,
        description="Extra space kept around the simulated objects")
    send_diagnostics: bpy.props.BoolProperty(
        name="Send Diagnostics", default=True,
        description="Send performance values, Bake results, errors and crash reports to "
                    "PolyWorks to help fix problems. No scenes, file names, folders or passwords. "
                    "Turning this off deletes everything collected so far",
        update=_send_diagnostics_changed)
    telemetry_refresh_seconds: bpy.props.FloatProperty(name="Telemetry Refresh", default=1.0, min=0.25, max=10.0, subtype="TIME")
    auto_cancel_high_ram: bpy.props.BoolProperty(
        name="Auto-Cancel on High RAM", default=True,
        description="Cancel an active Bake after RAM stays above the safety "
                    "threshold for two telemetry samples")
    auto_cancel_ram_percent: bpy.props.IntProperty(
        name="RAM Safety Threshold", default=90, min=50, max=99,
        subtype="PERCENTAGE",
        description="Total system RAM usage that automatically cancels the Bake")

    def draw(self, context) -> None:
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        self._draw_account_card(layout, context)
        self._draw_learning_section(layout)

        self._draw_solver_section(layout)
        from ..gaia import owner_test
        if owner_test.enabled():
            owner = layout.box()
            owner.label(text="GAIA Owner Evaluation — NOT production-ready", icon="ERROR")
            owner.prop(self, "gaia_owner_manifest")
            owner.label(text="CUDA hydrodynamics: frozen NEON only, validated frame ranges.")
            owner.label(text="Select this runtime separately under Active Solver above.")
            owner.label(text="Enable Hydrodynamic Pressure on the cloth's Fluid Interaction panel.")
            owner.label(text="Self-contact parity 19/20; trajectory repeatability exceeds 8 mm.")

        self._draw_bake_location(layout)

        general = layout.box()
        general.label(text="General")
        general.prop(self, "auto_launch_bake_window")
        if is_dev_build():
            general.prop(self, "developer_tools")

        viewport = layout.box()
        viewport.label(text="Viewport")
        viewport.prop(self, "new_look")
        from . import floating_simulation
        if floating_simulation._keymap_item is not None:
            import rna_keymap_ui
            viewport.label(text="Viewport Toolbar Shortcut")
            rna_keymap_ui.draw_kmi(
                [], context.window_manager.keyconfigs.addon,
                floating_simulation._keymap,
                floating_simulation._keymap_item, viewport, 0)
        viewport.prop(self, "show_role_colors")
        if getattr(self, "show_role_colors", False):
            viewport.label(
                text="Role colors require Solid shading > Color > Object.",
                icon="INFO")
            viewport.label(text="Random and other color modes remain available.")
        viewport.prop(self, "auto_frame_bake")
        framing_controls = viewport.column(align=True)
        framing_controls.enabled = getattr(self, "auto_frame_bake", True)
        for name in ("auto_frame_style", "auto_frame_smoothing",
                     "auto_frame_margin"):
            framing_controls.prop(self, name)

        self._draw_diagnostics(layout)

        safety = layout.box()
        safety.label(text="Memory Safety")
        safety.prop(self, "auto_cancel_high_ram")
        threshold = safety.row()
        threshold.enabled = getattr(self, "auto_cancel_high_ram", True)
        threshold.prop(self, "auto_cancel_ram_percent")

    def _draw_diagnostics(self, layout) -> None:
        from .diagnostics_runtime import opted_out_by_environment
        box = layout.box()
        box.label(text="Diagnostics")
        if opted_out_by_environment():
            box.label(text="Switched off by CLOTH_NEXT_NO_TELEMETRY", icon="INFO")
            return
        box.prop(self, "send_diagnostics")
        col = box.column(align=True)
        col.label(text="Performance, Bake results, errors and crashes; no scenes, file names or folders.")
        col.label(text="Sent with an anonymised ID of this computer and, when signed in, your PolyWorks account.")
        if not getattr(bpy.app, "online_access", True):
            col.label(text="Allow Online Access is off: nothing is sent.", icon="INFO")
        box.operator("clothnext.show_diagnostics", icon="TEXT")

    def _draw_learning_section(self, layout) -> None:
        welcome = layout.box()
        welcome.label(text="Learn Cloth NeXt")
        actions = welcome.row(align=True)
        actions.operator("clothnext.open_welcome", text="Open Welcome")
        actions.operator("clothnext.open_whats_new", text="What's New")
        learning = actions.operator(
            "wm.url_open", text="Learning Center", icon="URL")
        learning.url = LEARNING_CENTER_URL

    def _draw_account_card(self, layout, context) -> None:
        """Informational only: Superhive repository state plus a cached PolyWorks view.

        Never contacts a service, reads credentials, files or the vault.
        """
        from .account_status import current_view
        draw_account_card(layout, repository_status(context.preferences.extensions.repos),
                          current_view())

    def _draw_bake_location(self, layout) -> None:
        """Cached Cloud status only: no network or file access while drawing."""
        from ..cloud import service
        box = layout.box()
        box.label(text="Bake Location")
        box.prop(self, "bake_location")
        if getattr(self, "bake_location", "LOCAL") != "CLOUD":
            return
        status = service.availability()
        if status.reason in (service.LOCKED_REASON, service.CHECKING_REASON):
            box.label(text=status.reason, icon="LOCKED")
        elif not status.available:
            row = box.row()
            row.alert = True
            row.label(text=status.reason, icon="ERROR")
        elif status.capabilities is not None and status.capabilities.retention_days:
            box.label(text=f"Results stay available for {status.capabilities.retention_days} days")
        box.prop(self, "cloud_auto_download")
        from . import cloud_ui
        cloud_ui.draw_jobs(box)

    def _draw_solver_section(self, layout) -> None:
        box = layout.box()
        box.label(
            text="GAIA Engine",
            **icon_registry.icon_kwargs("gaia_engine", "NONE"),
        )
        box.label(text="Solver Installations")
        _session.load()
        registry, registry_error = _read_registry()
        selected_id = (getattr(self, "selected_solver_installation_id", "")
                       or registry.selected_installation_id or "")
        active = registry.get(selected_id)
        session_active = _solver_session_active()
        box.label(text="Active Solver")
        selector = box.row()
        selector.enabled = not session_active and bool(registry.installations)
        selector.prop(self, "selected_solver_installation_id")
        if active is None:
            box.label(text="No Solver Selected", **icon_registry.icon_kwargs("error", "ERROR"))
            if selected_id:
                box.label(text="The selected installation is missing.")
        else:
            box.label(text=(
                f"{active.display_name} · Protocol "
                f"{active.protocol_version} · Schema {active.schema_version}"))
            if active.protocol_version in {"0.22", "0.23", "0.26", "0.18"}:
                from ..ppf.backend_selection import available_backend_choices
                backend = box.row()
                backend.enabled = not session_active
                backend.prop(self, "solver_backend_choice", text="Backend")
                if active.protocol_version == "0.18":
                    box.label(text="Lumen provides CUDA only; Auto uses CUDA.")
                choice = str(getattr(self, "solver_backend_choice", "AUTO") or "AUTO")
                if choice not in available_backend_choices(
                        active.protocol_version, active.root):
                    box.label(text=f"{choice} is unavailable in {active.display_name}.",
                              icon="ERROR")
                if choice == "ROCM":
                    box.label(text="ROCm: general AMD GPU support is not yet verified.",
                              icon="INFO")
                box.label(text="The selected backend is checked before each Bake.")
        if session_active:
            box.label(
                text="Solver selection is locked while a Bake is active.",
                icon="LOCKED")
        if registry_error:
            box.label(text=registry_error, **icon_registry.icon_kwargs("error", "ERROR"))

        installed_box = box.box()
        installed_box.label(text="Installed")
        if not registry.installations:
            installed_box.label(text="No registered solver installations.")
        for installation in registry.installations:
            card = installed_box.box()
            label = installation.display_name
            if installation.installation_id == selected_id:
                label += " · Active"
            card.label(text=label)
            card.label(text=(
                f"Protocol {installation.protocol_version or 'Unknown'} · "
                f"Schema {installation.schema_version or 'Unknown'} · "
                f"{installation.channel.title()}"))
            card.label(text=(
                f"Package {installation.package_version or 'Unknown'} · "
                f"Release {installation.official_release_tag or 'Unverified'}"))
            card.label(text=(
                ("Healthy" if installation.healthy else "Unhealthy")
                + " · " + ("Managed" if installation.managed else "External")))
            card.label(text=installation.root_path)
            actions = card.row()
            use = actions.row()
            use.enabled = (
                not session_active and installation.compatible
                and installation.healthy and installation.verified
                and installation.available
                and installation.installation_id != selected_id)
            operator = use.operator("clothnext.solver_use", text="Use")
            operator.installation_id = installation.installation_id
            test = actions.operator(
                "clothnext.solver_health_check", text="Test")
            test.installation_id = installation.installation_id
            folder = actions.operator(
                "clothnext.solver_open_folder", text="Open Folder")
            folder.installation_id = installation.installation_id
            remove = actions.operator(
                "clothnext.solver_remove_managed", text="Remove")
            remove.installation_id = installation.installation_id

        available_box = box.box()
        available_box.label(text="Available Downloads")
        installed_tags = {
            item.official_release_tag for item in registry.installations
            if item.managed}
        for entry in (item for item in _session.entries if item.downloadable):
            row_box = available_box.box()
            row_box.label(text=entry.display_name)
            channel_label = 'Experimental' if entry.protocol_version == '0.26' else entry.channel.title()
            row_box.label(text=(
                f"Protocol {entry.protocol_version} · Schema "
                f"{entry.schema_version} · {channel_label}"))
            if entry.official_release_tag in installed_tags:
                row_box.label(text="Installed", **icon_registry.icon_kwargs("success", "CHECKMARK"))
                reinstall_row = row_box.row()
                reinstall_row.enabled = not session_active
                reinstall = reinstall_row.operator(
                    "clothnext.solver_download", text="Reinstall")
                reinstall.release_id = entry.release_id
                reinstall.reinstall = True
            else:
                buttons = row_box.row()
                buttons.enabled = not session_active
                download = buttons.operator(
                    "clothnext.solver_download", text="Download")
                download.release_id = entry.release_id
                download.activate_after_install = False
                download_use = buttons.operator(
                    "clothnext.solver_download", text="Download and Use")
                download_use.release_id = entry.release_id
                download_use.activate_after_install = True
        installer = _session.installer
        if _session.worker_status:
            box.label(text=_session.worker_status, **icon_registry.icon_kwargs("timer", "TIME"))
        if _session.worker_error:
            box.label(text=_session.worker_error, **icon_registry.icon_kwargs("error", "ERROR"))
        if installer is not None:
            box.label(text=(
                "Installation stage: "
                f"{installer.state.name.replace('_', ' ').title()}"))
            if installer.state is InstallerState.DOWNLOADING:
                done, total = installer.download_progress
                box.label(text=view_model.format_download_progress(done, total))
            if installer.error is not None:
                box.label(text=installer.error.user_message, icon="ERROR")
            if (_session.worker is not None and _session.worker.is_alive()
                    and installer.state is InstallerState.DOWNLOADING):
                box.operator("clothnext.solver_cancel", text="Cancel")
        actions = box.row()
        actions.operator("clothnext.solver_select_existing")
        actions.operator("clothnext.solver_refresh_installations")
        actions.operator("clothnext.solver_open_download_page")
        return
        state = _installer_state()
        installer = _session.installer
        progress_text = None
        if installer is not None and state is InstallerState.DOWNLOADING:
            done, total = installer.download_progress
            progress_text = view_model.format_download_progress(done, total)
        section = view_model.build_section(state, _session.entry,
                                           _session.disabled_reason, _installed_info(),
                                           download_progress=progress_text)
        if section.update_alert is not None:
            # The primary visual message: a real Blender alert (red) box.
            # Drawing it never starts a download — the button below opens the
            # existing confirmation-gated installer dialog.
            warning = box.box()
            warning.alert = True
            warning.label(text=section.update_alert.title, icon="ERROR")
            for line in section.update_alert.lines:
                warning.label(text=line)
            install_row = warning.row()
            install_row.operator(
                _ACTION_OPERATORS[section.update_alert.action],
                text=section.update_alert.action_text)
        for label, value in section.rows:
            row = box.row()
            row.label(text=f"{label}: {value}")
        if section.message:
            box.label(text=section.message)
        if (installer is not None and installer.error is not None
                and state is InstallerState.ERROR):
            box.label(text=installer.error.user_message, icon="ERROR")
        actions = box.column()
        for action in section.actions:
            if (section.update_alert is not None
                    and action is section.update_alert.action):
                continue  # the alert box already offers this action once
            idname = _ACTION_OPERATORS.get(action)
            if idname is not None:
                actions.operator(idname)
        if self.external_solver_path:
            box.label(text=f"External installation: {self.external_solver_path}")


CLASSES = (
    CLOTHNEXT_OT_solver_use,
    CLOTHNEXT_OT_solver_refresh_installations,
    CLOTHNEXT_OT_solver_download,
    CLOTHNEXT_OT_solver_cancel,
    CLOTHNEXT_OT_solver_select_existing,
    CLOTHNEXT_OT_solver_open_download_page,
    CLOTHNEXT_OT_solver_view_licenses,
    CLOTHNEXT_OT_solver_health_check,
    CLOTHNEXT_OT_solver_check_update,
    CLOTHNEXT_OT_solver_repair,
    CLOTHNEXT_OT_solver_remove_managed,
    CLOTHNEXT_OT_solver_open_folder,
    CLOTHNEXT_AddonPreferences,
)
