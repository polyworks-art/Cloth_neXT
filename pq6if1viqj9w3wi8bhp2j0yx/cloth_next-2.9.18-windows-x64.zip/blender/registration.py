# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Reload-safe Blender registration for Cloth NeXt.

Registration performs no downloads, no network access, and no solver
discovery side effects; the solver installer only ever runs after an explicit
user action in the add-on preferences.

Order is deterministic: classes first (preferences, then the object
PropertyGroup, then operators, then panels), then the ``Object.cloth_next``
PointerProperty, then the single Physics-Add draw callback. A partial
registration failure rolls back every step already applied; unregister
reverts everything in strict reverse order.
"""

from __future__ import annotations

import bpy

from . import (addon_update_operators, bake_operators, bake_preview, beta_tools,
               collider_proxy, companion_manager, floating_simulation, icon_registry,
               linked_colliders, object_attachments, object_properties, sewing,
               physics_operators, physics_ui,
               onboarding_manager, pin_constraints, preferences, solver_preferences_ui,
               solver_release_naming, solver_test, test_scene,
               telemetry_runtime, timeline_overlay, validation_state, viewport_autoframe,
               viewport_colors, water_flow, wind_fields, material_zones, material_zone_selector)

_CLASSES = (
    preferences.CLASSES
    + onboarding_manager.CLASSES
    + solver_preferences_ui.CLASSES
    + addon_update_operators.CLASSES
    + object_attachments.CLASSES
    + sewing.CLASSES
    + object_properties.CLASSES
    + collider_proxy.CLASSES
    + linked_colliders.CLASSES
    + physics_operators.CLASSES
    + bake_operators.CLASSES
    + beta_tools.CLASSES
    + test_scene.CLASSES
    + solver_test.CLASSES
    + physics_ui.CLASSES
    + floating_simulation.CLASSES
    + pin_constraints.CLASSES
    + water_flow.CLASSES
    + material_zones.CLASSES
    + material_zone_selector.CLASSES
)

_registered = False


def _steps() -> list[tuple]:
    """Ordered (apply, revert) pairs covering all registration side effects."""
    steps: list[tuple] = [
        (solver_release_naming.install, solver_release_naming.uninstall),
        (solver_preferences_ui.install, solver_preferences_ui.uninstall),
    ]
    steps.extend(
        (lambda cls=cls: bpy.utils.register_class(cls),
         lambda cls=cls: bpy.utils.unregister_class(cls))
        for cls in _CLASSES
    )
    steps.append((object_properties.attach_to_object,
                  object_properties.detach_from_object))
    steps.append((object_attachments.register, object_attachments.unregister))
    steps.append((sewing.register, sewing.unregister))
    steps.append((water_flow.register, water_flow.unregister))
    steps.append((material_zone_selector.register, material_zone_selector.unregister))
    steps.append((linked_colliders.register, linked_colliders.unregister))
    steps.append((pin_constraints.install_runtime_hooks,
                  pin_constraints.uninstall_runtime_hooks))
    # Existing files can already contain an enabled PDRD object before 2.1.3 is
    # registered. Migrate recognized quality presets immediately after the RNA
    # properties exist; Custom values remain untouched.
    steps.append((physics_operators.synchronize_all_scene_quality,
                  lambda: None))
    steps.append((physics_ui.append_add_physics_entry,
                  physics_ui.remove_add_physics_entry))
    steps.append((icon_registry.register, icon_registry.unregister))
    steps.append((viewport_colors.register, viewport_colors.unregister))
    steps.append((timeline_overlay.register, timeline_overlay.unregister))
    steps.append((floating_simulation.register, floating_simulation.unregister))
    steps.append((telemetry_runtime.register, telemetry_runtime.unregister))
    steps.append((onboarding_manager.register, onboarding_manager.unregister))
    # Depsgraph/load/undo handlers that mark Cloth NeXt objects dirty. Attached
    # late and detached early, and idempotent, so a reload cannot leave a
    # duplicate behind.
    steps.append((validation_state.register, validation_state.unregister))
    steps.append((wind_fields.register, wind_fields.unregister))
    steps.append((solver_test.install_recovery_ui_handler,
                  solver_test.uninstall_recovery_ui_handler))
    steps.append((solver_test.synchronize_playback_input_deformers,
                  lambda: None))
    return steps


def register() -> None:
    global _registered
    if _registered:
        return
    applied: list = []
    try:
        for apply_step, revert_step in _steps():
            apply_step()
            applied.append(revert_step)
    except Exception:
        for revert_step in reversed(applied):
            revert_step()
        raise
    _registered = True
    addon_update_operators.initialize_updates()


def unregister() -> None:
    global _registered
    if not _registered:
        return
    # Stop installer/update workers, timers, and handles first. The solver
    # test shutdown cancels the run, stops the exact owned solver process
    # (never an external server), and joins the worker thread.
    solver_test.shutdown()
    viewport_autoframe.reset()
    preferences.shutdown()
    addon_update_operators.shutdown()
    bake_preview.stop()
    companion_manager.shutdown()
    for _apply_step, revert_step in reversed(_steps()):
        revert_step()
    _registered = False
