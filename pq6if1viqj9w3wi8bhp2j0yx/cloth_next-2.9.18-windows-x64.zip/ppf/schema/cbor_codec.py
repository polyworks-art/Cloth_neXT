# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Strict CBOR subset codec for the verified PPF 0.11 wire payloads.

This is deliberately NOT a general CBOR library. It implements exactly the
subset the pinned PPF protocol uses (RFC 8949 major types 0-5 and 7), with
the same output choices ``cbor2`` makes for the payloads the official addon
produces, so the encoded bytes are accepted byte-for-byte by the shipped
solver frontend (``cbor2.loads``) and the Rust ``ciborium`` reader:

- unsigned/negative integers in their shortest form,
- Python ``float`` always as IEEE-754 float64 (major 7, ai 27) — ``cbor2``
  emits doubles for Python floats by default and the Rust schema declares
  every wire float as ``f64``,
- definite-length UTF-8 text strings, byte strings, arrays, and maps,
- ``False`` / ``True`` / ``None`` simple values,
- map insertion order preserved (payload hashes must be stable).

Everything else (tags, indefinite lengths, bignums, half/single floats on
encode) is rejected loudly. Decoding additionally accepts float16/float32
for robustness against future producers, but never silently skips data.

Runtime dependency decision (Phase 3A): no third-party wheel is vendored
into the extension. The subset above is small, closed, and pinned by the
protocol audit; correctness is enforced by golden fixtures generated with
the exact ``cbor2`` build shipped inside the official solver package (see
``tests/test_ppf_cbor_codec.py`` and ``tests/fixtures/ppf_0_11/``).
"""

from __future__ import annotations

import struct
from typing import Any, BinaryIO, Callable

MAX_DECODE_ITEMS = 50_000_000  # hard bound: no payload we decode is larger
MAX_NESTING = 32


class CborError(ValueError):
    """Raised on any unsupported construct or malformed input."""


# ---------------------------------------------------------------------------
# Encoding

def _encode_head(major: int, argument: int, out: bytearray) -> None:
    if argument < 0:
        raise CborError("negative length argument")
    if argument < 24:
        out.append((major << 5) | argument)
    elif argument < 0x100:
        out.append((major << 5) | 24)
        out.append(argument)
    elif argument < 0x1_0000:
        out.append((major << 5) | 25)
        out.extend(argument.to_bytes(2, "big"))
    elif argument < 0x1_0000_0000:
        out.append((major << 5) | 26)
        out.extend(argument.to_bytes(4, "big"))
    elif argument < 0x1_0000_0000_0000_0000:
        out.append((major << 5) | 27)
        out.extend(argument.to_bytes(8, "big"))
    else:
        raise CborError("integer exceeds 64-bit CBOR argument range")


def _encode_item(value: Any, out, depth: int, progress=None) -> None:
    if depth > MAX_NESTING:
        raise CborError("value nests deeper than the protocol subset allows")
    # bool must be tested before int (bool is an int subclass)
    if value is False:
        out.append(0xF4)
    elif value is True:
        out.append(0xF5)
    elif value is None:
        out.append(0xF6)
    elif isinstance(value, int):
        if value >= 0:
            _encode_head(0, value, out)
        else:
            _encode_head(1, -1 - value, out)
    elif isinstance(value, float):
        out.append(0xFB)
        out.extend(struct.pack(">d", value))
    elif isinstance(value, str):
        raw = value.encode("utf-8")
        _encode_head(3, len(raw), out)
        out.extend(raw)
    elif isinstance(value, (bytes, bytearray)):
        _encode_head(2, len(value), out)
        out.extend(value)
    elif _is_numpy_array(value):
        _encode_numpy_array(value, out, depth, progress)
    elif isinstance(value, (list, tuple)):
        _encode_head(4, len(value), out)
        for item in value:
            _encode_item(item, out, depth + 1, progress)
    elif isinstance(value, dict):
        _encode_head(5, len(value), out)
        for key, item in value.items():
            if not isinstance(key, (str, int)) or isinstance(key, bool):
                raise CborError(f"unsupported map key type {type(key).__name__}")
            _encode_item(key, out, depth + 1, progress)
            _encode_item(item, out, depth + 1, progress)
    else:
        raise CborError(f"unsupported type {type(value).__name__} "
                        "(outside the verified solver wire subset)")


def _is_numpy_array(value: Any) -> bool:
    """Recognize ndarrays without making NumPy a codec dependency."""
    return (type(value).__module__.split(".", 1)[0] == "numpy"
            and hasattr(value, "shape") and hasattr(value, "flat"))


def _encode_numpy_vec3_frames(value: Any, out, progress=None) -> bool:
    """Vectorize ``(frames, vertices, 3)`` float animation encoding.

    The scalar encoder made large animated colliders spend minutes in Python
    after capture had already reached N/N.  This produces byte-identical CBOR
    in bounded vertex blocks and works directly from a memmap.
    """
    shape = tuple(int(size) for size in value.shape)
    dtype = getattr(value, "dtype", None)
    if len(shape) != 3 or shape[2] != 3 or getattr(dtype, "kind", "") != "f":
        return False
    import numpy as np
    _encode_head(4, shape[0], out)
    for frame in range(shape[0]):
        _encode_head(4, shape[1], out)
        for start in range(0, shape[1], 16_384):
            stop = min(start + 16_384, shape[1])
            count = stop - start
            values = np.asarray(value[frame, start:stop], dtype=">f8")
            encoded = np.empty((count, 28), dtype=np.uint8)
            encoded[:, 0] = 0x83
            for axis, marker in enumerate((1, 10, 19)):
                encoded[:, marker] = 0xFB
                raw = values[:, axis].reshape(count, 1).view(np.uint8)
                encoded[:, marker + 1:marker + 9] = raw
            out.extend(memoryview(encoded).cast("B"))
        if progress is not None:
            progress(frame + 1, shape[0])
    return True


def _encode_numpy_float_payload(values, width: int):
    """Return CBOR doubles for a flat block without Python float objects."""
    import numpy as np
    source = np.asarray(values, dtype=">f8").reshape(-1)
    encoded = np.empty((len(source), 9), dtype=np.uint8)
    encoded[:, 0] = 0xFB
    encoded[:, 1:] = source.reshape(-1, 1).view(np.uint8)
    return encoded.reshape(-1)


def _encode_numpy_protocol_float_array(value: Any, out) -> bool:
    """Vectorize the float array shapes used by the PPF scene schema."""
    shape = tuple(int(size) for size in value.shape)
    dtype = getattr(value, "dtype", None)
    if getattr(dtype, "kind", "") != "f":
        return False
    import numpy as np
    block_size = 16_384
    if len(shape) == 1:
        _encode_head(4, shape[0], out)
        for start in range(0, shape[0], block_size):
            out.extend(memoryview(_encode_numpy_float_payload(
                value[start:start + block_size], 1)).cast("B"))
        return True
    if len(shape) == 2 and shape[1] in (2, 3):
        _encode_head(4, shape[0], out)
        row_head = 0x80 | shape[1]
        row_bytes = 1 + shape[1] * 9
        for start in range(0, shape[0], block_size):
            block = np.asarray(value[start:start + block_size], dtype=">f8")
            encoded = np.empty((len(block), row_bytes), dtype=np.uint8)
            encoded[:, 0] = row_head
            raw = block.reshape(len(block), shape[1], 1).view(
                np.uint8).reshape(len(block), shape[1], 8)
            for axis in range(shape[1]):
                marker = 1 + axis * 9
                encoded[:, marker] = 0xFB
                encoded[:, marker + 1:marker + 9] = raw[:, axis, :]
            out.extend(memoryview(encoded).cast("B"))
        return True
    if len(shape) == 3 and shape[1:] == (3, 2):
        _encode_head(4, shape[0], out)
        row_bytes = 1 + 3 * (1 + 2 * 9)
        for start in range(0, shape[0], block_size):
            block = np.asarray(value[start:start + block_size], dtype=">f8")
            encoded = np.empty((len(block), row_bytes), dtype=np.uint8)
            encoded[:, 0] = 0x83
            raw = block.reshape(len(block), 3, 2, 1).view(
                np.uint8).reshape(len(block), 3, 2, 8)
            for corner in range(3):
                base = 1 + corner * 19
                encoded[:, base] = 0x82
                for axis in range(2):
                    marker = base + 1 + axis * 9
                    encoded[:, marker] = 0xFB
                    encoded[:, marker + 1:marker + 9] = (
                        raw[:, corner, axis, :])
            out.extend(memoryview(encoded).cast("B"))
        return True
    return False


def _encode_numpy_array(value: Any, out: bytearray, depth: int,
                        progress=None) -> None:
    """Encode an ndarray as nested CBOR arrays without ``tolist()``.

    Animated collider captures can contain millions of coordinates.  Walking
    the ndarray/memmap directly keeps encoding bounded to the CBOR output plus
    the compact numeric capture instead of allocating a Python object per
    scalar.  Numeric leaves intentionally become normal Python int/float wire
    values, matching cbor2's normalized upstream payload.
    """
    shape = tuple(int(size) for size in value.shape)
    if not shape:
        _encode_item(value.item(), out, depth + 1, progress)
        return
    if _encode_numpy_vec3_frames(value, out, progress):
        return
    if _encode_numpy_protocol_float_array(value, out):
        return

    def emit(axis: int, prefix: tuple[int, ...]) -> None:
        _encode_head(4, shape[axis], out)
        if axis + 1 < len(shape):
            for index in range(shape[axis]):
                emit(axis + 1, prefix + (index,))
        else:
            for index in range(shape[axis]):
                scalar = value[prefix + (index,)].item()
                _encode_item(scalar, out, depth + axis + 1, progress)

    emit(0, ())


def dumps(value: Any) -> bytes:
    """Encode ``value`` using the strict verified subset."""
    out = bytearray()
    _encode_item(value, out, 0)
    return bytes(out)


class _StreamOutput:
    """Small bytearray-compatible adapter around a binary stream."""

    __slots__ = ("stream",)

    def __init__(self, stream: BinaryIO) -> None:
        self.stream = stream

    def append(self, value: int) -> None:
        self.stream.write(bytes((value,)))

    def extend(self, value) -> None:
        self.stream.write(value)


def dump(value: Any, stream: BinaryIO, *,
         progress: Callable[[int, int], None] | None = None) -> None:
    """Encode to a stream without retaining the complete payload in RAM."""
    out = _StreamOutput(stream)

    _encode_item(value, out, 0, progress)


# ---------------------------------------------------------------------------
# Decoding

class _Reader:
    __slots__ = ("data", "offset", "compact_arrays")

    def __init__(self, data: bytes, *, compact_arrays: bool = False) -> None:
        self.compact_arrays = compact_arrays
        self.data = data
        self.offset = 0

    def take(self, count: int) -> bytes:
        if count < 0 or self.offset + count > len(self.data):
            raise CborError("truncated CBOR input")
        chunk = self.data[self.offset:self.offset + count]
        self.offset += count
        return chunk

    def byte(self) -> int:
        return self.take(1)[0]


def _decode_argument(reader: _Reader, additional: int) -> int:
    if additional < 24:
        return additional
    if additional == 24:
        return reader.byte()
    if additional == 25:
        return int.from_bytes(reader.take(2), "big")
    if additional == 26:
        return int.from_bytes(reader.take(4), "big")
    if additional == 27:
        return int.from_bytes(reader.take(8), "big")
    raise CborError(f"unsupported additional info {additional} "
                    "(indefinite lengths are outside the subset)")


def _decode_item(reader: _Reader, depth: int) -> Any:
    if depth > MAX_NESTING:
        raise CborError("input nests deeper than the protocol subset allows")
    initial = reader.byte()
    major = initial >> 5
    additional = initial & 0x1F
    if major == 0:
        return _decode_argument(reader, additional)
    if major == 1:
        return -1 - _decode_argument(reader, additional)
    if major == 2:
        length = _decode_argument(reader, additional)
        if length > MAX_DECODE_ITEMS:
            raise CborError("byte string exceeds the decode bound")
        return bytes(reader.take(length))
    if major == 3:
        length = _decode_argument(reader, additional)
        if length > MAX_DECODE_ITEMS:
            raise CborError("text string exceeds the decode bound")
        try:
            return reader.take(length).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise CborError(f"invalid UTF-8 text string: {exc}") from exc
    if major == 4:
        count = _decode_argument(reader, additional)
        if count > MAX_DECODE_ITEMS:
            raise CborError("array exceeds the decode bound")
        # Scene animation uses fixed-width vec3 doubles. Keep these large
        # tables as read-only views instead of millions of Python objects.
        if reader.compact_arrays and count >= 16 and depth + 2 <= MAX_NESTING:
            start = reader.offset
            size = count * 28
            if start + size <= len(reader.data):
                import numpy as np
                raw = np.frombuffer(reader.data, dtype=np.uint8,
                                    count=size, offset=start).reshape(count, 28)
                if (np.all(raw[:, 0] == 0x83)
                        and np.all(raw[:, 1] == 0xFB)
                        and np.all(raw[:, 10] == 0xFB)
                        and np.all(raw[:, 19] == 0xFB)):
                    reader.offset += size
                    return np.ndarray((count, 3), dtype=">f8",
                                      buffer=reader.data, offset=start + 2,
                                      strides=(28, 9))
        return [_decode_item(reader, depth + 1) for _ in range(count)]
    if major == 5:
        count = _decode_argument(reader, additional)
        if count > MAX_DECODE_ITEMS:
            raise CborError("map exceeds the decode bound")
        result: dict[Any, Any] = {}
        for _ in range(count):
            key = _decode_item(reader, depth + 1)
            if not isinstance(key, (str, int)) or isinstance(key, bool):
                raise CborError(f"unsupported map key type {type(key).__name__}")
            result[key] = _decode_item(reader, depth + 1)
        return result
    if major == 7:
        if additional == 20:
            return False
        if additional == 21:
            return True
        if additional == 22:
            return None
        if additional == 25:
            return struct.unpack(">e", reader.take(2))[0]
        if additional == 26:
            return struct.unpack(">f", reader.take(4))[0]
        if additional == 27:
            return struct.unpack(">d", reader.take(8))[0]
        raise CborError(f"unsupported simple/float encoding {additional}")
    raise CborError(f"unsupported CBOR major type {major} "
                    "(tags are outside the verified subset)")


def loads(data: bytes, *, compact_arrays: bool = False) -> Any:
    """Decode a single CBOR item; trailing bytes are an error."""
    reader = _Reader(bytes(data), compact_arrays=compact_arrays)
    value = _decode_item(reader, 0)
    if reader.offset != len(reader.data):
        raise CborError(f"{len(reader.data) - reader.offset} trailing bytes "
                        "after the CBOR item")
    return value
