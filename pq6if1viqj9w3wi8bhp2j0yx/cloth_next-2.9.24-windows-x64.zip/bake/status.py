# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Immutable status snapshots shared by every Cloth NeXt bake interface."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from enum import Enum
import json
import math
import time
from typing import Any

from ..veyra.model import CompanionMode, VeyraStep


class BakeState(str, Enum):
    IDLE = "IDLE"
    PREPARING = "PREPARING"
    PREPARING_WATER = "PREPARING_WATER"
    STARTING_COMPANION = "STARTING_COMPANION"
    WAITING_FOR_COMPANION = "WAITING_FOR_COMPANION"
    COMPANION_READY = "COMPANION_READY"
    STARTING_RUN = "STARTING_RUN"
    EXPORTING = "EXPORTING"
    STARTING_SOLVER = "STARTING_SOLVER"
    UPLOADING = "UPLOADING"
    BUILDING = "BUILDING"
    SIMULATING = "SIMULATING"
    FETCHING = "FETCHING"
    IMPORTING = "IMPORTING"
    FINISHED = "FINISHED"
    CANCELLING = "CANCELLING"
    CANCELLED = "CANCELLED"
    ERROR = "ERROR"

class BakeJobKind(str, Enum):
    PREVIEW = "PREVIEW"
    SOLVER_TEST = "SOLVER_TEST"
    BAKE = "BAKE"
    VEYRA = "VEYRA"
    WATER_FIELD = "WATER_FIELD"

class BakeActivity(str, Enum):
    IDLE="IDLE"; VALIDATING="VALIDATING"; CAPTURING_GEOMETRY="CAPTURING_GEOMETRY"
    ENCODING_SCENE="ENCODING_SCENE"; STARTING_SOLVER="STARTING_SOLVER"
    BUILDING_CONTACTS="BUILDING_CONTACTS"; DETECTING_COLLISIONS="DETECTING_COLLISIONS"
    SOLVING_CONSTRAINTS="SOLVING_CONSTRAINTS"; UPDATING_PINS="UPDATING_PINS"
    ADVANCING_SIMULATION="ADVANCING_SIMULATION"; WRITING_FRAME="WRITING_FRAME"
    WAITING_FOR_OUTPUT="WAITING_FOR_OUTPUT"; READING_RESULTS="READING_RESULTS"
    BUILDING_PC2="BUILDING_PC2"; APPLYING_PLAYBACK="APPLYING_PLAYBACK"
    CLEANING_UP="CLEANING_UP"; CANCELLING="CANCELLING"; RECOVERY="RECOVERY"
    FINISHED="FINISHED"; ERROR="ERROR"; UNKNOWN="UNKNOWN"
    CAPTURING_PIN_TARGETS="CAPTURING_PIN_TARGETS"
    CAPTURING_COLLIDER_MOTION="CAPTURING_COLLIDER_MOTION"
    CAPTURING_FORCE_MOTION="CAPTURING_FORCE_MOTION"
    CAPTURING_WIND="CAPTURING_WIND"
    VALIDATING_PIN_TOPOLOGY="VALIDATING_PIN_TOPOLOGY"
    ENCODING_PIN_ANIMATION="ENCODING_PIN_ANIMATION"
    PREPARING_WATER="PREPARING_WATER"

ACTIVITY_LABELS = {
    BakeActivity.IDLE:"Waiting for a Bake", BakeActivity.VALIDATING:"Validating Blender scene",
    BakeActivity.CAPTURING_GEOMETRY:"Preparing evaluated geometry",
    BakeActivity.ENCODING_SCENE:"Encoding simulation scene", BakeActivity.STARTING_SOLVER:"Initializing solver",
    BakeActivity.BUILDING_CONTACTS:"Building contact constraints",
    BakeActivity.DETECTING_COLLISIONS:"Detecting collision candidates",
    BakeActivity.SOLVING_CONSTRAINTS:"Solving constraints", BakeActivity.UPDATING_PINS:"Updating pinned vertices",
    BakeActivity.ADVANCING_SIMULATION:"Advancing simulation", BakeActivity.WRITING_FRAME:"Writing frame",
    BakeActivity.WAITING_FOR_OUTPUT:"Waiting for solver output", BakeActivity.READING_RESULTS:"Reading simulated vertices",
    BakeActivity.BUILDING_PC2:"Building PC2 cache", BakeActivity.APPLYING_PLAYBACK:"Applying playback cache",
    BakeActivity.CLEANING_UP:"Cleaning temporary files", BakeActivity.CANCELLING:"Cancelling solver",
    BakeActivity.RECOVERY:"Saving recovery checkpoint", BakeActivity.FINISHED:"Playback cache ready", BakeActivity.ERROR:"Solver activity failed",
    BakeActivity.UNKNOWN:"Running solver",
    BakeActivity.CAPTURING_PIN_TARGETS:"Capturing animated Pin targets",
    BakeActivity.CAPTURING_COLLIDER_MOTION:"Capturing animated Colliders",
    BakeActivity.CAPTURING_FORCE_MOTION:"Capturing animated Forces",
    BakeActivity.CAPTURING_WIND:"Sampling local Wind",
    BakeActivity.VALIDATING_PIN_TOPOLOGY:"Validating Pin topology",
    BakeActivity.ENCODING_PIN_ANIMATION:"Encoding Pin animation",
    BakeActivity.PREPARING_WATER:"Preparing Water Flow",
}

PHASE_ACTIVITIES = {"PREPARING":BakeActivity.CAPTURING_GEOMETRY, "EXPORTING":BakeActivity.ENCODING_SCENE,
    "PREPARING_WATER":BakeActivity.PREPARING_WATER,
    "STARTING_SOLVER":BakeActivity.STARTING_SOLVER, "UPLOADING":BakeActivity.ENCODING_SCENE,
    "BUILDING":BakeActivity.BUILDING_CONTACTS, "SIMULATING":BakeActivity.ADVANCING_SIMULATION,
    "FETCHING":BakeActivity.READING_RESULTS, "IMPORTING":BakeActivity.BUILDING_PC2}


_TITLES = {s: s.value.replace("_", " ").title() for s in BakeState}
_TITLES[BakeState.PREPARING_WATER] = "Preparing Water Flow"
_ACTIVE = {BakeState.PREPARING, BakeState.STARTING_COMPANION,
           BakeState.PREPARING_WATER,
           BakeState.WAITING_FOR_COMPANION, BakeState.COMPANION_READY,
           BakeState.STARTING_RUN, BakeState.EXPORTING,
           BakeState.STARTING_SOLVER, BakeState.UPLOADING,
           BakeState.BUILDING, BakeState.SIMULATING, BakeState.FETCHING,
           BakeState.IMPORTING, BakeState.CANCELLING}


def format_duration(seconds: float | None, *, approximate: bool = False) -> str:
    if seconds is None or not math.isfinite(seconds) or seconds < 0:
        return "Unknown"
    value = int(seconds)
    hours, value = divmod(value, 3600)
    minutes, secs = divmod(value, 60)
    text = f"{hours:02d}:{minutes:02d}:{secs:02d}" if hours else f"{minutes:02d}:{secs:02d}"
    return f"~{text}" if approximate else text


@dataclass(slots=True)
class FrameEtaEstimator:
    """Smoothed frame-rate ETA that waits for real solver progress."""

    smoothing: float = 0.35
    minimum_samples: int = 2
    _last_frame: int | None = None
    _last_time: float | None = None
    _seconds_per_frame: float | None = None
    _samples: int = 0

    def reset(self) -> None:
        self._last_frame = None
        self._last_time = None
        self._seconds_per_frame = None
        self._samples = 0

    def observe(self, frame: int | None, frame_end: int | None,
                now: float) -> float | None:
        if frame is None or frame_end is None or not math.isfinite(now):
            return None
        frame, frame_end, now = int(frame), int(frame_end), float(now)
        if frame >= frame_end:
            return 0.0
        if self._last_frame is not None and frame < self._last_frame:
            self.reset()
            return None
        if self._last_frame is None:
            self._last_frame, self._last_time = frame, now
            return None
        if frame > self._last_frame and now > float(self._last_time):
            sample = ((now - float(self._last_time)) /
                      (frame - self._last_frame))
            if math.isfinite(sample) and sample > 0.0:
                if self._seconds_per_frame is None:
                    self._seconds_per_frame = sample
                else:
                    weight = min(1.0, max(0.0, float(self.smoothing)))
                    self._seconds_per_frame = (
                        weight * sample +
                        (1.0 - weight) * self._seconds_per_frame)
                self._samples += 1
            self._last_frame, self._last_time = frame, now
        if (self._samples < max(1, int(self.minimum_samples))
                or self._seconds_per_frame is None):
            return None
        return max(0.0, (frame_end - frame) * self._seconds_per_frame)


@dataclass(frozen=True, slots=True)
class BakeSnapshot:
    state: BakeState = BakeState.IDLE
    progress_current: int = 0
    progress_total: int | None = None
    preparation_current: int = 0
    preparation_total: int | None = None
    current_frame: int | None = None
    frame_start: int | None = None
    frame_end: int | None = None
    status_title: str = "Idle"
    status_message: str = "Ready"
    active_object_name: str = ""
    elapsed_seconds: float = 0.0
    estimated_remaining_seconds: float | None = None
    can_cancel: bool = False
    can_pause: bool = False
    is_paused: bool = False
    error_summary: str = ""
    error_details: str = ""
    error_code: str = ""
    job_id: str = ""
    updated_at: float = 0.0
    preview: bool = False
    job_kind: BakeJobKind = BakeJobKind.BAKE
    solver_mode: str = ""
    solver_version: str = ""
    solver_process_id: int | None = None
    solver_name: str = ""
    solver_backend: str = ""
    solver_device: str = ""
    solver_telemetry: dict[str, str] = field(default_factory=dict)
    activity_code: BakeActivity = BakeActivity.IDLE
    activity_label: str = ""
    activity_detail: str = ""
    companion_mode: CompanionMode = CompanionMode.BAKE
    veyra_step: VeyraStep | None = None
    veyra_step_index: int = 0
    veyra_step_current: int = 0
    veyra_step_total: int | None = None

    @property
    def progress_fraction(self) -> float:
        if self.progress_total is None or self.progress_total <= 0:
            return 0.0
        return min(1.0, max(0.0, self.progress_current / self.progress_total))

    @property
    def active(self) -> bool:
        return self.state in _ACTIVE

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["state"] = self.state.value
        data["job_kind"] = self.job_kind.value
        data["activity_code"] = self.activity_code.value
        data["companion_mode"] = self.companion_mode.value
        data["veyra_step"] = (self.veyra_step.value
                              if self.veyra_step is not None else None)
        data["progress_fraction"] = self.progress_fraction
        return data

    def to_transport_dict(self) -> dict[str, Any]:
        """Return a bounded snapshot that always fits the local IPC budget."""
        data = self.to_dict()
        limits = {
            "error_details": 32 * 1024, "error_summary": 4096,
            "status_message": 4096, "activity_detail": 2048,
            "activity_label": 1024, "status_title": 512,
            "active_object_name": 1024, "solver_version": 512,
            "solver_mode": 128, "solver_name": 128,
            "solver_backend": 128, "solver_device": 512,
            "job_id": 128, "error_code": 32,
        }
        for key, limit in limits.items():
            value = data.get(key)
            if isinstance(value, str) and len(value) > limit:
                data[key] = value[:limit - 16] + "\n[truncated]"
        return data

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), sort_keys=True)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BakeSnapshot":
        allowed = {field for field in cls.__dataclass_fields__}
        values = {key: value for key, value in data.items() if key in allowed}
        try:
            values["state"] = BakeState(values.get("state", "IDLE"))
        except (TypeError, ValueError):
            values["state"] = BakeState.ERROR
            values["error_code"] = "CNX-E116"
            values["error_summary"] = "Unsupported Companion status received."
        try:
            values["job_kind"] = BakeJobKind(values.get("job_kind", "BAKE"))
        except (TypeError, ValueError):
            values["job_kind"] = BakeJobKind.BAKE
        try: values["activity_code"] = BakeActivity(values.get("activity_code", "IDLE"))
        except (TypeError, ValueError): values["activity_code"] = BakeActivity.UNKNOWN
        try:
            values["companion_mode"] = CompanionMode(
                values.get("companion_mode", "BAKE"))
        except (TypeError, ValueError):
            values["companion_mode"] = CompanionMode.BAKE
        try:
            step = values.get("veyra_step")
            values["veyra_step"] = VeyraStep(step) if step else None
        except (TypeError, ValueError):
            values["veyra_step"] = None
        for key in ("progress_current", "preparation_current", "current_frame", "frame_start",
                    "frame_end", "solver_process_id", "veyra_step_index",
                    "veyra_step_current"):
            if key in values and values[key] is not None:
                try: values[key] = int(values[key])
                except (TypeError, ValueError): values[key] = None if key != "progress_current" else 0
        telemetry = values.get("solver_telemetry")
        values["solver_telemetry"] = (
            {str(key): str(value) for key, value in telemetry.items()
             if isinstance(key, str) and isinstance(value, (str, int, float))
             and not isinstance(value, bool) and str(value).strip()}
            if isinstance(telemetry, dict) else {})
        if "progress_total" in values and values["progress_total"] is not None:
            try: values["progress_total"] = max(0, int(values["progress_total"]))
            except (TypeError, ValueError): values["progress_total"] = None
        if "preparation_total" in values and values["preparation_total"] is not None:
            try: values["preparation_total"] = max(0, int(values["preparation_total"]))
            except (TypeError, ValueError): values["preparation_total"] = None
        if "veyra_step_total" in values and values["veyra_step_total"] is not None:
            try: values["veyra_step_total"] = max(0, int(values["veyra_step_total"]))
            except (TypeError, ValueError): values["veyra_step_total"] = None
        for key in ("elapsed_seconds", "estimated_remaining_seconds"):
            if key in values and values[key] is not None:
                try:
                    number = float(values[key])
                    values[key] = number if math.isfinite(number) and number >= 0 else None
                except (TypeError, ValueError):
                    values[key] = None
        return cls(**values)

    @classmethod
    def from_json(cls, value: str) -> "BakeSnapshot":
        data = json.loads(value)
        if not isinstance(data, dict):
            raise ValueError("status message must be a JSON object")
        return cls.from_dict(data)


def normalized(snapshot: BakeSnapshot, **changes: Any) -> BakeSnapshot:
    state = changes.get("state", snapshot.state)
    changes.setdefault("status_title", _TITLES[state])
    changes.setdefault("can_cancel", state in _ACTIVE - {BakeState.CANCELLING})
    changes.setdefault("updated_at", time.time())
    if "activity_code" not in changes and state != snapshot.state:
        changes["activity_code"] = PHASE_ACTIVITIES.get(state.value, {
            BakeState.IDLE:BakeActivity.IDLE, BakeState.CANCELLING:BakeActivity.CANCELLING,
            BakeState.CANCELLED:BakeActivity.CLEANING_UP, BakeState.FINISHED:BakeActivity.FINISHED,
            BakeState.ERROR:BakeActivity.ERROR}.get(state, BakeActivity.UNKNOWN))
    if changes.get("preview", snapshot.preview):
        changes.setdefault("job_kind", BakeJobKind.PREVIEW)
    current = max(0, int(changes.get("progress_current", snapshot.progress_current)))
    total = changes.get("progress_total", snapshot.progress_total)
    if total is not None:
        total = max(0, int(total))
        if total > 0:
            current = min(current, total)
    changes["progress_current"] = current
    changes["progress_total"] = total
    return replace(snapshot, **changes)
