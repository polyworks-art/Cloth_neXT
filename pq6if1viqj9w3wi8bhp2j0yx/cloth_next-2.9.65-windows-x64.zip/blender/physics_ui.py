# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Physics Properties integration for Cloth NeXt (Phase 3B).

The "Cloth NeXt" entry is appended to Blender's own ``PHYSICS_PT_add`` panel
through the stable ``Panel.append``/``Panel.remove`` API. Blender does not
expose the internal two-column grid of the native Add-Physics buttons to
appended callbacks, so the entry continues that grid with a left-hand
half-width cell immediately below it. No Blender source class is monkey-
patched and no third-party add-on internals are touched. Cloth NeXt
deliberately has no N-panel; the Physics Properties tab is the primary
workflow.

Honest-controls policy (Phase 3B): every visible, editable property maps to
a real PPF parameter. The former Quality, Pressure, and Shape subpanels and
the editable Cache range are gone until their mappings are verified; the
development frame slice is shown read-only instead. Preset data is parsed
once at import time — no Panel.draw ever reads the preset file.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import bpy

from .. import manifest_version
from ..bake.controller import shared_controller
from ..developer import is_dev_build
from ..materials import formatting
from ..materials import presets as material_presets
from ..solver_quality import (
    PDRD_QUALITY_PRESETS,
    QUALITY_PRESETS,
    matching_quality_preset,
)
from ..updater.addon_versions import parse_version
from . import (beta_tools, collider_proxy, icon_registry, object_properties,
               object_attachments, sewing,
               physics_operators, validation_state)
from .addon_identity import addon_preferences
from .playback_cache import has_cloth_next_playback_marker

_add_entry_appended = False


def _stable_only_panel_visible() -> bool:
    """Keep expert panels out of Beta and Dev builds."""
    return parse_version(manifest_version()).channel_name == "stable"

UNAVAILABLE_OBJECT_TYPES = (
    ("SAND", "Sand",
     "Coming soon. Granular simulation is not supported yet."),
)


class CLOTHNEXT_OT_unavailable_object_type(bpy.types.Operator):
    """Coming soon. This object type is not supported by Cloth NeXt yet."""

    bl_idname = "clothnext.unavailable_object_type"
    bl_label = "Coming Soon"
    bl_options = {"INTERNAL"}

    tooltip: bpy.props.StringProperty(options={"HIDDEN"})

    @classmethod
    def description(cls, _context, properties):
        return properties.tooltip or cls.__doc__

    def execute(self, _context):
        return {"CANCELLED"}


class CLOTHNEXT_MT_object_type(bpy.types.Menu):
    """Presentation-only selector for the authoritative settings.role enum."""

    bl_idname = "CLOTHNEXT_MT_object_type"
    bl_label = "Object Type"

    def draw(self, context):
        layout = self.layout
        obj = getattr(context, "object", None)
        settings = getattr(obj, "cloth_next", None)
        active_role = getattr(settings, "role", "")
        for identifier, label, _description in object_properties.ROLE_ITEMS:
            row = layout.row()
            row.enabled = ((identifier == "FORCE") ==
                           (getattr(obj, "type", "") == "EMPTY"))
            if getattr(obj, "type", "") == "CURVE":
                row.enabled = identifier == "ROD"
            operator = row.operator(
                physics_operators.CLOTHNEXT_OT_set_object_type.bl_idname,
                text=label, depress=identifier == active_role,
                **object_properties.role_icon_kwargs(identifier))
            operator.role = identifier
        layout.separator()
        for _identifier, label, description in UNAVAILABLE_OBJECT_TYPES:
            row = layout.row()
            row.alert = True
            row.enabled = False
            operator = row.operator(
                CLOTHNEXT_OT_unavailable_object_type.bl_idname,
                text=label, icon="LOCKED")
            operator.tooltip = description


class CLOTHNEXT_OT_add_friction_region(bpy.types.Operator):
    """Add a vertex-group row with its own collision-friction value."""
    bl_idname = "clothnext.add_friction_region"
    bl_label = "Add Friction Vertex Group"
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        settings = context.object.cloth_next
        region = settings.friction_regions.add()
        region.friction = float(settings.collision.surface_grip)
        settings.friction_region_index = len(settings.friction_regions) - 1
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_remove_friction_region(bpy.types.Operator):
    """Remove this friction-region row from the active Cloth object."""
    bl_idname = "clothnext.remove_friction_region"
    bl_label = "Remove Friction Vertex Group"
    bl_options = {"INTERNAL", "UNDO"}

    index: bpy.props.IntProperty(default=-1, options={"HIDDEN"})

    def execute(self, context):
        settings = context.object.cloth_next
        index = int(self.index)
        if not 0 <= index < len(settings.friction_regions):
            return {"CANCELLED"}
        settings.friction_regions.remove(index)
        settings.friction_region_index = max(
            0, min(index, len(settings.friction_regions) - 1))
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_add_soft_constraint(bpy.types.Operator):
    """Add a soft transform constraint targeting another object."""
    bl_idname = "clothnext.add_soft_constraint"
    bl_label = "Add Soft Constraint"
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        settings = context.object.cloth_next
        settings.soft_constraints.add()
        settings.soft_constraint_index = len(settings.soft_constraints) - 1
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_remove_soft_constraint(bpy.types.Operator):
    """Remove this soft transform constraint from the active Cloth object."""
    bl_idname = "clothnext.remove_soft_constraint"
    bl_label = "Remove Soft Constraint"
    bl_options = {"INTERNAL", "UNDO"}

    index: bpy.props.IntProperty(default=-1, options={"HIDDEN"})

    def execute(self, context):
        settings = context.object.cloth_next
        index = int(self.index)
        if not 0 <= index < len(settings.soft_constraints):
            return {"CANCELLED"}
        settings.soft_constraints.remove(index)
        settings.soft_constraint_index = max(
            0, min(index, len(settings.soft_constraints) - 1))
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_add_advanced_pin_target(bpy.types.Operator):
    """Add an independently configurable Pin Group and target object."""
    bl_idname = "clothnext.add_advanced_pin_target"
    bl_label = "Add Advanced Pin Target"
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        settings = context.object.cloth_next
        settings.advanced_pin_targets.add()
        settings.advanced_pin_target_index = \
            len(settings.advanced_pin_targets) - 1
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_remove_advanced_pin_target(bpy.types.Operator):
    """Remove this advanced Pin Group target from the active Cloth object."""
    bl_idname = "clothnext.remove_advanced_pin_target"
    bl_label = "Remove Advanced Pin Target"
    bl_options = {"INTERNAL", "UNDO"}

    index: bpy.props.IntProperty(default=-1, options={"HIDDEN"})

    def execute(self, context):
        settings = context.object.cloth_next
        index = int(self.index)
        if not 0 <= index < len(settings.advanced_pin_targets):
            return {"CANCELLED"}
        settings.advanced_pin_targets.remove(index)
        settings.advanced_pin_target_index = max(
            0, min(index, len(settings.advanced_pin_targets) - 1))
        validation_state.mark_settings_dirty(context.object)
        return {"FINISHED"}


class CLOTHNEXT_OT_add_motion_override(bpy.types.Operator):
    """Add a motion override at the current Blender timeline frame."""
    bl_idname = "clothnext.add_motion_override"
    bl_label = "Add Motion Override"
    bl_options = {"UNDO"}

    def execute(self, context):
        settings = context.object.cloth_next
        item = settings.motion_overrides.add()
        item.frame = int(context.scene.frame_current)
        settings.motion_override_index = len(settings.motion_overrides) - 1
        return {"FINISHED"}


class CLOTHNEXT_OT_remove_motion_override(bpy.types.Operator):
    """Remove this frame-specific motion override."""
    bl_idname = "clothnext.remove_motion_override"
    bl_label = "Remove Motion Override"
    bl_options = {"UNDO"}
    index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        settings = context.object.cloth_next
        if not 0 <= self.index < len(settings.motion_overrides):
            return {"CANCELLED"}
        settings.motion_overrides.remove(self.index)
        settings.motion_override_index = max(
            0, min(self.index, len(settings.motion_overrides) - 1))
        return {"FINISHED"}


def _draw_object_type_selector(layout, settings) -> None:
    """Draw a compact menu without introducing any duplicate state."""
    labels = {identifier: label for identifier, label, _ in object_properties.ROLE_ITEMS}
    row = layout.row(align=True)
    row.label(text="Object Type")
    row.menu(CLOTHNEXT_MT_object_type.bl_idname,
             text=labels.get(settings.role, settings.role.title()),
             **object_properties.role_icon_kwargs(settings.role))


def _draw_add_physics_entry(panel, context) -> None:
    """Appended to PHYSICS_PT_add; draws the Cloth NeXt add/remove entry."""
    obj = getattr(context, "object", None)
    if obj is None or obj.type not in {"MESH", "CURVE", "EMPTY"}:
        return
    settings = getattr(obj, "cloth_next", None)
    # Appended callbacks cannot access the grid created earlier by Blender (or
    # by another add-on such as FLIP Fluids). Continue it visually with the
    # next left-hand cell instead of adding an oversized full-width row.
    row = panel.layout.row(align=True)
    split = row.split(factor=0.5, align=True)
    cell = split.column(align=True)
    split.column(align=True)  # empty right-hand grid cell
    if settings is not None and settings.enabled:
        cell.operator(physics_operators.CLOTHNEXT_OT_remove_physics.bl_idname,
                      text="Cloth NeXt",
                      **icon_registry.icon_kwargs("cloth_next", "MOD_CLOTH"))
    else:
        cell.operator(physics_operators.CLOTHNEXT_OT_add_physics.bl_idname,
                      text="Cloth NeXt",
                      **icon_registry.icon_kwargs("cloth_next", "MOD_CLOTH"))


# Marks the callback so stale copies from a previous module instance (e.g.
# after a script reload that skipped unregister) can be identified and purged.
_draw_add_physics_entry._clothnext_add_entry = True


def _purge_stale_add_entries() -> None:
    """Best-effort removal of callbacks left behind by a reloaded module."""
    draw = getattr(bpy.types.PHYSICS_PT_add, "draw", None)
    for func in list(getattr(draw, "_draw_funcs", ())):
        if (getattr(func, "_clothnext_add_entry", False)
                and func is not _draw_add_physics_entry):
            bpy.types.PHYSICS_PT_add.remove(func)


def append_add_physics_entry() -> None:
    """Append the draw callback exactly once."""
    global _add_entry_appended
    if _add_entry_appended:
        return
    _purge_stale_add_entries()
    bpy.types.PHYSICS_PT_add.append(_draw_add_physics_entry)
    _add_entry_appended = True


def remove_add_physics_entry() -> None:
    global _add_entry_appended
    if not _add_entry_appended:
        return
    bpy.types.PHYSICS_PT_add.remove(_draw_add_physics_entry)
    _add_entry_appended = False


class CLOTHNEXT_PT_physics(bpy.types.Panel):
    """Main Cloth NeXt panel in the Physics Properties tab."""

    bl_label = f"Cloth NeXt  v{manifest_version()}"
    bl_idname = "CLOTHNEXT_PT_physics"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"

    def draw_header(self, context):
        from . import addon_update_operators
        addon_update_operators.request_automatic_update_check(context)
        self.layout.label(
            text="",
            **icon_registry.icon_kwargs("cloth_next", "MOD_CLOTH"))
        update_session = addon_update_operators.session()
        if (update_session.state in
                addon_update_operators.addon_updates.ACTIONABLE_STATES):
            latest = getattr(update_session, "latest", None)
            text = addon_update_operators.addon_updates.build_section_view(
                update_session.state, latest, "").status_text
            self.layout.label(
                text=text,
                **icon_registry.icon_kwargs("warning", "ERROR"))

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        if obj is None or obj.type not in {"MESH", "CURVE", "EMPTY"}:
            return False
        settings = getattr(obj, "cloth_next", None)
        return settings is not None and settings.enabled

    def draw(self, context):
        layout = self.layout
        settings = context.object.cloth_next
        layout.use_property_split = True
        layout.use_property_decorate = False
        _draw_object_type_selector(layout, settings)
        if settings.role in {
                "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER",
                "FORCE"}:
            return
        from . import addon_update_operators
        addon_update_operators.request_automatic_update_check(context)
        update_session = addon_update_operators.session()
        update_view = addon_update_operators.addon_updates.build_section_view(
            update_session.state, update_session.latest,
            update_session.message)
        version = layout.row(align=True)
        version.label(
            text=f"Version: {addon_update_operators.INSTALLED_VERSION}",
            icon="PACKAGE")
        update_icon = ("ERROR" if update_session.state in
                       addon_update_operators.addon_updates.ACTIONABLE_STATES
                       else "CHECKMARK" if update_session.state is
                       addon_update_operators.AddonUpdateState.UP_TO_DATE
                       else "INFO")
        version.label(text=update_view.status_text, icon=update_icon)
        snapshot = shared_controller.snapshot()
        box = layout.box()
        col = box.column(align=True)
        role_icon = settings.role.lower() if settings.role in {
            "CLOTH", "COLLIDER", "FORCE"} else "cloth_next"
        col.label(text=f"{context.object.name} · {settings.role.title()}",
                  **icon_registry.icon_kwargs(role_icon,"OBJECT_DATA"))
        state_icon=("error" if snapshot.error_summary else "solver" if snapshot.active
                    else "success" if snapshot.state.value=="FINISHED" else "warning")
        col.label(text=f"Bake: {snapshot.status_title}",
                  **icon_registry.icon_kwargs(state_icon,"INFO"))
        if snapshot.preview:
            col.label(text="UI PREVIEW — no simulation", **icon_registry.icon_kwargs("info", "INFO"))
        if snapshot.error_summary:
            col.label(text=snapshot.error_summary, **icon_registry.icon_kwargs("error", "ERROR"))
        layout.operator(physics_operators.CLOTHNEXT_OT_remove_physics.bl_idname,
                        text="Remove Cloth NeXt", **icon_registry.icon_kwargs("remove", "X"))


class CLOTHNEXT_PT_empty_force(bpy.types.Panel):
    """Guaranteed Cloth NeXt entry for Emptys in Object Data Properties."""

    bl_label = "Cloth NeXt Force"
    bl_idname = "CLOTHNEXT_PT_empty_force"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return obj is not None and obj.type == "EMPTY"

    def draw_header(self, _context):
        self.layout.label(
            text="", **icon_registry.icon_kwargs("force", "FORCE_FORCE"))

    def draw(self, context):
        layout = self.layout
        obj = context.object
        settings = getattr(obj, "cloth_next", None)
        if settings is None:
            layout.label(text="Cloth NeXt is not registered", **icon_registry.icon_kwargs("error", "ERROR"))
            return
        if not settings.enabled:
            layout.operator(
                physics_operators.CLOTHNEXT_OT_add_physics.bl_idname,
                text="Enable Cloth NeXt Force", **icon_registry.icon_kwargs("force", "FORCE_FORCE"))
            return
        layout.use_property_split = True
        layout.use_property_decorate = True
        _draw_object_type_selector(layout, settings)
        _draw_complete_force_controls(
            layout, settings, direction_prefix="Empty ")
        layout.operator(
            physics_operators.CLOTHNEXT_OT_remove_physics.bl_idname,
            text="Remove Cloth NeXt", **icon_registry.icon_kwargs("remove", "X"))


class _ClothNextSubpanel:
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"
    bl_parent_id = "CLOTHNEXT_PT_physics"
    header_icon = "cloth_next"

    def draw_header(self, _context):
        self.layout.label(text="", **icon_registry.icon_kwargs(self.header_icon, "DOT"))

    @classmethod
    def poll(cls, context):
        if not CLOTHNEXT_PT_physics.poll(context):
            return False
        role = context.object.cloth_next.role
        roles = getattr(cls, "roles", None)
        if role == "FORCE":
            if roles is not None:
                return role in roles
            return bool(getattr(cls, "force_only", False))
        if getattr(cls, "force_only", False):
            return False
        if roles is not None:
            return role in roles
        if getattr(cls, "cloth_only", False):
            return role == "CLOTH"
        if getattr(cls, "deformable_only", False):
            return role in {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
        return True


class CLOTHNEXT_PT_solver(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Solver"; bl_idname = "CLOTHNEXT_PT_solver"
    header_icon = "solver"
    @classmethod
    def poll(cls, context):
        return (super().poll(context)
                and context.object.cloth_next.role not in {
                    "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER"})
    def draw(self, context):
        from . import solver_test
        layout = self.layout
        status = _active_backend_status(context)
        header = layout.column(align=True)
        header.label(text="Simulation Solver",
                     **icon_registry.icon_kwargs("solver", "SETTINGS"))
        if not status.ready:
            header.label(text=status.title)
            layout.operator("clothnext.open_preferences",
                            text="Open Add-on Preferences")

        model = _bake_panel_model(context, status)
        snapshot = shared_controller.snapshot()
        action = layout.row(align=True)
        split = action.split(factor=0.86, align=True)
        # Use columns as the split's direct children so both operators fill
        # their allocated width. An aligned child row shrink-wraps the folder
        # operator to its icon and leaves part of the panel visibly unused.
        bake_button = split.column(align=True)
        bake_button.scale_y = 1.6
        bake_button.enabled = model.enabled and not snapshot.active
        bake_button.operator("clothnext.bake", text=bake_button_text(context, model),
                             **bake_button_icon(context))
        # Small folder button on the right sets the Cache Directory. It stays
        # enabled even when Bake is disabled for a missing directory, so the
        # artist can satisfy the requirement without leaving the panel.
        set_dir = split.column(align=True)
        set_dir.scale_y = 1.6
        set_dir.enabled = not snapshot.active
        set_dir.operator("clothnext.set_cache_directory", text="",
                         **icon_registry.icon_kwargs("folder", "FILE_FOLDER"))
        if not snapshot.active:
            warning = _animated_collider_capture_warning(context, solver_test)
            if warning is not None:
                warning_row = layout.row()
                warning_row.alert = True
                warning_row.label(
                    text=(f'Large animated Collider capture: '
                          f'~{warning.size_label}'), icon="ERROR")
                layout.label(
                    text="Bake allowed · Low-poly collision proxy recommended.")
            contact_warning = _contact_stability_warning(context)
            if contact_warning:
                warning_row = layout.row()
                warning_row.alert = True
                warning_row.label(text=contact_warning, **icon_registry.icon_kwargs("error", "ERROR"))
                layout.label(text="Bake allowed · Try Gap 0.001 and Friction 0.2–0.3")
        if snapshot.active:
            progress_text = _run_state_text(snapshot)
            layout.label(text=progress_text)
            if snapshot.can_cancel:
                layout.operator("clothnext.bake_cancel", text="Cancel",
                                **icon_registry.icon_kwargs("cancel", "CANCEL"))
        elif model.reason:
            layout.label(text=model.reason, **icon_registry.icon_kwargs("error", "ERROR"))
        if snapshot.state.value == "ERROR" and snapshot.error_summary:
            layout.operator("clothnext.companion_open_logs", text="Open Logs",
                            **icon_registry.icon_kwargs("folder", "FILE_FOLDER"))
            _draw_intersection_diagnostics(
                layout, snapshot, running=solver_test.run_active())
        if not snapshot.active:
            validation = layout.row(align=True)
            validation.label(text=_validation_line(context))
            validation.operator("clothnext.validate", text="Validate",
                                **icon_registry.icon_kwargs("validate",
                                                            "CHECKMARK"))
        summary = layout.column(align=True)
        summary.label(text=model.summary_line)
        try:
            cloth, _ = solver_test._enabled_objects_for_bake(context)
            start, end = cloth.cloth_next.bake_start, cloth.cloth_next.bake_end
            summary.label(text=f"Frames {start}–{end} · {end-start+1} cached "
                               f"frames · {model.cache_label}")
        except solver_test.SceneValidationError:
            summary.label(text=model.cache_label)
        _draw_solver_quality(layout, context, snapshot.active)


def _draw_quality_buttons(layout, context, bake_active: bool):
    has_pdrd = physics_operators.scene_has_pdrd(context.scene)
    current = matching_quality_preset(
        object_properties.solver_quality_from(context.scene),
        has_pdrd=has_pdrd)
    buttons = layout.row(align=True)
    buttons.enabled = not bake_active
    if has_pdrd:
        low = buttons.row(align=True)
        low.enabled = False
        low.operator(
            physics_operators.QUALITY_PRESET_OPERATOR_IDS["LOW"], text="Low")
        presets = PDRD_QUALITY_PRESETS[1:]
        operator_ids = physics_operators.PDRD_QUALITY_PRESET_OPERATOR_IDS
    else:
        presets = QUALITY_PRESETS
        operator_ids = physics_operators.QUALITY_PRESET_OPERATOR_IDS
    for preset in presets:
        button = buttons.row(align=True)
        button.alert = preset.identifier == "EXTREME"
        button.operator(
            operator_ids[preset.identifier],
            text=preset.label,
            depress=current is preset)
    return current


def _draw_solver_quality(layout, context, bake_active: bool) -> None:
    if _aether_selected(context):
        layout.label(text="AETHER Engine presets: see the AETHER Engine panel")
        return
    quality = getattr(context.scene, "cloth_next_quality", None)
    if quality is None:
        return
    section = layout.column(align=True)
    section.label(text="Solver Quality · Scene-wide")
    current = _draw_quality_buttons(section, context, bake_active)
    if current is None:
        section.label(text="Custom")
        section.label(text="Manually adjusted solver settings.")
    else:
        section.label(text=current.label)
        section.label(text=current.description)
        if current.warning:
            section.label(text=current.warning, **icon_registry.icon_kwargs("error", "ERROR"))

    foldout = section.row(align=True)
    foldout.prop(quality, "show_advanced", text="Advanced Settings",
                 icon="TRIA_DOWN" if quality.show_advanced else "TRIA_RIGHT",
                 emboss=False)
    if quality.show_advanced:
        advanced = section.column(align=True)
        advanced.enabled = not bake_active
        advanced.use_property_split = True
        advanced.use_property_decorate = False
        advanced.label(text="Advanced Solver")
        advanced.prop(quality, "time_step")
        advanced.prop(quality, "min_newton_steps")
        advanced.prop(quality, "cg_max_iter")
        advanced.prop(quality, "cg_tol")


@dataclass(frozen=True, slots=True)
class _SolverStatus:
    ready: bool
    title: str
    details: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class _BakePanelModel:
    enabled: bool
    action: str
    reason: str
    summary_line: str
    cache_label: str


def _solver_status(context) -> _SolverStatus:
    """Non-blocking readiness view; never probes or displays a local path."""
    from . import solver_test
    plan = solver_test._active_plan
    if plan is not None:
        resolved = plan.resolved
        details = tuple(value for value in (
            f"Package {resolved.package_version}" if resolved.package_version else "",
            f"Protocol {resolved.protocol_version}" if resolved.protocol_version else "",
            f"Schema {resolved.schema_version}" if resolved.schema_version else "",
            resolved.mode.name.replace("_", " ").title(),
        ) if value)
        protocol = resolved.protocol_version or "unknown"
        return _SolverStatus(True, f"Ready · Protocol {protocol}", details)
    try:
        prefs = addon_preferences(context, __package__)
        raw = str(prefs.external_solver_path or "").strip()
    except (KeyError, AttributeError):
        prefs = None
        raw = ""
    # The installation registry is the authority for the side-by-side solver
    # manager. Check it before the legacy single-installation pointer: a
    # A registered side-by-side release need not own legacy ``current.json``.
    try:
        from ..updater.install_paths import ManagedSolverPaths
        from ..updater.solver_registry import load_registry
        registry = load_registry(ManagedSolverPaths.default().registry_json)
        requested = registry.selected_installation_id or ""
        if requested:
            installation = registry.get(requested)
            if installation is None or not installation.available:
                return _SolverStatus(False, "Selected solver is missing")
            if not (installation.compatible and installation.verified
                    and installation.healthy):
                return _SolverStatus(False, "Selected solver is unavailable")
            details = tuple(value for value in (
                (f"Package {installation.package_version}"
                 if installation.package_version else ""),
                (f"Protocol {installation.protocol_version}"
                 if installation.protocol_version else ""),
                (f"Schema {installation.schema_version}"
                 if installation.schema_version else ""),
                ("Managed installation" if installation.managed
                 else "External installation"),
            ) if value)
            protocol = installation.protocol_version or "unknown"
            return _SolverStatus(
                True, f"Ready Â· Protocol {protocol}", details)
        if registry.installations:
            return _SolverStatus(False, "No Solver Selected")
    except (OSError, ValueError):
        return _SolverStatus(False, "Solver registry unavailable")
    if raw:
        root = Path(raw)
        configured = root.is_file() or root.is_dir()
        return _SolverStatus(configured,
                             "External installation" if configured
                             else "Solver unavailable")
    try:
        from ..updater.install_paths import ManagedSolverPaths, read_current
        paths = ManagedSolverPaths.default()
        active = read_current(paths)
        if active is not None and active.executable_path(paths).is_file():
            from ..updater.solver_manifest import load_bundled_manifest
            from ..platform_support import platform_spec
            entry = next((item for item in load_bundled_manifest().releases_for(
                platform_spec().solver_platform)
                if item.official_release_tag == active.official_release_tag), None)
            details = (f"Package {active.version}",
                       f"Protocol {entry.protocol_version}",
                       f"Schema {entry.schema_version}",
                       "Managed installation") if entry else (
                           f"Package {active.version}", "Managed installation")
            protocol = entry.protocol_version if entry else "unknown"
            return _SolverStatus(True, f"Ready · Protocol {protocol}", details)
    except (OSError, ValueError):
        return _SolverStatus(False, "Solver unavailable")
    development = os.environ.get("CLOTH_NEXT_PPF_EXECUTABLE", "").strip()
    if development and Path(development).is_file():
        return _SolverStatus(True, "External installation",
                             ("Development configuration",))
    return _SolverStatus(False, "Not configured")


def _active_backend_status(context) -> _SolverStatus:
    """Cheap readiness of the selected backend without discovery side effects."""
    from . import solver_backends
    status = solver_backends.backend_status(context)
    if status is not None:
        return _SolverStatus(*status)
    return _solver_status(context)


def _aether_selected(context) -> bool:
    from ..simulation.backends import BackendId
    from . import solver_backends
    return solver_backends.active_backend_id(context.scene) is BackendId.AETHER_ENGINE


def _draw_aether_section(layout, context, bake_active: bool) -> bool:
    """AETHER Engine presets, Live Simulation and Recovery; False for other backends."""
    from ..simulation.backends import BackendId
    from . import solver_backends
    if solver_backends.active_backend_id(context.scene) is not BackendId.AETHER_ENGINE:
        return False
    from . import aether_engine_backend, aether_engine_live
    settings = getattr(context.scene, "cloth_next_solver", None)
    section = layout.column(align=True)
    section.label(text="AETHER Engine · experimental")
    if settings is not None:
        row = section.row(align=True)
        row.enabled = not bake_active
        row.prop(settings, "aether_bake_quality", text="Bake")
        row = section.row(align=True)
        row.enabled = not aether_engine_live.is_running()
        row.prop(settings, "aether_live_quality", text="Live")
        if hasattr(settings, "aether_fit_pose"):
            row = section.row(align=True)
            row.enabled = not bake_active
            row.prop(settings, "aether_fit_pose", text="Start from Fit Pose")
            if settings.aether_fit_pose:
                sub = row.row(align=True)
                sub.prop(settings, "aether_fit_frame", text="Frame")
                sub.prop(settings, "aether_fit_transition", text="Over")
    for note in aether_engine_backend.not_enforced_notes(context)[:3]:
        layout.label(text=note.split(" (", 1)[0] + " · not enforced by AETHER", icon="INFO")
    live = layout.row(align=True)
    if aether_engine_live.is_running():
        live.operator("clothnext.aether_live_toggle_pause",
                      text="Resume" if aether_engine_live.is_paused() else "Pause",
                      icon="PLAY" if aether_engine_live.is_paused() else "PAUSE")
        live.operator("clothnext.aether_live_reset", text="Reset", icon="FILE_REFRESH")
        live.operator("clothnext.aether_live_stop", text="Stop & Keep", icon="PINNED")
        layout.label(text="Grab Cloth: drag the cloth with the left mouse button in the 3D View", icon="VIEW_PAN")
        layout.label(text=aether_engine_live.status_line())
    else:
        live.enabled = not bake_active
        from . import aether_drape
        draped = any(aether_drape.drape_block(o) is not None for o in context.scene.objects
                     if getattr(o, "type", "") == "MESH")
        live.operator("clothnext.aether_live_start", text="Continue Live Simulation" if draped
                      else "Start Live Simulation", icon="PLAY")
        if draped:
            live.operator("clothnext.aether_clear_drape", text="Clear Drape", icon="LOOP_BACK")
    if not bake_active and aether_engine_backend.recovery_available(context):
        box = layout.box()
        box.label(text="An AETHER bake was interrupted", icon="RECOVER_LAST")
        row = box.row(align=True)
        row.operator("clothnext.aether_resume_bake", text="Resume Bake")
        row.operator("clothnext.aether_discard_recovery", text="Discard")
    return True


def _cache_state(context) -> tuple[str, str]:
    """Cheap, honest cache view. Never hashes a mesh and never scans pins.

    The settings half of the Bake fingerprint is recomputable for free, so
    "the settings changed" is stated as fact. The geometry half is not, so
    until a full validation confirms it this reports "needs validation"
    rather than claiming the cache safely matches.
    """
    from . import solver_test
    try:
        cloth, _collider = solver_test._enabled_objects_for_bake(context)
    except solver_test.SceneValidationError:
        return "EMPTY", "Cache empty"
    settings = cloth.cloth_next
    # Marker-only check: no Path.resolve(), so no filesystem syscall in draw.
    modifier = next((mod for mod in cloth.modifiers
                     if has_cloth_next_playback_marker(cloth, mod)), None)
    rod_cache = (str(getattr(cloth.data, "get", lambda *_: "")(
        "cloth_next_rod_cache", "") or "") if cloth.type == "CURVE" else "")
    baked_settings = getattr(settings, "baked_settings_fingerprint", "")
    if (modifier is None and not rod_cache) or not baked_settings:
        return "EMPTY", "Cache empty"
    from . import solver_backends
    baked_backend = str(getattr(settings, "baked_solver_backend", "") or "PPF")
    if baked_backend != solver_backends.active_backend_id(context.scene).value:
        return "STALE", "Cache stale · solver changed"

    disk_condition = str(getattr(settings, "baked_cache_condition", "") or "")
    disk_message = str(getattr(settings, "baked_cache_message", "") or "")
    if disk_condition == "CORRUPT":
        return "INVALID", disk_message or "Cache invalid · file damaged"
    if disk_condition == "PARTIAL":
        return "INVALID", disk_message or "Cache incomplete · Rebake required"
    if disk_condition == "MISSING":
        return "INVALID", disk_message or "Cache invalid · files missing"

    record = validation_state.record_for(cloth)
    if record.state is validation_state.ValidationState.INVALID:
        return "INVALID", f"Cache invalid · {record.message}" if record.message \
            else "Cache invalid · topology mismatch"

    # A result baked before the fingerprint was split carries no geometry half.
    # It is never presented as matching; it has to be validated first.
    version = int(getattr(settings, "baked_fingerprint_version", 0) or 0)
    baked_geometry = getattr(settings, "baked_geometry_fingerprint", "")
    if version != solver_test.BAKE_FINGERPRINT_VERSION or not baked_geometry:
        return "NEEDS_VALIDATION", "Cache needs validation · mesh may have changed"

    current_settings = solver_backends.backend_settings_key(
        context, solver_test.cheap_settings_fingerprint(context))
    if current_settings is None or current_settings != baked_settings:
        return "STALE", "Cache stale · settings changed"

    if record.state is validation_state.ValidationState.VALID:
        if record.geometry_fingerprint == baked_geometry:
            return "MATCHING", "Cache ready"
        return "STALE", "Cache stale · mesh changed"
    return "NEEDS_VALIDATION", "Cache needs validation · mesh may have changed"


_VALIDATION_TITLES = {
    validation_state.ValidationState.UNKNOWN: "Ready to validate and bake",
    validation_state.ValidationState.DIRTY: "Scene validation required",
    validation_state.ValidationState.VALIDATING: "Validating scene…",
    validation_state.ValidationState.VALID: "Scene validated",
}


def _validation_line(context) -> str:
    """One recorded status string. Computes nothing."""
    obj = getattr(context, "object", None)
    record = validation_state.record_for(obj)
    if record.state is validation_state.ValidationState.INVALID:
        return record.message or "Scene validation failed"
    return _VALIDATION_TITLES.get(record.state, "Ready to validate and bake")


def _bake_panel_model(context, solver_status: _SolverStatus | None = None) \
        -> _BakePanelModel:
    """Enable/disable the Bake button from cheap state only.

    Obviously invalid *cheap* states (no solver, wrong object counts, an
    animated collider, a broken frame range, an invalid mapped material value,
    a missing pin group) disable the button immediately. Everything that needs
    the mesh — topology, pin indices — is validated when Bake is clicked, not
    on every redraw. A previously recorded INVALID verdict remains visible,
    but never disables retry: otherwise correcting a scene could leave the
    artist permanently locked out of the validation path.
    """
    from . import solver_test
    status = solver_status or _solver_status(context)
    objects = getattr(getattr(context, "scene", None), "objects", ())
    cloths = [obj for obj in objects if getattr(getattr(obj, "cloth_next", None),
                                                "enabled", False)
              and obj.cloth_next.role in {
                  "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}]
    colliders = [obj for obj in objects if getattr(getattr(obj, "cloth_next", None),
                                                   "enabled", False)
                 and obj.cloth_next.role == "COLLIDER"]
    role = (cloths[0].cloth_next.role if len(cloths) == 1
            else "MULTI" if cloths else "")
    preset = (cloths[0].cloth_next.material.preset.replace("_", " ").title()
              if role == "CLOTH" else "Multi Object" if role == "MULTI"
              else role.replace("_", " ").title() if role else "No material")
    summary = f"{preset} · {len(cloths)} Deformable · {len(colliders)} Collider"
    cache_state, cache_label = _cache_state(context)
    action = {"STALE": "REBAKE", "INVALID": "REBAKE",
              "NEEDS_VALIDATION": "REBAKE",
              "MATCHING": "BAKE AGAIN"}.get(cache_state, "BAKE")
    reason = ""
    if not status.ready:
        from ..simulation.backends import BackendId
        from . import solver_backends
        reason = ("The simulation solver is not configured."
                  if solver_backends.active_backend_id(context.scene)
                  is BackendId.PPF else status.title)
    elif not cloths:
        reason = "At least one deformable object is required."
    else:
        from . import solver_backends
        reason = solver_backends.unsupported_reason(context.scene)
    if not reason and cloths:
        try:
            from ..bake.frame_range import BakeFrameRange
            ranges = {(int(obj.cloth_next.bake_start),
                       int(obj.cloth_next.bake_end)) for obj in cloths}
            if len(ranges) != 1:
                details = ", ".join(
                    f"{obj.name}: {int(obj.cloth_next.bake_start)}–"
                    f"{int(obj.cloth_next.bake_end)}" for obj in cloths)
                raise ValueError(f"Bake ranges differ · {details}")
            BakeFrameRange(*next(iter(ranges)))
            contacts = {bool(obj.cloth_next.collision.enabled)
                        for obj in cloths}
            if len(contacts) != 1:
                raise ValueError(
                    "All deformables need the same Enable Contact setting.")
            # Property-only validation: touches no mesh.
            for obj in cloths:
                solver_test._snapshot_materials(
                    obj, colliders[0] if colliders else None)
        except Exception as exc:  # noqa: BLE001 — an invalid value stays visible
            reason = str(exc) or "Material settings are invalid."
        else:
            for obj in cloths:
                reason = _cheap_pin_reason(solver_test, obj)
                if reason:
                    break
    # A production bake requires a chosen cache folder so the result is not
    # written to the temp directory and lost on the next Blender launch. Kept
    # last so more fundamental problems surface first.
    if not reason and cloths and any(
            not str(getattr(obj.cloth_next, "cache_directory", "") or "").strip()
            for obj in cloths):
        reason = ("Set a Cache Directory (folder button next to Bake) so the "
                  "result survives a Blender restart.")
    location = bake_location(context)
    if not reason and location == "CLOUD":
        from ..cloud import service
        # Never a silent fallback to this computer (concept 12.1).
        status = service.availability()
        if not status.available:
            reason = status.reason or "Cloud Bakes are not available right now."
    return _BakePanelModel(not reason, action, reason, summary, cache_label)


def bake_location(context) -> str:
    try:
        from .addon_identity import addon_preferences
        return str(addon_preferences(context, __package__).bake_location)
    except (KeyError, AttributeError, TypeError):
        return "LOCAL"


def bake_button_icon(context) -> dict:
    """Croissant for This Computer, cloud for Cloud."""
    if bake_location(context) == "CLOUD":
        return icon_registry.icon_kwargs("cloud", "WORLD")
    return icon_registry.icon_kwargs("bake", "RENDER_ANIMATION")


def bake_button_text(context, model) -> str:
    where = "Cloud" if bake_location(context) == "CLOUD" else "This Computer"
    return f"{model.action.title()} · {where}"


def _animated_collider_capture_warning(context, solver_test):
    """Cheap panel warning; malformed scene state is handled by Bake itself."""
    try:
        deformables, colliders = solver_test._enabled_objects_for_solve(context)
        ranges = {(int(obj.cloth_next.bake_start),
                   int(obj.cloth_next.bake_end)) for obj in deformables}
        if len(ranges) != 1:
            return None
        from ..bake.frame_range import BakeFrameRange
        bake_range = BakeFrameRange(*next(iter(ranges)))
        return solver_test.animated_collider_capture_warning(
            colliders, bake_range)
    except Exception:  # noqa: BLE001 - Panel.draw must remain failure-safe
        return None


def _contact_stability_warning(context) -> str:
    """Warn without overriding deliberate, scale-dependent contact values."""
    objects = getattr(getattr(context, "scene", None), "objects", ())
    deformables = [obj for obj in objects
        if getattr(getattr(obj, "cloth_next", None), "enabled", False)
        and obj.cloth_next.role in {
            "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}]
    if not deformables or not any(
            bool(obj.cloth_next.collision.enabled) for obj in deformables):
        return ""
    for obj in objects:
        settings = getattr(obj, "cloth_next", None)
        if (settings is None or not bool(getattr(settings, "enabled", False))
                or getattr(settings, "role", "") != "COLLIDER"):
            continue
        collision = settings.collision
        if (float(collision.collision_gap) >= 0.01
                and float(collision.surface_grip) >= 0.4):
            return "High Collision Gap and Friction can destabilize pinned Cloth."
    return ""


def _cheap_pin_reason(solver_test, cloth) -> str:
    """Pin problems detectable without reading a single vertex."""
    summary = solver_test.cheap_pin_summary(cloth)
    if not summary.enabled:
        return ""
    if not summary.group_name:
        return "Select a Pin Group."
    if not summary.group_exists:
        return "The selected Pin Group no longer exists."
    return ""


def _run_state_text(snapshot) -> str:
    if snapshot.state.value == "SIMULATING" and snapshot.current_frame is not None:
        return f"Simulating {snapshot.current_frame} / {snapshot.frame_end}"
    title = snapshot.status_title
    return title if snapshot.state.value in {"FINISHED", "CANCELLED", "ERROR"} \
        else title + "…"


def _preset_description(identifier: str) -> str:
    for item_id, _label, description in object_properties.PRESET_ITEMS:
        if item_id == identifier:
            return description
    return ""


def _preset_label(identifier: str) -> str:
    preset = material_presets.preset_by_identifier(identifier)
    if preset is not None:
        return preset.label
    return material_presets.CUSTOM_LABEL


def _draw_concept_row(layout, label: str) -> None:
    """Draw an inert future-facing row without editable state."""
    row = layout.row(align=True)
    row.label(text=label, icon="TRIA_RIGHT")
    row.label(text="◇")


def _draw_frame_range(layout, settings) -> None:
    section = layout.column(align=True)
    section.label(text="Frame Range")
    section.prop(settings, "bake_start", text="Start")
    section.prop(settings, "bake_end", text="End")
    section.operator("clothnext.use_scene_range", text="Use Scene Range")


def _draw_force_setup(layout, settings) -> None:
    """Draw the complete, fully encoded Force control set."""
    _draw_complete_force_controls(layout, settings)


def _draw_complete_force_controls(
        layout, settings, *, direction_prefix: str = "") -> None:
    """Draw every Force type directly, without an active-type selector."""
    force = settings.force
    vector = layout.box().column(align=True)
    vector.label(text="Gravity", icon="WORLD")
    vector.prop(force, "gravity_strength", text="Gravity")
    vector.prop(force, "gravity_axis", text="Gravity Axis")
    wind = layout.box().column(align=True)
    wind.label(text="Wind Field", icon="FORCE_WIND")
    wind.prop(force, "wind_strength", text="Speed")
    wind.prop(force, "wind_radius", text="Radius")
    wind.prop(force, "wind_falloff", text="Falloff", slider=True)
    wind.separator()
    wind.label(text=f"Direction · {direction_prefix}local +Z", icon="ORIENTATION_LOCAL")
    wind.label(text="Move and rotate the Empty to aim Wind")
    motion = layout.box().column(align=True)
    motion.label(text="Gusts & Turbulence", icon="FORCE_TURBULENCE")
    motion.prop(force, "wind_variation", text="Gust Strength")
    motion.prop(force, "wind_noise_scale", text="Motion Timing")
    motion.separator()
    motion.prop(force, "wind_turbulence", text="Swirl Strength")
    motion.prop(force, "wind_turbulence_size", text="Swirl Size")
    obstacles = layout.box().column(align=True)
    obstacles.label(text="Obstacle Response", icon="MOD_PHYSICS")
    obstacles.prop(force, "wind_obstacles", text="Geometry")
    if force.wind_obstacles != 'NONE':
        obstacles.prop(force, "wind_wake_strength", text="Wake Strength", slider=True)
        obstacles.prop(force, "wind_wake_length", text="Wake Length")
    preview = layout.box().column(align=True)
    preview.label(text="Preview & Quality", icon="HIDE_OFF")
    preview.prop(force, "wind_show_vectors", text="Show Vectors")
    if force.wind_show_vectors:
        preview.prop(force, "wind_vector_scale", text="Arrow Scale")
        preview.label(text="Scrub or play the timeline to preview Wind")
    preview.prop(force, "wind_resolution", text="Field Resolution")
    environment = layout.box().column(align=True)
    environment.label(text="Air Response", icon="PHYSICS")
    environment.prop(force, "air_density", text="Air Density")
    environment.prop(force, "air_friction", text="Air Friction")
    environment.prop(force, "vertex_air_damp", text="Vertex Air Damping")
    if (force.wind_strength > 0.0 or force.wind_variation > 0.0 or force.wind_turbulence > 0.0) and force.air_density <= 0.001:
        warning = layout.box()
        warning.alert = True
        warning.label(text="Wind needs a higher Air Density", icon="ERROR")
        warning.label(text="Use 0.01 for visible aerodynamic force")
    layout.label(text="Properties and rotation can be keyframed")


def _authoritative_frame_settings(context):
    """Return a deformable's synchronized range without inspecting geometry."""
    for obj in getattr(getattr(context, "scene", None), "objects", ()):
        settings = getattr(obj, "cloth_next", None)
        if (settings is not None and bool(getattr(settings, "enabled", False))
                and getattr(settings, "role", "") in {
                    "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}):
            return settings
    return context.object.cloth_next


def _scene_role_counts(context) -> dict[str, int]:
    """Count enabled roles from object settings only; never inspect meshes."""
    counts = {role: 0 for role, _label, _description
              in object_properties.ROLE_ITEMS}
    for obj in getattr(getattr(context, "scene", None), "objects", ()):
        settings = getattr(obj, "cloth_next", None)
        if settings is None or not bool(getattr(settings, "enabled", False)):
            continue
        role = getattr(settings, "role", "")
        if role in counts:
            counts[role] += 1
    return counts


def _scene_counts(context) -> tuple[int, int, int]:
    counts = _scene_role_counts(context)
    deformables = sum(counts[role] for role in (
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"))
    return deformables, counts["COLLIDER"], counts["FORCE"]


def _draw_scene_statistics(layout, context) -> None:
    deformables, colliders, forces = _scene_counts(context)
    role = context.object.cloth_next.role
    if role == "RIGID_BODY":
        counts = _scene_role_counts(context)
        rigid_bodies = counts["RIGID_BODY"]
        other_deformables = deformables - rigid_bodies
        rigid_label = "Rigid Body" if rigid_bodies == 1 else "Rigid Bodies"
        collider_label = "Collider" if colliders == 1 else "Colliders"
        text = (f"{rigid_bodies} {rigid_label} · "
                f"{other_deformables} Deformables · "
                f"{colliders} {collider_label}")
    elif role in {"ROD", "SOFT_BODY", "COLLIDER", "FORCE"}:
        collider_label = "Collider" if colliders == 1 else "Colliders"
        force_label = "Force" if forces == 1 else "Forces"
        text = (f"{deformables} Deformables · {colliders} {collider_label} · "
                f"{forces} {force_label}")
    else:
        text = (f"{deformables} Deformables · {colliders} Collider · "
                f"{forces} Forces")
    layout.label(text=text)
    settings = (_authoritative_frame_settings(context)
                if role in {"COLLIDER", "FORCE"}
                else context.object.cloth_next)
    layout.label(text=f"Frames {settings.bake_start}–{settings.bake_end}")


def _draw_quality_selector(layout, context, bake_active: bool) -> None:
    if _aether_selected(context):
        layout.label(text="AETHER Engine presets: see the AETHER Engine panel")
        return
    quality = getattr(context.scene, "cloth_next_quality", None)
    if quality is None:
        return
    layout.label(text="Quality")
    _draw_quality_buttons(layout, context, bake_active)


def _draw_bake_action(layout, context, model, snapshot) -> None:
    if snapshot.active:
        layout.label(text="Bake running in Cloth NeXt Bake Window")
        cancel = layout.row()
        cancel.enabled = snapshot.can_cancel
        cancel.operator("clothnext.bake_cancel", text="Cancel Bake",
                        **icon_registry.icon_kwargs("cancel", "CANCEL"))
        return
    action = layout.row(align=True)
    split = action.split(factor=0.86, align=True)
    bake_button = split.column(align=True)
    bake_button.scale_y = 1.6
    bake_button.enabled = model.enabled
    bake_button.operator("clothnext.bake", text=bake_button_text(context, model),
                         **bake_button_icon(context))
    set_dir = split.column(align=True)
    set_dir.scale_y = 1.6
    set_dir.operator("clothnext.set_cache_directory", text="",
                     icon="FILE_FOLDER")
    if model.reason:
        layout.label(text=model.reason, icon="ERROR")


def _draw_recovery_banner(layout, context, snapshot) -> None:
    """Compact durable-Recovery state in the primary Simulation workflow."""
    settings = getattr(getattr(context, "scene", None),
                       "cloth_next_recovery", None)
    if settings is None or not bool(getattr(settings, "enabled", False)):
        return
    status = str(getattr(settings, "status", "") or "")
    frame = int(getattr(settings, "latest_checkpoint_frame", 0) or 0)
    banner = layout.box()
    if status == "Checking for Recovery":
        banner.label(text="Checking for Recovery", icon="TIME")
        return
    if status in {"Recovery Check Failed", "Recovery Metadata Invalid",
                  "Recovery Incompatible", "Recovery Project Missing"}:
        banner.alert = True
        banner.label(text=status, icon="ERROR")
        detail = str(getattr(settings, "status_detail", "") or "")
        if detail:
            banner.label(text=detail)
        banner.operator("clothnext.companion_open_logs",
                        text="Open Diagnostics", icon="FILE_FOLDER")
        return
    if bool(getattr(settings, "resumable", False)):
        # Compatibility is deliberately not shown as green until Bake start
        # has recomputed the complete current identity.
        banner.label(
            text=(f"Recovery checkpoint found \u00b7 Frame {frame}"
                  if frame > 0 else "Recovery checkpoint found"),
            icon="INFO")
        if not bool(getattr(settings, "compatible", False)):
            banner.label(text="Compatibility will be verified before Resume",
                         icon="QUESTION")
        actions = banner.row(align=True)
        resume = actions.row(align=True)
        resume.enabled = not snapshot.active
        resume.operator("clothnext.recovery_resume_latest",
                        text="Resume Bake", icon="PLAY")
        fresh = actions.row(align=True)
        fresh.enabled = not snapshot.active
        fresh.operator("clothnext.recovery_start_fresh",
                       text="Start Fresh", icon="FILE_REFRESH")
        return
    banner.label(text="No Recovery Checkpoint", icon="INFO")


def _draw_soft_body_material(layout, settings) -> None:
    """Draw only fully mapped solid-material controls."""
    model = layout.row(align=True)
    model.label(text="Solver Model")
    model.label(text="ARAP")
    soft = settings.soft_body
    layout.prop(soft, "appear_solid")
    layout.prop(soft, "volume_density")
    deformation = layout.column(align=True)
    deformation.enabled = not getattr(soft, "appear_solid", False)
    deformation.prop(soft, "stretch_resistance", text="Stretch Resistance")
    deformation.prop(soft, "poisson_ratio", text="Sideways Response")
    deformation.prop(soft, "volume_scale", text="Volume Scale")
    layout.prop(soft, "tetrahedralizer")
    damping = layout.column(align=True)
    damping.enabled = not getattr(soft, "appear_solid", False)
    damping.label(text="Damping")
    damping.prop(settings.damping, "shape_damping")
    permanent = layout.column(align=True)
    permanent.enabled = not getattr(soft, "appear_solid", False)
    permanent.label(text="Permanent Deformation")
    permanent.prop(soft, "stretch_plasticity_enabled")
    controls = permanent.column(align=True)
    controls.enabled = soft.stretch_plasticity_enabled
    controls.prop(soft, "stretch_plasticity_rate")
    controls.prop(soft, "stretch_plasticity_threshold_percent")


def _draw_cable_rope_material(layout, settings) -> None:
    """Draw only fully mapped Cable / Rope material controls."""
    cable = settings.rod
    layout.prop(cable, "linear_density")
    layout.prop(cable, "stretch_resistance")
    layout.prop(cable, "bend_resistance")
    protection = layout.column(align=True)
    protection.label(text="Stretch Protection")
    protection.prop(cable, "stretch_limit_percent", text="Maximum Stretch")
    damping = layout.column(align=True)
    damping.label(text="Damping")
    damping.prop(settings.damping, "shape_damping")
    damping.prop(settings.damping, "fold_damping", text="Bend Damping")
    permanent = layout.column(align=True)
    permanent.label(text="Permanent Deformation")
    permanent.prop(cable, "bend_plasticity_enabled")
    controls = permanent.column(align=True)
    controls.enabled = cable.bend_plasticity_enabled
    controls.prop(cable, "bend_plasticity_rate")
    controls.prop(cable, "bend_plasticity_threshold_degrees")
    controls.prop(cable, "bend_rest_from_geometry")


def _draw_collider_collision(layout, settings, context=None) -> None:
    """Draw mapped Collider motion and contact controls."""
    layout.use_property_split = True
    layout.use_property_decorate = False
    from . import linked_colliders
    context = context or bpy.context
    obj = getattr(settings, "id_data", None)
    scene = getattr(context, "scene", None)
    group = linked_colliders.group_for(obj, scene) if scene is not None else None
    link_row = layout.row(align=True)
    link_row.label(text="Linked Colliders")
    link_row.operator("clothnext.pick_collider", text="", icon="EYEDROPPER")
    if group is not None:
        listing = layout.box()
        for member in linked_colliders.members(scene, group):
            row = listing.row(align=True)
            row.label(text=member.name)
            remove = row.operator("clothnext.unlink_collider", text="", icon="X")
            remove.target_name = member.name
    def shared_prop(owner, name):
        if group is None:
            layout.prop(owner, name)
        else:
            row = layout.row(align=True)
            row.label(text="", **icon_registry.icon_kwargs("link", "LINKED"))
            row.prop(group, name)
    shared_prop(settings, "collider_motion")
    if object_properties.collider_motion_from(settings) == "STATIC":
        from . import solver_test
        obj = getattr(settings, "id_data", None)
        if solver_test.static_collider_has_animation(obj):
            warning = layout.box()
            warning.alert = True
            warning.label(text="Animated Collider is set to Static", icon="ERROR")
            warning.label(text="Set Collider Motion to Animated before Bake")
    if object_properties.collider_motion_from(settings) == "ANIMATED":
        layout.prop(settings, "collider_capture_mode")
        layout.prop(settings, "collider_samples_per_frame",
                    text="Samples per Frame")
        samples = int(settings.collider_samples_per_frame)
        if samples < 8:
            layout.label(
                text="Low sampling can let fast colliders cross cloth",
                icon="ERROR")
        elif samples < 12:
            layout.label(
                text="Fast or curved motion: consider 12–16 samples",
                icon="INFO")
    collision = group or settings.collision
    shared_prop(collision, "surface_grip")
    shared_prop(collision, "collision_gap")
    shared_prop(collision, "surface_offset")


def _draw_material_category(self, context):
    selected = getattr(context.object.cloth_next.material, "preset", "")
    for preset in material_presets.presets_in_category(self.category):
        operator = self.layout.operator(
            "clothnext.apply_material_preset", text=preset.label,
            icon="CHECKMARK" if preset.identifier == selected else "NONE")
        operator.preset = preset.identifier


def _make_material_category_menu(category: str):
    class_name = f"CLOTHNEXT_MT_material_{category.lower()}"
    return type(class_name, (bpy.types.Menu,), {
        "__module__": __name__,
        "bl_idname": class_name,
        "bl_label": material_presets.CATEGORY_LABELS[category],
        "category": category,
        "draw": _draw_material_category,
    })


MATERIAL_PRESET_CATEGORY_MENUS = tuple(
    _make_material_category_menu(category)
    for category in material_presets.CATEGORY_ORDER
)


class CLOTHNEXT_MT_material_presets(bpy.types.Menu):
    """Categorized, hover-opened fabric material library."""

    bl_idname = "CLOTHNEXT_MT_material_presets"
    bl_label = "Material Presets"

    def draw(self, _context):
        for menu in MATERIAL_PRESET_CATEGORY_MENUS:
            if material_presets.presets_in_category(menu.category):
                self.layout.menu(menu.bl_idname, text=menu.bl_label)


class CLOTHNEXT_PT_setup(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Setup"
    bl_idname = "CLOTHNEXT_PT_setup"
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "setup"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if context.object.cloth_next.role == "FORCE":
            _draw_force_setup(layout, context.object.cloth_next)
            return
        _draw_frame_range(layout, _authoritative_frame_settings(context))


class CLOTHNEXT_PT_aether_engine(_ClothNextSubpanel, bpy.types.Panel):
    """AETHER Engine presets, Live Simulation and Recovery (both looks)."""
    bl_label = "AETHER Engine"
    bl_idname = "CLOTHNEXT_PT_aether_engine"
    roles = {"CLOTH", "COLLIDER"}
    header_icon = "solver"

    @classmethod
    def poll(cls, context):
        return super().poll(context) and _aether_selected(context)

    def draw(self, context):
        _draw_aether_section(self.layout, context, shared_controller.snapshot().active)


class CLOTHNEXT_PT_simulation(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Simulation"
    bl_idname = "CLOTHNEXT_PT_simulation"
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "solver"

    @classmethod
    def poll(cls, context):
        if not super().poll(context):
            return False
        try:
            return not bool(addon_preferences(context, __package__).new_look)
        except (KeyError, AttributeError):
            return True

    def draw(self, context):
        layout = self.layout
        snapshot = shared_controller.snapshot()
        if context.object.cloth_next.role not in {"COLLIDER", "FORCE"}:
            _draw_quality_selector(layout, context, snapshot.active)
        model = _bake_panel_model(context, _active_backend_status(context))
        _draw_bake_action(layout, context, model, snapshot)
        _draw_intersection_diagnostics(
            layout, snapshot, running=snapshot.active)
        _draw_recovery_banner(layout, context, snapshot)
        _draw_scene_statistics(layout, context)


class CLOTHNEXT_PT_cloud_jobs(_ClothNextSubpanel, bpy.types.Panel):
    """Cloud jobs sent from this .blend (status, download, activation)."""

    bl_label = "Cloud Jobs"
    bl_idname = "CLOTHNEXT_PT_cloud_jobs"
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "cloud"

    @classmethod
    def poll(cls, context):
        if not super().poll(context):
            return False
        if bake_location(context) == "CLOUD":
            return True
        from . import cloud_runtime, cloud_ui
        jobs = cloud_runtime.view().jobs
        return bool(jobs) and bool(cloud_ui.file_jobs(context.scene, jobs))

    def draw(self, context):
        from . import cloud_ui
        cloud_ui.draw_jobs(self.layout, scene=context.scene)


class CLOTHNEXT_PT_shape(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Shape"
    bl_idname = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY"}
    header_icon = "shape"

    def draw(self, context):
        role = context.object.cloth_next.role
        if role == "ROD":
            _draw_concept_row(self.layout, "Pinning")


class CLOTHNEXT_PT_advanced_pin_motion(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Advanced Pin Motion"
    bl_idname = "CLOTHNEXT_PT_advanced_pin_motion"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "timer"

    def draw(self, context):
        settings = context.object.cloth_next
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        table = layout.box()
        header = table.row(align=True)
        header.label(text="Pin Group")
        header.label(text="Target Object")
        header.label(text="Strength")
        header.operator(CLOTHNEXT_OT_add_advanced_pin_target.bl_idname,
                        text="", icon="ADD")
        for index, item in enumerate(settings.advanced_pin_targets):
            row = table.row(align=True)
            row.prop_search(item, "vertex_group", context.object,
                            "vertex_groups", text="")
            row.prop(item, "target", text="")
            row.prop(item, "strength", text="")
            remove = row.operator(
                CLOTHNEXT_OT_remove_advanced_pin_target.bl_idname,
                text="", icon="REMOVE")
            remove.index = index
        if not settings.advanced_pin_targets:
            table.label(text="Add a Pin Group and Target Object", icon="INFO")
        layout.label(text="Each group preserves its Bake Start offsets")


class CLOTHNEXT_PT_soft_constraints(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Soft Constraints"
    bl_idname = "CLOTHNEXT_PT_soft_constraints"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "link"

    def draw(self, context):
        settings = context.object.cloth_next
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        table = layout.box()
        header = table.row(align=True)
        header.label(text="Target Object")
        header.label(text="Constraint")
        header.label(text="Strength")
        header.operator(CLOTHNEXT_OT_add_soft_constraint.bl_idname,
                        text="", icon="ADD")
        for index, constraint in enumerate(settings.soft_constraints):
            row = table.row(align=True)
            row.prop(constraint, "target", text="")
            row.prop(constraint, "constraint_type", text="")
            row.prop(constraint, "strength", text="")
            remove = row.operator(
                CLOTHNEXT_OT_remove_soft_constraint.bl_idname,
                text="", icon="REMOVE")
            remove.index = index
        if not settings.soft_constraints:
            table.label(text="Add a Target Object constraint", icon="INFO")


class CLOTHNEXT_PT_rest_shape(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Shrink"
    bl_idname = "CLOTHNEXT_PT_rest_shape"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "rest_shape"

    def draw(self, context):
        self.layout.use_property_split = True
        pressure = context.object.cloth_next.pressure
        self.layout.prop(pressure, "shrink_percent", text="Uniform Shrink")
        column = self.layout.column(align=True)
        column.prop(pressure, "shrink_warp_percent", text="Warp")
        column.prop(pressure, "shrink_weft_percent", text="Weft")


class CLOTHNEXT_PT_soft_body_rest_shape(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Shrink"
    bl_idname = "CLOTHNEXT_PT_soft_body_rest_shape"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"SOFT_BODY"}
    header_icon = "rest_shape"

    def draw(self, context):
        self.layout.use_property_split = True
        self.layout.use_property_decorate = False
        self.layout.prop(context.object.cloth_next.soft_body, "volume_scale",
                         text="Uniform Scale")


class CLOTHNEXT_PT_cable_rope_rest_shape(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Rest Shape"
    bl_idname = "CLOTHNEXT_PT_cable_rope_rest_shape"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"ROD"}
    header_icon = "rest_shape"

    def draw(self, context):
        self.layout.use_property_split = True
        self.layout.use_property_decorate = False
        self.layout.prop(context.object.cloth_next.rod, "length_factor",
                         text="Length Scale")


class CLOTHNEXT_PT_pressure(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Pressure"
    bl_idname = "CLOTHNEXT_PT_pressure"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "pressure"

    def draw(self, context):
        pressure = context.object.cloth_next.pressure
        self.layout.use_property_split = True
        self.layout.prop(pressure, "enable_inflate")
        strength = self.layout.row()
        strength.enabled = pressure.enable_inflate
        strength.prop(pressure, "inflate_pressure", text="Pressure Strength")


class CLOTHNEXT_PT_sewing(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Sewing"
    bl_idname = "CLOTHNEXT_PT_sewing"
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "sewing"

    def draw(self, context):
        layout, scene = self.layout, context.scene
        pressure = context.object.cloth_next.pressure
        if pressure.sewing_enabled:
            # Legacy loose-edge Sewing from files before the path workflow:
            # visible only while it is on, so it can be switched off.
            box = layout.box()
            box.prop(pressure, "sewing_enabled", text="Legacy Loose-Edge Sewing")
            box.label(text="Not supported by AETHER; use Sewing definitions", icon="INFO")
        op = sewing.CLOTHNEXT_OT_edit_sewing.bl_idname
        top = layout.row(align=True)
        top.scale_y = 1.25
        top.operator(op, text="Start Sewing", icon="ADD").mode = "SEGMENT"
        top.prop(scene, "cloth_next_show_sewing", text="",
                 icon="HIDE_OFF" if scene.cloth_next_show_sewing else "HIDE_ON")
        visual = scene.cloth_next_sewing_visual
        display = layout.row(align=True)
        display.prop(visual, "ui_expanded", text="Display", emboss=False,
                     icon="TRIA_DOWN" if visual.ui_expanded else "TRIA_RIGHT")
        if visual.ui_expanded:
            column = layout.column(align=True)
            toggles = column.row(align=True)
            toggles.prop(visual, "lines", text="Lines", toggle=True)
            toggles.prop(visual, "threads", text="Threads", toggle=True)
            toggles.prop(visual, "notches", text="Notches", toggle=True)
            toggles = column.row(align=True)
            toggles.prop(visual, "lengths", text="Lengths", toggle=True)
            toggles.prop(visual, "inactive", text="Inactive", toggle=True)
            toggles.prop(visual, "xray", text="X-Ray", toggle=True)
            column.separator()
            column.prop(visual, "density")
            column.prop(visual, "opacity")
            column.prop(visual, "threshold")
            column.prop(visual, "absolute")
        objects = sewing._objects(scene)
        rows = [(index, item) for index, item in enumerate(scene.cloth_next_sewing_definitions)
                if context.object in (objects.get(str(item.source_persistent_id)),
                                      objects.get(str(item.target_persistent_id)))]
        if not rows:
            layout.label(text="No seams on this object yet", icon="INFO")
            return
        for index, item in rows:
            valid, message = sewing.seam_status(scene, index)
            selected = index == scene.cloth_next_sewing_index
            box = layout.box()
            row = box.row(align=True)
            row.prop(item, "ui_expanded", text="", emboss=False,
                     icon="TRIA_DOWN" if item.ui_expanded else "TRIA_RIGHT")
            row.prop(item, "enabled", text="")
            name = row.row(align=True)
            name.alert = not valid
            name.prop(item, "name", text="", icon="ERROR" if not valid else "NONE")
            row.prop(item, "strength", text="")
            flip = row.operator(sewing.CLOTHNEXT_OT_flip_sewing.bl_idname, text="",
                                icon="ARROW_LEFTRIGHT", depress=item.flipped)
            flip.index = index
            row.prop(item, "show_overlay", text="",
                     icon="HIDE_OFF" if item.show_overlay else "HIDE_ON")
            edit = row.operator(sewing.CLOTHNEXT_OT_select_sewing.bl_idname, text="",
                                icon="GREASEPENCIL", depress=selected)
            edit.index = index
            remove = row.operator(sewing.CLOTHNEXT_OT_remove_sewing.bl_idname,
                                  text="", icon="X")
            remove.index = index
            if not valid and message:
                box.label(text=message, icon="ERROR")
            if item.ui_expanded:
                details = box.column(align=True)
                details.label(text=f"Side A: {item.source_name} · {len(item.side_a)} vertices")
                details.label(text=f"Side B: {item.target_name} · {len(item.side_b)} vertices")
                details.label(text=f"Direction: {'reversed' if item.flipped else 'forward'}"
                                   f" · {len(item.mapping)} connections")


class CLOTHNEXT_PT_collision(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Collision"
    bl_idname = "CLOTHNEXT_PT_collision"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "collision"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.object.cloth_next
        collision = settings.collision
        layout.prop(collision, "enabled", text="Enable Collisions")
        controls = layout.column()
        controls.enabled = collision.enabled
        controls.prop(collision, "surface_grip")
        if context.object.cloth_next.role == "ROD":
            controls.prop(collision, "surface_offset",
                          text="Collision Radius")
            controls.prop(collision, "collision_gap")
        else:
            controls.prop(collision, "collision_gap")
            controls.prop(collision, "surface_offset")


class CLOTHNEXT_PT_collision_timing(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Collision Timing"
    bl_idname = "CLOTHNEXT_PT_collision_timing"
    bl_parent_id = "CLOTHNEXT_PT_collision"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "timer"

    @classmethod
    def poll(cls, context):
        return _stable_only_panel_visible() and super().poll(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        quality = context.scene.cloth_next_quality
        layout.prop(quality, "target_toi")
        layout.prop(quality, "line_search_max_t")
        layout.prop(quality, "ccd_max_iter")


class CLOTHNEXT_PT_advanced_contact_distance(
        _ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Advanced Contact Distance"
    bl_idname = "CLOTHNEXT_PT_advanced_contact_distance"
    bl_parent_id = "CLOTHNEXT_PT_collision"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "collision"

    @classmethod
    def poll(cls, context):
        return _stable_only_panel_visible() and super().poll(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        warning = layout.box()
        warning.alert = True
        warning.label(text="Expert settings", icon="ERROR")
        warning.label(text="Change only if you understand their solver impact")
        warning.label(text="Incorrect values can destabilize or stop a Bake")
        quality = context.scene.cloth_next_quality
        layout.prop(quality, "constraint_ghat")
        layout.prop(quality, "constraint_tol")
        layout.prop(quality, "ccd_reduction")
        layout.label(text="Scene-wide settings for moving Pins and contact",
                     icon="INFO")


class CLOTHNEXT_PT_friction_regions(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Friction Regions"
    bl_idname = "CLOTHNEXT_PT_friction_regions"
    bl_parent_id = "CLOTHNEXT_PT_collision"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "friction_regions"

    def draw(self, context):
        settings = context.object.cloth_next
        layout = self.layout
        header = layout.row(align=True)
        header.operator(CLOTHNEXT_OT_add_friction_region.bl_idname,
                        text="Add Region", icon="ADD")
        for index, region in enumerate(settings.friction_regions):
            row = layout.row(align=True)
            row.prop_search(region, "vertex_group", context.object,
                            "vertex_groups", text="")
            row.prop(region, "friction", text="")
            remove = row.operator(CLOTHNEXT_OT_remove_friction_region.bl_idname,
                                  text="", icon="REMOVE")
            remove.index = index


class CLOTHNEXT_PT_collider_collision(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Collision"
    bl_idname = "CLOTHNEXT_PT_collider_collision"
    roles = {"COLLIDER"}
    header_icon = "collision"

    def draw(self, context):
        controls = self.layout.column()
        controls.enabled = not shared_controller.snapshot().active
        controls.label(text="Collision Geometry · Evaluated at: Cloth NeXt",
                       icon="MODIFIER")
        controls.label(text="Modifiers after Cloth NeXt are Blender-only")
        _draw_collider_collision(controls, context.object.cloth_next, context)

    def draw_header(self, context):
        super().draw_header(context)
        from . import linked_colliders
        group = linked_colliders.group_for(context.object, context.scene)
        if group is not None:
            count = len(linked_colliders.members(context.scene, group))
            indicator = self.layout.operator("clothnext.shared_collision_info", text=f"Shared [{count}]",
                                            emboss=False, **icon_registry.icon_kwargs("link", "LINKED"))
            indicator.count = count


class CLOTHNEXT_PT_simulation_proxy(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Simulation Proxy"
    bl_idname = "CLOTHNEXT_PT_simulation_proxy"
    bl_parent_id = "CLOTHNEXT_PT_collider_collision"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"COLLIDER"}
    header_icon = "simulation_proxy"

    @classmethod
    def poll(cls, context):
        if not super().poll(context):
            return False
        settings = context.object.cloth_next
        return (object_properties.collider_motion_from(settings) == "ANIMATED"
                and not collider_proxy.is_generated_proxy(context.object))

    def draw(self, context):
        settings = context.object.cloth_next
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        layout.prop(settings, "collider_proxy_type")
        cage_mode = settings.collider_proxy_type == "CHARACTER_CAGE"
        if cage_mode:
            cage = layout.column(align=True)
            cage.prop(settings, "collider_cage_margin")
            cage.prop(settings, "collider_cage_joint_overlap")
            cage.prop(settings, "collider_cage_sample_step")
            cage.prop(settings, "collider_cage_weight_threshold")
            cage.prop(settings, "collider_cage_min_vertices")
        else:
            layout.prop(settings, "collider_proxy_target_vertices",
                        text="Target Vertices")

        proxy = getattr(settings, "collider_proxy_object", None)
        cage_proxy = bool(
            proxy is not None and
            collider_proxy.character_collision_cage.is_primary_cage_segment(proxy))
        simple_proxy = bool(
            proxy is not None and
            not collider_proxy.character_collision_cage.is_cage_segment(proxy))
        proxy_matches_mode = cage_proxy if cage_mode else simple_proxy

        action = layout.row()
        action.enabled = not shared_controller.snapshot().active
        action.operator(
            "clothnext.generate_collider_proxy",
            text=("Regenerate Character Cage" if proxy_matches_mode and cage_mode
                  else "Generate Character Cage" if cage_mode
                  else "Regenerate Simple Proxy" if proxy_matches_mode
                  else "Generate Simple Proxy"))

        if not proxy_matches_mode:
            if bool(settings.collider_proxy_enabled):
                layout.prop(settings, "collider_proxy_enabled",
                            text="Use Simulation Proxy")
                layout.label(
                    text="Selected Proxy Type is missing; generate it or disable Proxy",
                    icon="ERROR")
            elif proxy is not None:
                layout.label(
                    text="Generate the selected Proxy Type before enabling it",
                    icon="INFO")
            else:
                layout.label(
                    text="Original Collider remains active until generated",
                    icon="INFO")
            return

        layout.prop(settings, "collider_proxy_enabled",
                    text="Use Simulation Proxy")
        # Panel.draw must never inspect proxy geometry. Generation stores these
        # counts on the source; use only those cached values during redraw.
        source_vertices = int(
            getattr(settings, "collider_proxy_source_vertices", 0) or 0)
        proxy_vertices = int(
            getattr(settings, "collider_proxy_result_vertices", 0) or 0)
        frame_settings = _authoritative_frame_settings(context)
        samples = collider_proxy.motion_sample_count(
            int(frame_settings.bake_start), int(frame_settings.bake_end),
            int(settings.collider_samples_per_frame))
        proxy_samples = 1 if cage_mode else samples
        source_peak = collider_proxy.estimated_ppf_peak_bytes(
            source_vertices, samples)
        proxy_peak = collider_proxy.estimated_ppf_peak_bytes(
            proxy_vertices, proxy_samples)
        if cage_mode:
            segment_count = (collider_proxy.character_collision_cage.
                             cage_segment_count(context.object))
            layout.label(
                text=(f"Cage: {segment_count} bone hulls · "
                      f"{proxy_vertices:,} vertices"))
            layout.label(
                text="Character sampled once; Bake uses rigid bone hulls",
                icon="ARMATURE_DATA")
        else:
            layout.label(text=f"Source: {source_vertices:,} vertices")
            layout.label(text=f"Proxy: {proxy_vertices:,} vertices")
        layout.label(text="Estimated Peak Memory")
        layout.label(
            text=(f"{collider_proxy.format_bytes(source_peak)} → "
                  f"{collider_proxy.format_bytes(proxy_peak)}"),
            icon="MEMORY")
        layout.label(
            text="Regenerate after topology, rig, or animation changes",
            icon="INFO")


class CLOTHNEXT_PT_force(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Force"
    bl_idname = "CLOTHNEXT_PT_force"
    force_only = True
    header_icon = "force"

    @classmethod
    def poll(cls, _context):
        """Superseded by the role-aware Setup panel."""
        return False

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = True
        _draw_complete_force_controls(
            layout, context.object.cloth_next, direction_prefix="Empty ")
        layout.label(text="Forces of the same type are added together")


class CLOTHNEXT_PT_material(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Material"; bl_idname = "CLOTHNEXT_PT_material"; deformable_only = True
    header_icon = "physical"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.object.cloth_next
        if settings.role == "ROD":
            _draw_cable_rope_material(layout, settings)
            return
        if settings.role == "SOFT_BODY":
            _draw_soft_body_material(layout, settings)
            return
        if settings.role == "RIGID_BODY":
            layout.prop(settings.rigid_body, "volume_density",
                        text="Volume Density")
            return
        material = settings.material
        error = material_presets.load_error()
        if error:
            layout.label(text="Bundled presets unavailable:", icon="ERROR")
            layout.label(text=error)
        preset_row = layout.row()
        preset_row.label(text="Material Preset")
        preset_row.menu(CLOTHNEXT_MT_material_presets.bl_idname,
                        text=_preset_label(material.preset))
        layout.prop(material, "model")
        behavior = layout.column(align=True)
        behavior.prop(material, "surface_weight")
        behavior.prop(material, "stretch_resistance")
        behavior.prop(material, "sideways_response")
        behavior.prop(material, "bend_resistance")
        # Sent to the solver whether or not bend plasticity is on.
        behavior.prop(material, "bend_rest_from_geometry")
        protection = layout.column(align=True)
        protection.label(text="Stretch Protection")
        protection.prop(material, "stretch_limit_enabled")
        row = protection.row()
        row.enabled = material.stretch_limit_enabled
        row.prop(material, "maximum_stretch_percent")
        damping = layout.column(align=True)
        damping.label(text="Damping")
        damping.prop(settings.damping, "shape_damping")
        damping.prop(settings.damping, "fold_damping")
        permanent = layout.column(align=True)
        permanent.label(text="Permanent Deformation")
        permanent.prop(material, "stretch_plasticity_enabled")
        stretch = permanent.column(align=True)
        stretch.enabled = material.stretch_plasticity_enabled
        stretch.prop(material, "stretch_plasticity_rate")
        stretch.prop(material, "stretch_plasticity_threshold_percent")
        permanent.prop(material, "bend_plasticity_enabled")
        bend = permanent.column(align=True)
        bend.enabled = material.bend_plasticity_enabled
        bend.prop(material, "bend_plasticity_rate")
        bend.prop(material, "bend_plasticity_threshold_degrees")
        from . import material_zones
        material_zones.draw(layout, context)


class CLOTHNEXT_PT_pinning(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Pinning"; bl_idname = "CLOTHNEXT_PT_pinning"; cloth_only = True
    bl_parent_id = "CLOTHNEXT_PT_shape"
    bl_options = {"DEFAULT_CLOSED"}
    header_icon = "pinning"

    def draw(self, context):
        from . import solver_test
        layout = self.layout
        settings = context.object.cloth_next
        controls = layout.column(align=True)
        controls.enabled = not shared_controller.snapshot().active
        controls.prop(settings, "pinning_enabled", text="Enable Pinning")
        group_row = controls.row()
        group_row.enabled = bool(settings.pinning_enabled)
        group_row.prop_search(settings, "pin_group", context.object,
                              "vertex_groups", text="Vertex Group")
        mode_row=controls.row(); mode_row.enabled=bool(settings.pinning_enabled)
        mode_row.prop(settings,"pin_mode",text="Mode")
        if settings.pin_mode == "TARGET_OBJECT":
            target_row = controls.row()
            target_row.enabled = bool(settings.pinning_enabled)
            target_row.prop(settings, "pin_target", text="Target")
            info = layout.box()
            info.label(text="Soft Pins preserve their starting offsets")
            info.label(text="Collider contact takes priority over the target")
        # The pin count comes from the last full validation. Scanning the
        # vertex group here would cost one pass over every vertex on every
        # single redraw — that is what made large meshes unusable.
        summary = solver_test.cheap_pin_summary(context.object)
        for text, icon in _pin_status_lines(summary):
            layout.label(text=text, icon=icon)


def _pin_status_lines(summary):
    """Recorded pinning status, labelled by how trustworthy it is."""
    states = validation_state.ValidationState
    if not summary.enabled:
        return (("Pinning is disabled", "NONE"),)
    if not summary.group_name:
        return (("Select a Pin Group.", "ERROR"),)
    if not summary.group_exists:
        return (("The selected Pin Group no longer exists.", "ERROR"),)
    if summary.state is states.INVALID:
        return ((summary.message or "Pin selection is invalid.", "ERROR"),)
    if summary.state is states.VALID and summary.counted_group == summary.group_name:
        return ((f"Pinned Vertices: {summary.pin_count}", "NONE"),)
    if summary.state is states.VALIDATING:
        return (("Validating Pin selection…", "INFO"),)
    if summary.state is states.DIRTY:
        return (("Pin selection changed · validation required", "INFO"),)
    return (("Pin selection will be validated before Bake", "INFO"),)


class CLOTHNEXT_PT_damping(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Damping"; bl_idname = "CLOTHNEXT_PT_damping"; deformable_only = True
    header_icon = "damping"
    @classmethod
    def poll(cls, context):
        return (super().poll(context)
                and context.object.cloth_next.role not in {
                    "CLOTH", "ROD", "SOFT_BODY"}
                and context.object.cloth_next.role != "RIGID_BODY")
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        damping = context.object.cloth_next.damping
        layout.prop(damping, "shape_damping")
        if context.object.cloth_next.role in {"CLOTH", "ROD"}:
            layout.prop(damping, "fold_damping")


class CLOTHNEXT_PT_collisions(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Collisions"; bl_idname = "CLOTHNEXT_PT_collisions"
    header_icon = "collision"
    @classmethod
    def poll(cls, context):
        return (super().poll(context)
                and context.object.cloth_next.role not in {
                    "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER"})
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.object.cloth_next
        collision = settings.collision
        if settings.role == "COLLIDER":
            layout.prop(settings, "collider_motion")
            if object_properties.collider_motion_from(settings) == "STATIC":
                from . import solver_test
                if solver_test.static_collider_has_animation(context.object):
                    warning = layout.box()
                    warning.alert = True
                    warning.label(
                        text="Animated Collider is set to Static", icon="ERROR")
                    warning.label(
                        text="Set Collider Motion to Animated before Bake")
            if object_properties.collider_motion_from(settings) == "ANIMATED":
                layout.prop(settings, "collider_capture_mode")
                layout.prop(settings, "collider_samples_per_frame")
                samples = int(settings.collider_samples_per_frame)
                if samples < 8:
                    layout.label(text="Low sampling can let fast colliders cross cloth",
                                 icon="ERROR")
                elif samples < 12:
                    layout.label(text="Fast or curved motion: consider 12–16 samples",
                                 icon="INFO")
                else:
                    layout.label(text="High-fidelity animated Collider sampling",
                                 icon="CHECKMARK")
                if not collider_proxy.is_proxy_implementation_object(context.object):
                    proxy_box = layout.box()
                    proxy_box.label(text="Simulation Proxy · Preview",
                                    icon="ERROR")
                    proxy_box.prop(settings, "collider_proxy_type")
                    cage_mode = settings.collider_proxy_type == "CHARACTER_CAGE"
                    if cage_mode:
                        proxy_box.prop(settings, "collider_cage_margin")
                        proxy_box.prop(settings, "collider_cage_joint_overlap")
                        proxy_box.prop(settings, "collider_cage_sample_step")
                        proxy_box.prop(settings, "collider_cage_weight_threshold")
                        proxy_box.prop(settings, "collider_cage_min_vertices")
                    else:
                        proxy_box.prop(settings, "collider_proxy_target_vertices")
                    proxy = getattr(settings, "collider_proxy_object", None)
                    action = proxy_box.row(align=True)
                    action.operator(
                        "clothnext.generate_collider_proxy",
                        text=("Regenerate Character Cage" if proxy and cage_mode else
                              "Generate Character Cage" if cage_mode else
                              "Regenerate Simple Proxy" if proxy else
                              "Generate Simple Proxy"))
                    if proxy:
                        proxy_box.prop(settings, "collider_proxy_enabled")
                        estimate = collider_proxy.proxy_estimate(
                            context.object, proxy)
                        if cage_mode:
                            segment_count = (collider_proxy.character_collision_cage.
                                             cage_segment_count(context.object))
                            proxy_box.label(
                                text=(f"Cage: {segment_count} bone hulls · "
                                      f"{estimate.proxy_vertices:,} vertices"))
                            proxy_box.label(
                                text=("Mesh deformation is captured once while fitting; "
                                      "Bake uses transform-only rigid hulls"),
                                icon="ARMATURE_DATA")
                        else:
                            proxy_box.label(
                                text=(f"Geometry: {estimate.source_vertices:,} → "
                                      f"{estimate.proxy_vertices:,} vertices"))
                        proxy_box.label(
                            text=(f"Estimated solver peak: "
                                  f"{collider_proxy.format_bytes(estimate.source_peak_bytes)} "
                                  f"→ {collider_proxy.format_bytes(estimate.proxy_peak_bytes)}"),
                            icon="MEMORY")
                        proxy_box.label(
                            text="Regenerate after topology, rig, or animation changes",
                            icon="INFO")
                    else:
                        proxy_box.label(
                            text="Original Collider remains active until generated",
                            icon="INFO")
        if settings.role in {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}:
            layout.prop(collision, "enabled")
        column = layout.column()
        if settings.role in {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}:
            column.enabled = collision.enabled
        column.prop(collision, "surface_grip")
        if settings.role == "CLOTH":
            regions = column.box()
            header = regions.row(align=True)
            header.label(text="Friction Vertex Groups")
            header.operator(CLOTHNEXT_OT_add_friction_region.bl_idname,
                            text="", icon="ADD")
            for index, region in enumerate(settings.friction_regions):
                row = regions.row(align=True)
                row.prop_search(region, "vertex_group", context.object,
                                "vertex_groups", text="")
                row.prop(region, "friction", text="")
                remove = row.operator(
                    CLOTHNEXT_OT_remove_friction_region.bl_idname,
                    text="", icon="REMOVE")
                remove.index = index
            if not settings.friction_regions:
                regions.label(text="All vertices use general Friction",
                              icon="INFO")
        column.prop(collision, "collision_gap")
        column.prop(collision, "surface_offset")
        if (settings.role == "COLLIDER"
                and float(collision.collision_gap) >= 0.01
                and float(collision.surface_grip) >= 0.4):
            warning = layout.row()
            warning.alert = True
            warning.label(
                text="High Collision Gap and Friction may destabilize pinned Cloth",
                icon="ERROR")


def _developer_tools_enabled(context) -> bool:
    if not _developer_tools_build_enabled():
        return False
    try:
        return bool(addon_preferences(
            context, __package__).developer_tools)
    except (KeyError, AttributeError):
        return False


def _developer_tools_build_enabled() -> bool:
    """Developer UI exists only in explicitly prepared Dev snapshots."""
    return is_dev_build()


def _draw_intersection_diagnostics(layout, snapshot, *, running: bool) -> None:
    """Draw solver-confirmed intersections in production and developer UI."""
    from . import intersection_overlay, solver_test

    violations = solver_test.intersection_violations()
    presented = intersection_overlay.presentation_diagnostics()
    if (not violations and not presented
            and intersection_overlay.diagnostic_session() is None):
        return
    if intersection_overlay.diagnostic_session() is None:
        detected_count = max(
            (getattr(item, "total_count", len(violations))
             for item in violations), default=len(violations))
    else:
        detected_count = intersection_overlay.detected_count()
    degenerate_count = sum(
        1 for item in presented if not hasattr(item, "elements"))
    summary = []
    if detected_count:
        summary.append(
            f"{detected_count} Intersection"
            f"{'s' if detected_count != 1 else ''}")
    if degenerate_count:
        summary.append(
            f"{degenerate_count} Degenerate Face"
            f"{'s' if degenerate_count != 1 else ''}")
    diagnostics_box = layout.box()
    header = diagnostics_box.row(align=True)
    header.label(text="Geometry Diagnostics", icon="ERROR")
    summary_row = diagnostics_box.row(align=True)
    summary_row.label(text=" · ".join(summary))
    if intersection_overlay.mapping_warning():
        warning = diagnostics_box.row()
        warning.alert = True
        warning.label(text=intersection_overlay.mapping_warning(), icon="ERROR")
    if intersection_overlay.detail_notice():
        notice = diagnostics_box.row()
        notice.label(text=intersection_overlay.detail_notice(), icon="INFO")
    actions = diagnostics_box.split(factor=0.7, align=True)
    auto_fix = actions.column(align=True)
    auto_fix.enabled = (
        bool(solver_test._auto_fix_supported_violations()
             or solver_test._auto_fix_supported_degenerate_faces())
        and not running and not snapshot.active)
    auto_fix.scale_y = 1.15
    auto_fix.operator("clothnext.intersection_auto_fix",
                      text="Auto Fix", icon="MODIFIER")
    clear = actions.column(align=True)
    clear.scale_y = 1.15
    clear.operator("clothnext.intersection_clear", text="Clear", icon="X")


def _draw_solver_test_controls(layout, context) -> None:
    """Draw real-solver developer controls into a supplied container."""
    from . import solver_test
    layout.label(text="Real Solver Test", **icon_registry.icon_kwargs("advanced", "EXPERIMENTAL"))
    snapshot = shared_controller.snapshot()
    running = solver_test.run_active()
    layout.operator("clothnext.create_test_scene", **icon_registry.icon_kwargs("shape", "MESH_GRID"))
    run_row = layout.row()
    run_row.enabled = not running and not snapshot.active
    run_row.operator("clothnext.solver_test_run",
                     **icon_registry.icon_kwargs("bake", "RENDER_ANIMATION"))
    if running or snapshot.active:
        cancel_row = layout.row()
        cancel_row.enabled = snapshot.can_cancel
        cancel_row.operator("clothnext.solver_test_cancel",
                            **icon_registry.icon_kwargs("cancel","CANCEL"))
    column = layout.column(align=True)
    column.label(text=f"State: {snapshot.status_title}")
    if snapshot.status_message:
        column.label(text=snapshot.status_message)
    progress=getattr(column,"progress",None)
    if progress is not None and snapshot.progress_total:
        progress(factor=snapshot.progress_fraction,
                 text=f"{snapshot.progress_current} / {snapshot.progress_total}")
    if running or snapshot.active:
        from ..bake.status import format_duration
        plan = solver_test._active_plan
        if plan is not None:
            column.label(text=f"Solver: {plan.resolved.mode.name}")
            diag_host = "127.0.0.1 (owned process)"
            column.label(text=f"Server: {diag_host}")
        if snapshot.current_frame is not None and snapshot.frame_end:
            column.label(text=f"Frame {snapshot.current_frame} "
                              f"of {snapshot.frame_end}")
        column.label(text=f"Elapsed: {format_duration(snapshot.elapsed_seconds)}")
    if snapshot.error_summary:
        column.label(text=snapshot.error_summary, **icon_registry.icon_kwargs("error", "ERROR"))
        details = tuple(line.strip() for line in snapshot.error_details.splitlines()
                        if line.strip())
        for prefix in ("Stage:", "Blender frame:", "What to do:",
                       "Diagnostic log:"):
            line = next((value for value in details
                         if value.startswith(prefix)), None)
            if line:
                column.label(text=line[:180])
        _draw_intersection_diagnostics(layout, snapshot, running=running)
    layout.operator("clothnext.inspect_parameters",
                    **icon_registry.icon_kwargs("info", "VIEWZOOM"))
    actions=layout.row(align=True)
    actions.operator("clothnext.companion_launch", text="Bake Window",
                     **icon_registry.icon_kwargs("bake","WINDOW"))
    actions.operator("clothnext.solver_test_open_logs", text="Logs",
                     **icon_registry.icon_kwargs("folder","FILE_FOLDER"))
    actions.operator("clothnext.solver_test_clear", text="Clear", **icon_registry.icon_kwargs("remove", "TRASH"))


def _draw_ui_diagnostics_controls(layout, _context) -> None:
    layout.label(text="UI Diagnostics")
    snapshot = shared_controller.snapshot()
    layout.operator("clothnext.preview_start", text="Start UI Preview",
                    **icon_registry.icon_kwargs("play", "PLAY"))
    if snapshot.preview and snapshot.active:
        layout.operator("clothnext.preview_cancel", text="Cancel UI Preview",
                        **icon_registry.icon_kwargs("cancel", "CANCEL"))


_STALE_NOTICES = {
    "STALE": "Result is stale — settings or mesh changed since this bake. "
             "Rebake or Clear it explicitly.",
    "INVALID": "Result cannot be trusted — the last validation failed. "
               "Fix the scene, then Rebake.",
    "NEEDS_VALIDATION": "Result is not confirmed — the mesh has not been "
                        "validated since this bake. Validate or Rebake.",
}


def _draw_stale_result_notice(layout, context) -> None:
    """Show the recorded cache verdict.

    Reads the cheap settings fingerprint and the recorded validation state.
    It never hashes the mesh, so it can be honest about "settings changed"
    while staying explicitly unsure about "mesh changed".
    """
    obj = context.object
    if not getattr(obj.cloth_next, "baked_settings_fingerprint", ""):
        return
    try:
        state, _label = _cache_state(context)
    except Exception:  # noqa: BLE001 — a broken scene must not break draw
        return
    notice = _STALE_NOTICES.get(state)
    if notice:
        layout.label(text=notice,
                     **icon_registry.icon_kwargs("warning", "ERROR"))


class CLOTHNEXT_PT_cache(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Cache"; bl_idname = "CLOTHNEXT_PT_cache"
    deformable_only = True
    header_icon = "cache"
    @classmethod
    def poll(cls, context):
        return (super().poll(context)
                and context.object.cloth_next.role not in {
                    "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"})
    def draw(self, context):
        layout = self.layout
        settings = context.object.cloth_next
        controls = layout.column(align=True)
        controls.enabled = not shared_controller.snapshot().active
        controls.prop(settings, "bake_start")
        controls.prop(settings, "bake_end")
        controls.operator("clothnext.use_scene_range", text="Use Scene Range")
        controls.prop(settings, "cache_directory")
        try:
            from ..bake.frame_range import BakeFrameRange
            selected = BakeFrameRange(int(settings.bake_start),
                                      int(settings.bake_end))
            layout.label(text=f"Frames {selected.start}–{selected.end} · "
                              f"{selected.output_count} cached frames")
        except Exception as exc:
            layout.label(text=str(exc), icon="ERROR")
        _draw_stale_result_notice(layout, context)
        clear_row = layout.row()
        clear_row.enabled = not shared_controller.snapshot().active
        clear_row.operator("clothnext.solver_test_clear", text="Clear Result",
                           icon="TRASH")


class CLOTHNEXT_PT_developer_tools(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Developer Tools"
    bl_idname = "CLOTHNEXT_PT_developer_tools"
    bl_parent_id = "CLOTHNEXT_PT_cache"
    bl_options = {"DEFAULT_CLOSED"}
    deformable_only = True
    header_icon = "warning"

    @classmethod
    def poll(cls, context):
        return (CLOTHNEXT_PT_cache.poll(context)
                and _developer_tools_enabled(context))

    def draw(self, context):
        developer_box = self.layout.box()
        developer_box.alert = True
        developer_box.label(text="Developer-only controls", **icon_registry.icon_kwargs("advanced", "EXPERIMENTAL"))
        developer_box.label(
            text="Internal testing tools. Do not use in production scenes.",
            icon="ERROR")
        _draw_solver_test_controls(developer_box, context)
        developer_box.separator()
        _draw_ui_diagnostics_controls(developer_box, context)


class CLOTHNEXT_PT_beta_readiness(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Scene Health & Recovery"
    bl_idname = "CLOTHNEXT_PT_beta_readiness"
    bl_parent_id = "CLOTHNEXT_PT_cache"
    bl_options = {"DEFAULT_CLOSED"}
    cloth_only = True
    header_icon = "validate"

    def draw(self, context):
        layout = self.layout
        actions = layout.column(align=True)
        actions.enabled = not shared_controller.snapshot().active
        actions.operator("clothnext.scene_health", text="Run Scene Health Check",
                         icon="CHECKMARK")
        for check in beta_tools._last_health[:8]:
            icon = ("ERROR" if check.severity.value == "ERROR" else
                    "INFO" if check.severity.value == "WARNING" else "CHECKMARK")
            row = layout.row(align=True)
            row.alert = check.severity.value == "ERROR"
            row.label(text=f"{check.title}: {check.detail}", icon=icon)
            if check.action:
                layout.label(text=check.action, icon="BLANK1")
        layout.separator()
        cache = layout.box()
        cache.label(text="Cache Recovery", **icon_registry.icon_kwargs("cache", "FILE_CACHE"))
        cache.operator("clothnext.cache_scan", text="Scan Cache Directory",
                       icon="VIEWZOOM")
        if beta_tools._last_cache_root is not None:
            invalid = sum(entry.deletable for entry in beta_tools._last_cache)
            total = sum(entry.size_bytes for entry in beta_tools._last_cache)
            cache.label(text=(f"{len(beta_tools._last_cache)} cache(s) · "
                              f"{beta_tools.human_bytes(total)} · "
                              f"{invalid} safely removable"))
            for entry in beta_tools._last_cache[:5]:
                cache.label(text=f"{entry.cache_path.name}: {entry.condition}",
                            icon=("ERROR" if entry.deletable else "INFO"))
            clear = cache.row()
            clear.enabled = invalid > 0 and not shared_controller.snapshot().active
            clear.operator("clothnext.cache_clear_invalid",
                           text="Remove Invalid Caches", icon="TRASH")
        layout.separator()
        support = layout.box()
        support.label(text="Support", **icon_registry.icon_kwargs("question", "HELP"))
        support.operator("clothnext.export_support_report",
                         text="Export Privacy-Safe Report", icon="TEXT")
        if beta_tools._last_support_report is not None:
            support.label(text=beta_tools._last_support_report.name,
                          icon="CHECKMARK")


class CLOTHNEXT_PT_cloth_advanced(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Advanced"
    bl_idname = "CLOTHNEXT_PT_cloth_advanced"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "advanced"

    @classmethod
    def poll(cls, context):
        return _stable_only_panel_visible() and super().poll(context)

    def draw(self, context):
        pass


class CLOTHNEXT_PT_motion_overrides(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Motion Overrides"
    bl_idname = "CLOTHNEXT_PT_motion_overrides"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "timer"

    def draw(self, context):
        layout = self.layout
        settings = context.object.cloth_next
        header = layout.row(align=True)
        header.operator(CLOTHNEXT_OT_add_motion_override.bl_idname,
                        text="Add Override", **icon_registry.icon_kwargs("add", "ADD"))
        for index, item in enumerate(settings.motion_overrides):
            box = layout.box()
            top = box.row(align=True)
            top.prop(item, "frame")
            top.prop(item, "motion_type", text="")
            remove = top.operator(
                CLOTHNEXT_OT_remove_motion_override.bl_idname,
                text="", icon="REMOVE")
            remove.index = index
            if item.motion_type == "ANGULAR":
                box.prop(item, "angular_velocity", text="Spin")
            else:
                box.prop(item, "velocity", text="Velocity")
        if not settings.motion_overrides:
            layout.label(text="Add an override to change motion at a frame",
                         icon="INFO")
        layout.label(text="Hard-pinned vertices keep following their Pins",
                     icon="PINNED")


class CLOTHNEXT_PT_advanced_contact_solver(
        _ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Advanced Contact Solver"
    bl_idname = "CLOTHNEXT_PT_advanced_contact_solver"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER"}
    header_icon = "solver_settings"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        warning = layout.box()
        warning.alert = True
        warning.label(text="Expert settings", **icon_registry.icon_kwargs("error", "ERROR"))
        warning.label(text="Change only if you understand their solver impact")
        warning.label(text="Incorrect values can destabilize or stop a Bake")
        quality = context.scene.cloth_next_quality
        layout.prop(quality, "max_newton_steps")
        layout.prop(quality, "max_dx")
        layout.prop(quality, "eigenanalysis_eps")
        layout.prop(quality, "friction_eps")
        layout.prop(quality, "csrmat_max_nnz")
        layout.prop(quality, "contact_barrier")
        layout.label(text="These settings affect the entire scene", **icon_registry.icon_kwargs("info", "INFO"))


class CLOTHNEXT_PT_recovery(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Recovery & Checkpoints"
    bl_idname = "CLOTHNEXT_PT_recovery"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    bl_options = {"DEFAULT_CLOSED"}
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "result"

    def draw(self, context):
        settings = context.scene.cloth_next_recovery
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(settings, "enabled")
        controls = layout.column()
        controls.enabled = settings.enabled
        controls.prop(settings, "auto_save")
        interval = controls.column()
        interval.enabled = settings.auto_save
        interval.prop(settings, "checkpoint_interval")
        controls.prop(settings, "keep_saved_states")
        controls.prop(settings, "save_on_cancel")
        controls.prop(settings, "save_on_finish")
        if settings.status:
            layout.separator()
            layout.label(text=settings.status,
                         icon="CHECKMARK" if settings.compatible else "INFO")
        if settings.status_detail:
            layout.label(text=settings.status_detail)
        if settings.resumable:
            layout.label(
                text=f"Latest checkpoint: Frame "
                     f"{settings.latest_checkpoint_frame}")
            layout.label(
                text=f"Available checkpoints: {settings.checkpoint_count}")
            layout.label(
                text="Resume available · Uses latest verified checkpoint")
        if settings.older_checkpoint_preserved:
            layout.label(
                text="Older checkpoint preserved after latest save failed",
                icon="INFO")
        actions = layout.column(align=True)
        resume = actions.row()
        resume.enabled = (
            settings.resumable and not shared_controller.snapshot().active)
        resume.operator("clothnext.recovery_resume_latest",
                        text="Resume Latest", **icon_registry.icon_kwargs("play", "PLAY"))
        actions.operator("clothnext.recovery_start_fresh",
                         text="Start Fresh", **icon_registry.icon_kwargs("update", "FILE_REFRESH"))
        actions.operator("clothnext.recovery_clear_checkpoints",
                         text="Clear Checkpoints", **icon_registry.icon_kwargs("remove", "TRASH"))
        actions.operator("clothnext.recovery_open_folder",
                         text="Open Recovery Folder", **icon_registry.icon_kwargs("folder", "FILE_FOLDER"))


class CLOTHNEXT_PT_solver_settings(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Solver Settings"
    bl_idname = "CLOTHNEXT_PT_solver_settings"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    roles = {
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "solver_settings"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        quality = context.scene.cloth_next_quality
        layout.prop(quality, "time_step")
        layout.prop(quality, "min_newton_steps")
        layout.prop(quality, "cg_max_iter")
        layout.prop(quality, "cg_tol")


class CLOTHNEXT_PT_simulation_engine(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Simulation Engine"
    bl_idname = "CLOTHNEXT_PT_simulation_engine"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    roles = {
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "engine"

    def draw(self, context):
        status = _solver_status(context)
        row = self.layout.row(align=True)
        row.label(text="Status")
        row.label(text="✓ Ready" if status.ready else "Not Configured")
        if not status.ready:
            self.layout.operator("clothnext.open_preferences",
                                 text="Open Add-on Preferences")


class CLOTHNEXT_PT_result(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Result"
    bl_idname = "CLOTHNEXT_PT_result"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    roles = {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}
    header_icon = "result"

    def draw(self, context):
        settings = context.object.cloth_next
        _state, label = _cache_state(context)
        layout = self.layout
        layout.use_property_split = True
        layout.label(text=f"Status                             {label}")
        if _state != "EMPTY":
            layout.label(text=(f"Cached Frames                    "
                               f"{settings.bake_start}–{settings.bake_end}"))
        cache_path = str(getattr(settings, "cache_directory", "") or "").strip()
        if cache_path:
            operator = layout.operator("wm.path_open",
                                       text="Open Cache Folder",
                                       icon="FILE_FOLDER")
            operator.filepath = cache_path
        clear = layout.row()
        clear.enabled = not shared_controller.snapshot().active
        clear.operator("clothnext.solver_test_clear", text="Clear Result",
                       icon="TRASH")


class CLOTHNEXT_PT_diagnostics(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Diagnostics"
    bl_idname = "CLOTHNEXT_PT_diagnostics"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    roles = {
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "diagnostics"

    def draw(self, context):
        if context.object.cloth_next.role in {"COLLIDER", "FORCE"}:
            self.layout.operator(
                "clothnext.companion_launch", text="Open Bake Window",
                **icon_registry.icon_kwargs("bake", "WINDOW"))
            self.layout.operator("clothnext.companion_open_logs",
                                 text="Open Logs", icon="FILE_FOLDER")
            return
        self.layout.operator("clothnext.scene_health",
                             text="Run Scene Health Check", icon="CHECKMARK")
        self.layout.operator("clothnext.inspect_parameters",
                             text="Inspect Parameters", icon="VIEWZOOM")
        self.layout.operator("clothnext.companion_open_logs",
                             text="Open Logs", icon="FILE_FOLDER")


class CLOTHNEXT_PT_object_attachments(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Object Attachments"
    bl_idname = "CLOTHNEXT_PT_object_attachments"
    roles = {"CLOTH", "SOFT_BODY"}
    bl_options = {"DEFAULT_CLOSED"}
    header_icon = "pinning"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.use_property_split = False
        source_id = str(context.object.cloth_next.persistent_export_id)
        owned = []
        referenced = []
        for index, item in enumerate(scene.cloth_next_object_attachments):
            if source_id == str(item.source_persistent_id):
                owned.append((index, item))
            elif source_id == str(item.target_persistent_id):
                referenced.append(item)

        controls = layout.column()
        controls.enabled = not shared_controller.snapshot().active
        for index, item in owned:
            source_count = len(object_attachments._selected_indices(item, "source"))
            target_count = len(object_attachments._selected_indices(item, "target"))
            box = controls.box()
            header = box.row(align=True)
            header.alert = item.needs_rebuild
            header.prop(item, "ui_expanded", text="", emboss=False,
                        icon="TRIA_DOWN" if item.ui_expanded else "TRIA_RIGHT")
            header.prop(item, "enabled", text="")
            header.prop(item, "name", text="")
            header.label(text=f"{source_count} ↔ {target_count}")
            header.prop(item, "show_overlay", text="", icon="HIDE_OFF")
            remove = header.operator(
                object_attachments.CLOTHNEXT_OT_remove_object_attachment.bl_idname,
                text="", icon="REMOVE")
            remove.index = index
            if not item.ui_expanded:
                continue
            if item.use_vertex_groups:
                row = box.row(align=True)
                source = object_attachments._objects_by_identity(scene).get(
                    str(item.source_persistent_id))
                row.prop(item, "target_object", text="")
                if source is not None:
                    row.prop_search(item, "source_group", source, "vertex_groups", text="")
                else:
                    row.label(text="Missing source", icon="ERROR")
                group2 = row.row(align=True)
                group2.enabled = item.target_object is not None
                if item.target_object is not None:
                    group2.prop_search(item, "target_group", item.target_object,
                                       "vertex_groups", text="")
                else:
                    group2.prop(item, "target_group", text="")
                status = box.row(align=True)
                bind = status.operator(
                    object_attachments.CLOTHNEXT_OT_bind_group_attachment.bl_idname,
                    text="Bind", icon="LINKED")
                bind.index = index
                if item.needs_rebuild:
                    status.label(text=item.status_message, icon="INFO")
                else:
                    status.label(text=f"{len(item.points)} attachment points")
                continue
            target = getattr(item, "target_object", None)
            box.label(text=f"Target        {target.name if target else item.target_name or 'Missing'}")
            box.label(text=f"Vertices      {source_count} ↔ {target_count}")
            box.prop(item, "stiffness", text="Strength", slider=True)
            if item.needs_rebuild:
                box.label(text=item.status_message or "Needs Rebuild",
                          icon="ERROR")
        controls.operator(object_attachments.CLOTHNEXT_OT_edit_attachment.bl_idname,
                          text="Add Attachment", icon="ADD")
        controls.operator(object_attachments.CLOTHNEXT_OT_edit_attachment.bl_idname,
                          text="Smart Attach", icon="SNAP_VERTEX").smart = True
        if not owned:
            layout.label(text="No source-owned attachments", icon="INFO")
        if referenced:
            layout.separator()
            layout.label(text="Referenced by:")
            objects = object_attachments._objects_by_identity(scene)
            for item in referenced:
                source = objects.get(str(item.source_persistent_id))
                row = layout.row()
                row.enabled = False
                row.label(text=f"{source.name if source else item.source_name or 'Missing'} → {context.object.name}",
                          icon="LINKED")


class CLOTHNEXT_PT_maintenance(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Maintenance"
    bl_idname = "CLOTHNEXT_PT_maintenance"
    bl_parent_id = "CLOTHNEXT_PT_cloth_advanced"
    roles = {
        "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER", "FORCE"}
    header_icon = "maintenance"

    def draw(self, _context):
        self.layout.operator(
            physics_operators.CLOTHNEXT_OT_remove_physics.bl_idname,
            text="Remove Cloth NeXt", **icon_registry.icon_kwargs("remove", "X"))


class CLOTHNEXT_PT_advanced(_ClothNextSubpanel, bpy.types.Panel):
    bl_label = "Advanced Solver"; bl_idname = "CLOTHNEXT_PT_advanced"; bl_options = {"DEFAULT_CLOSED"}
    header_icon = "advanced"

    @classmethod
    def poll(cls, context):
        return (super().poll(context)
                and context.object.cloth_next.role not in {
                    "CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY", "COLLIDER",
                    "FORCE"})

    def draw(self, context):
        layout = self.layout
        settings = context.object.cloth_next
        if settings.role == "CLOTH":
            layout.use_property_split = True
            layout.use_property_decorate = False
            layout.prop(settings.material, "model")
        column = layout.column(align=True)
        column.label(text="Exact solver wire values:")
        try:
            if settings.role == "CLOTH":
                shell = object_properties.shell_settings_from(settings)
                rows = formatting.shell_wire_rows(shell)
            else:
                static = object_properties.static_settings_from(settings)
                rows = formatting.static_wire_rows(static)
        except Exception as exc:  # noqa: BLE001 — invalid values stay visible
            column.label(text=str(exc), icon="ERROR")
            rows = ()
        for artist_label, ppf_key, value in rows:
            column.label(text=f"{artist_label} · {ppf_key}: {value}")
        info = layout.column(align=True)
        info.label(text="Friction mode: Minimum (fixed) — the lower of the "
                        "two touching surfaces wins")
        if settings.role == "CLOTH":
            info.label(text="Stiffness basis: density-normalized solver "
                            "young-mod (not textbook Pa)")
            contact = ("enabled" if settings.collision.enabled
                       else "DISABLED (disable-contact: true)")
            info.label(text=f"Contact: {contact}")
        info.label(text="Shared solve: multiple deformables and colliders",
                   icon="INFO")


CLASSES = (CLOTHNEXT_OT_unavailable_object_type, CLOTHNEXT_MT_object_type,
           CLOTHNEXT_OT_add_friction_region,
           CLOTHNEXT_OT_remove_friction_region,
           CLOTHNEXT_OT_add_soft_constraint,
           CLOTHNEXT_OT_remove_soft_constraint,
           CLOTHNEXT_OT_add_advanced_pin_target,
           CLOTHNEXT_OT_remove_advanced_pin_target,
           CLOTHNEXT_OT_add_motion_override,
           CLOTHNEXT_OT_remove_motion_override,
           *MATERIAL_PRESET_CATEGORY_MENUS, CLOTHNEXT_MT_material_presets,
           CLOTHNEXT_PT_physics, CLOTHNEXT_PT_empty_force,
           CLOTHNEXT_PT_setup, CLOTHNEXT_PT_aether_engine, CLOTHNEXT_PT_simulation, CLOTHNEXT_PT_cloud_jobs,
           CLOTHNEXT_PT_solver,
           CLOTHNEXT_PT_force, CLOTHNEXT_PT_material,
           CLOTHNEXT_PT_shape, CLOTHNEXT_PT_pinning,
           CLOTHNEXT_PT_advanced_pin_motion,
           CLOTHNEXT_PT_soft_constraints,
           CLOTHNEXT_PT_rest_shape, CLOTHNEXT_PT_soft_body_rest_shape,
           CLOTHNEXT_PT_cable_rope_rest_shape,
           CLOTHNEXT_PT_pressure,
           CLOTHNEXT_PT_sewing,
           CLOTHNEXT_PT_object_attachments,
           CLOTHNEXT_PT_damping,
           CLOTHNEXT_PT_collision, CLOTHNEXT_PT_friction_regions,
           CLOTHNEXT_PT_collision_timing,
           CLOTHNEXT_PT_advanced_contact_distance,
           CLOTHNEXT_PT_collider_collision, CLOTHNEXT_PT_simulation_proxy,
           CLOTHNEXT_PT_collisions, CLOTHNEXT_PT_cache,
           CLOTHNEXT_PT_beta_readiness,
           CLOTHNEXT_PT_developer_tools,
           CLOTHNEXT_PT_cloth_advanced,
           CLOTHNEXT_PT_motion_overrides,
           CLOTHNEXT_PT_advanced_contact_solver,
           CLOTHNEXT_PT_recovery,
           CLOTHNEXT_PT_solver_settings,
           CLOTHNEXT_PT_simulation_engine, CLOTHNEXT_PT_result,
           CLOTHNEXT_PT_diagnostics, CLOTHNEXT_PT_maintenance,
           CLOTHNEXT_PT_advanced)
