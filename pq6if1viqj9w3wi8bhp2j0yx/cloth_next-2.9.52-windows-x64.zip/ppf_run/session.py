# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""Pure solver session service: one real PPF run from upload to frames.

No ``bpy`` anywhere in this module (enforced by tests). The Blender side
hands in an immutable :class:`SessionScene`; this service starts or connects
the solver, uploads, builds, simulates, incrementally fetches and validates
result frames, emits :class:`SessionEvent` progress, honors cancellation,
cleans up its unique project, and stops only processes it started itself.

Process management, health checks, ownership rules, error taxonomy, and
logging all reuse the existing Phase-2 building blocks; no second process
implementation exists here.
"""

from __future__ import annotations

import logging
import json
import re
import os
import subprocess
from copy import deepcopy
import threading
import time
import uuid as uuid_module
from dataclasses import dataclass, field, replace
from enum import Enum
from pathlib import Path
from typing import Callable

import numpy as np

from ..core.errors import ClothNextError, ErrorCategory, ErrorRecord
from ..core.logging import get_logger, log_with_context
from ..core.safe_delete import delete_owned
from ..core.filesystem_paths import io_path
from ..ppf import results, wire
from ..ppf.health import start_owned_and_wait
from ..ppf.layout import BundledSolverLayout
from ..ppf.models import ConnectionOwnership
from ..ppf.process import (SolverProcessConfig, SolverProcessManager,
                           format_windows_exit_code)
from ..ppf.resolver import ResolvedSolver
from ..ppf.transport import TransportConfig
from .. import recovery
from ..updater.health_runner import bundle_root_for, free_port
from ..platform_support import platform_spec

# Wire status tokens (crates/ppf-cts-server, verified at pinned 7193f158).
STATUS_NO_DATA = "NO_DATA"
STATUS_NO_BUILD = "NO_BUILD"
STATUS_BUILDING = "BUILDING"
STATUS_READY = "READY"
STATUS_RESUMABLE = "RESUMABLE"
STATUS_FAILED = "FAILED"
STATUS_BUSY = "BUSY"
STATUS_SAVE_AND_QUIT = "SAVE_AND_QUIT"

_POLL_INTERVAL = 0.25
# The ordinary session read allowance is 30 seconds. Two such windows cover a
# server worker that is briefly monopolized by a difficult GPU frame, while a
# three-retry ceiling prevents fast connection refusals from hammering accept().
_STATUS_RECONNECT_GRACE = 60.0
_STATUS_RECONNECT_RETRIES = 3
_MAX_VIOLATION_SIDECAR_BYTES = 4 * 1024 * 1024
_VIOLATION_SIDECAR_CONFIRM_TIMEOUT = 1.0


def _normalize_violation_payload(payload) -> tuple[dict, ...]:
    """Flatten the bounded JSON shapes used by real solver transports.

    Depending on protocol generation, a status field or sidecar may contain
    dictionaries directly, JSON strings for individual records, one JSON
    string for the complete list, or a ``{"violations": ...}`` envelope.
    """
    records = []

    def visit(value, depth=0):
        if depth > 4:
            return
        if isinstance(value, str):
            if len(value) > _MAX_VIOLATION_SIDECAR_BYTES:
                return
            try:
                visit(json.loads(value), depth + 1)
            except (json.JSONDecodeError, TypeError, ValueError):
                return
        elif isinstance(value, (list, tuple)):
            for item in value:
                visit(item, depth + 1)
        elif isinstance(value, dict):
            # An envelope is not itself a violation. Do not unwrap a genuine
            # record that merely carries supplemental nested diagnostics.
            identifying = {
                "type", "classification", "combined_pair", "pair", "tris",
                "elements", "tri_positions", "positions0", "positions1"}
            if "violations" in value and not identifying.intersection(value):
                visit(value["violations"], depth + 1)
            else:
                records.append(value)

    visit(payload)
    return tuple(records)

_SOLVER_METRICS = {
    "contacts": "advance.num_contact.out",
    "newton": "advance.newton_steps.out",
    "iterations": "advance.iter.out",
}


def _native_worker_path(executable: Path) -> Path:
    """Resolve the worker in both supported official solver layouts.

    Release bundles keep it next to the control server; local official source
    builds keep it below ``target/release``.  The latter is used by the real
    Blender integration proof and must not be mistaken for a quarantined
    worker.
    """
    bundled = executable.with_name(platform_spec().solver_worker_filename)
    if bundled.is_file():
        return bundled
    return executable.parent / "target" / "release" / bundled.name


def _missing_worker_error(worker: Path, *, detail: str = "") -> ClothNextError:
    technical = f"native solver worker is missing: {worker}"
    if detail:
        technical += f"; {detail}"
    return ClothNextError(ErrorRecord.create(
        category=ErrorCategory.SOLVER_INSTALLATION,
        user_message=(
            "The native solver worker is missing. Security software may "
            "have quarantined it."),
        technical_message=technical,
        recommended_action=(
            "Restore or reinstall the verified solver, allow its installation "
            "folder in the security software, then retry the Bake."),
        recoverable=True,
        context={"failure_kind": "NATIVE_WORKER_MISSING",
                 "worker_path": str(worker)}))


class RecoveryOutcomeKind(str, Enum):
    SAVED = "SAVED"
    EXISTING_PRESERVED = "EXISTING_PRESERVED"
    NOT_ENABLED = "NOT_ENABLED"
    NOT_AVAILABLE_YET = "NOT_AVAILABLE_YET"
    FAILED = "FAILED"


class ResumeServerState(str, Enum):
    """Authoritative server-side disposition before sending ``resume``.

    Durable checkpoint metadata is deliberately not enough to decide whether a
    remote PPF project may be resumed: after a host crash it can still be
    simulating.  This value is diagnostic as well as a gate; it never causes
    a request that changes an external server.
    """
    RESUMABLE = "RESUMABLE"
    ACTIVE = "ACTIVE"
    READY = "READY"
    FAILED_WITH_CHECKPOINT = "FAILED_WITH_CHECKPOINT"
    MISSING = "MISSING"
    STALE = "STALE"


@dataclass(frozen=True, slots=True)
class ResumeServerReconciliation:
    state: ResumeServerState
    status: str
    message: str
    may_resume: bool


def reconcile_resume_server_state(response: dict) -> ResumeServerReconciliation:
    """Classify a checked server project without mutating it.

    Call this immediately before ``REQUEST_RESUME``.  In particular, BUSY is
    not a resumable state: it means the old solver session is still active and
    must be reconnected to, allowed to finish, or explicitly stopped by the
    artist outside this automatic recovery path.
    """
    status = str(response.get("status", "") or "")
    if status in {STATUS_BUSY, STATUS_SAVE_AND_QUIT, STATUS_BUILDING}:
        return ResumeServerReconciliation(
            ResumeServerState.ACTIVE, status,
            "The saved solver project is still active. Reconnect or wait for "
            "it to finish; Cloth NeXt will not start a second resume or stop "
            "an external server automatically.", False)
    if status == STATUS_RESUMABLE:
        return ResumeServerReconciliation(
            ResumeServerState.RESUMABLE, status,
            "Saved project is resumable.", True)
    if status == STATUS_READY:
        return ResumeServerReconciliation(
            ResumeServerState.READY, status,
            "Saved project is ready and not currently simulating.", True)
    if status == STATUS_FAILED:
        return ResumeServerReconciliation(
            ResumeServerState.FAILED_WITH_CHECKPOINT, status,
            "The solver project failed but retains a verified checkpoint.",
            True)
    if status in {STATUS_NO_DATA, STATUS_NO_BUILD}:
        return ResumeServerReconciliation(
            ResumeServerState.MISSING, status,
            "The saved solver project no longer exists on this server.", False)
    return ResumeServerReconciliation(
        ResumeServerState.STALE, status,
        "The saved solver project returned an unrecognised status; recovery "
        "metadata may be stale.", False)


@dataclass(frozen=True, slots=True)
class RecoveryOutcome:
    """Structured result of a recovery checkpoint attempt on cancellation."""
    kind: RecoveryOutcomeKind
    """Unambiguous category used by the Blender UI."""
    checkpoint_saved: bool
    """True if a verified checkpoint was confirmed and the project is resumable."""
    artist_message: str
    """Short user-facing message for the UI (e.g., 'Recovery checkpoint saved')."""
    technical_reason: str
    """Detailed reason for logging/debugging (empty on success)."""
    state_before: str
    """Server status when cancellation was requested (e.g., 'BUSY', 'BUILDING')."""
    saved_states: tuple[int, ...]
    """Frames with confirmed saved states, if any."""
    timed_out: bool = False
    """True if the attempt timed out waiting for confirmation."""

    @property
    def resumable(self) -> bool:
        return self.checkpoint_saved
def _tail_numeric_metric(path: Path) -> int | None:
    """Read one live PPF metric without loading its growing history."""
    try:
        with io_path(path).open("rb") as stream:
            stream.seek(0, 2)
            size = stream.tell()
            if size <= 0:
                return None
            stream.seek(max(0, size - 4096))
            lines = stream.read().splitlines()
    except OSError:
        return None
    for line in reversed(lines):
        fields = line.split()
        if len(fields) < 2:
            continue
        try:
            return int(float(fields[-1]))
        except ValueError:
            continue
    return None


class SessionCancelled(Exception):
    """The run was cancelled cooperatively; not an error."""

    def __init__(self, *, resumable: bool = False,
                 recovery_outcome: RecoveryOutcome | None = None) -> None:
        super().__init__("solver session cancelled")
        self.resumable = bool(resumable)
        self.recovery_outcome = recovery_outcome


@dataclass(frozen=True, slots=True)
class RecoveryOptions:
    enabled: bool
    metadata_path: Path
    identity: recovery.RecoveryIdentity
    server_data_root: Path
    resume: bool = False
    keep_saved_states: int = 3
    save_on_cancel: bool = True
    keep_on_finish: bool = False
    auto_save_interval: int = 0
    completed_solver_frames: tuple[int, ...] = ()
    partial_pc2: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class SessionDeformable:
    name: str
    uuid: str
    vertex_count: int
    deformable_type: str = "SHELL"
    world_matrix: tuple | None = None


@dataclass(frozen=True, slots=True)
class SessionScene:
    """Immutable scene export handed from Blender's main thread."""

    project_name: str
    cloth_name: str
    cloth_uuid: str
    cloth_vertex_count: int
    collider_name: str
    collider_uuid: str
    frame_count: int  # Blender frames 1..frame_count
    data_payload: bytes | Path
    param_payload: bytes | Path
    data_hash: str
    param_hash: str
    deformable_type: str = "SHELL"
    deformable_world_matrix: tuple | None = None
    deformables: tuple[SessionDeformable, ...] = ()
    # CNX-owned binding state; never serialized as an unknown solver field.
    official_bridge_json: str = ""
    water_stream_json: str = ""

    @property
    def dynamic_objects(self) -> tuple[SessionDeformable, ...]:
        if self.deformables:
            return self.deformables
        return (SessionDeformable(
            self.cloth_name, self.cloth_uuid, self.cloth_vertex_count,
            self.deformable_type, self.deformable_world_matrix),)

    @property
    def solver_frame_count(self) -> int:
        """Frames the solver produces (vert_1..vert_N): Blender N -> N-1."""
        return self.frame_count - 1


def new_project_name() -> str:
    """Unique, server-safe project key; never a blend-file or object name."""
    return f"clothnext_{uuid_module.uuid4().hex[:12]}"


@dataclass(frozen=True, slots=True)
class SessionEvent:
    phase: str
    message: str
    progress_current: int | None = None
    progress_total: int | None = None
    frame_current: int | None = None
    frame_total: int | None = None
    indeterminate: bool = False
    process_id: int | None = None
    solver_mode: str = ""
    package_version: str | None = None
    protocol_version: str | None = None
    schema_version: str | None = None
    host: str = ""
    port: int = 0
    activity_code: str = ""
    solver_name: str = ""
    solver_backend: str = ""
    solver_device: str = ""
    solver_telemetry: dict[str, str] = field(default_factory=dict)
    emitted_at: float = field(default_factory=time.monotonic)


@dataclass(frozen=True, slots=True)
class SolverFrame:
    """One validated solver frame split into original dynamic objects."""

    solver_frame: int  # 1-based solver frame index (vert_<N>.bin)
    positions_solver_world: object
    positions_by_uuid: dict[str, object] = field(default_factory=dict)


@dataclass(slots=True)
class SessionDiagnostics:
    run_id: str = field(default_factory=lambda: uuid_module.uuid4().hex)
    project_name: str = ""
    solver_mode: str = ""
    installation_id: str | None = None
    official_release_tag: str | None = None
    host: str = ""
    port: int = 0
    process_id: int | None = None
    package_version: str | None = None
    protocol_version: str | None = None
    schema_version: str | None = None
    upload_id: str = ""
    data_hash: str = ""
    param_hash: str = ""
    status_transitions: list[str] = field(default_factory=list)
    fetched_frames: list[int] = field(default_factory=list)
    timings: dict[str, float] = field(default_factory=dict)
    cache_events: dict[str, str] = field(default_factory=dict)
    stdout_tail: tuple[str, ...] = ()
    stderr_tail: tuple[str, ...] = ()
    contact_peak: int = 0
    contact_last: int = 0
    contact_samples: int = 0
    cancelled: bool = False
    bytes_transferred: int = 0
    upload_data_bytes: int = 0
    upload_param_bytes: int = 0
    upload_total_bytes: int = 0
    control_server_alive: bool | None = None
    control_server_exit_code: int | None = None
    owned_process_ids: tuple[int, ...] = ()
    last_output_frame: int | None = None
    cleanup_issues: list[str] = field(default_factory=list)
    solver_launch_id: str = ""
    active_operation: str = "INITIALIZING"
    last_successful_stage: str = ""
    last_successful_command: str = ""
    command_in_flight: str = ""
    current_logical_frame: int | None = None
    last_completed_logical_frame: int | None = None
    last_fetched_frame: int | None = None
    termination_requested: bool = False
    last_valid_health_response: dict[str, object] = field(
        default_factory=dict)
    status_request_count: int = 0
    status_success_count: int = 0
    status_failure_count: int = 0
    consecutive_status_failures: int = 0
    status_latency_ms: float = 0.0
    max_status_latency_ms: float = 0.0
    last_status_success_monotonic: float | None = None
    transport_failure_phase: str = ""
    solver_name: str = ""
    solver_backend: str = ""
    solver_device: str = ""
    solver_telemetry: dict[str, str] = field(default_factory=dict)
    # Successful allowances are independent of violations and error state.
    exemptions: tuple[object, ...] = ()
    additive_status_fields: dict[str, object] = field(default_factory=dict)

    def note_status(self, status: str) -> None:
        if not self.status_transitions or self.status_transitions[-1] != status:
            self.status_transitions.append(status)


def _session_error(message: str, technical: str, *,
                   category: ErrorCategory = ErrorCategory.SIMULATION,
                   action: str = "Inspect the Cloth NeXt log and the solver "
                                 "stderr tail, then retry.",
                   context: dict[str, object] | None = None) -> ClothNextError:
    return ClothNextError(ErrorRecord.create(
        category=category, user_message=message, technical_message=technical,
        recommended_action=action, recoverable=True, context=context))


@dataclass(frozen=True, slots=True)
class PreparedSolverInputs:
    """Solver inputs after local Water Flow preparation.

    ``scene`` no longer carries a water descriptor when preparation turned it
    into files: a native fluid PARAM payload, or hydrodynamic volumes named by
    ``environment``. A legacy held stream (protocol 0.23) stays a descriptor.
    """

    scene: SessionScene
    environment: dict[str, str] = field(default_factory=dict)
    native_fluid_seconds: float | None = None


def prepare_solver_inputs(scene: SessionScene, resolved: ResolvedSolver,
                          work_directory: Path, *,
                          check_cancel: Callable[[], None],
                          event: Callable[..., None]) -> PreparedSolverInputs:
    """Run the local Water Flow preparation shared by local and Cloud Bakes."""
    if not scene.water_stream_json:
        return PreparedSolverInputs(scene)
    descriptor = json.loads(scene.water_stream_json)
    environment: dict[str, str] = {}
    seconds = None
    if descriptor.get('field_kind') == 'experimental-hydrodynamic':
        from ..gaia.hydrodynamic_session import prepare_session
        def report_surface(current,total):
            event('EXPORTING','Preparing native hydrodynamic surfaces',
                progress_current=current,progress_total=total,
                activity_code='ENCODING_NATIVE_FLUID')
        environment = prepare_session(descriptor,
            resolved.executable_path,work_directory,
            check_cancel=check_cancel,progress=report_surface,
            scene=scene)
        scene = replace(scene,water_stream_json='')
    if descriptor.get('field_kind') == 'native-file':
        from ..gaia.native_fluid import native_fluid_payload_file
        payload_path = work_directory / ('native-fluid-' + uuid_module.uuid4().hex + '.cbor')
        encoding_total = ((descriptor['last'] - descriptor['first'] + 1)
                          * len(descriptor['targets']))
        encoding_current = 0
        def report_native_encoding(frame):
            nonlocal encoding_current
            encoding_current += 1
            event('EXPORTING', f'Encoding native fluid frame {frame}',
                progress_current=encoding_current, progress_total=encoding_total,
                activity_code="ENCODING_NATIVE_FLUID")
        event('EXPORTING', 'Encoding native fluid sequence',
              progress_current=0, progress_total=encoding_total,
              activity_code="ENCODING_NATIVE_FLUID")
        encoding_started = time.monotonic()
        digest = native_fluid_payload_file(scene.param_payload, descriptor,
            payload_path, check_cancel=check_cancel,
            progress=report_native_encoding)
        seconds = time.monotonic() - encoding_started
        scene = replace(scene, param_payload=payload_path,
                        param_hash=digest, water_stream_json='')
    return PreparedSolverInputs(scene, environment, seconds)


def _extraction_targets(targets) -> tuple[results.ExtractionTarget, ...]:
    return tuple(results.ExtractionTarget(
        target.uuid, target.vertex_count, target.deformable_type,
        target.world_matrix) for target in targets)


class SolverSession:
    """Drives one complete vertical-slice run against a real PPF server."""

    def __init__(self, *, resolved: ResolvedSolver,
                 scene: SessionScene, work_directory: Path,
                 external_address: wire.ServerAddress | None = None,
                 transport: TransportConfig | None = None,
                 emit: Callable[[SessionEvent], None] | None = None,
                 cancel_event: threading.Event | None = None,
                 frame_sink: Callable[[SolverFrame], None] | None = None,
                 raw_output_sink: Callable[[str, bytes], None] | None = None,
                 hydrodynamic_environment: dict[str, str] | None = None,
                 poll_interval: float = _POLL_INTERVAL,
                 build_timeout: float = 600.0,
                 simulate_timeout: float = 600.0,
                 recovery_options: RecoveryOptions | None = None,
                 status_reconnect_grace: float = _STATUS_RECONNECT_GRACE,
                 status_reconnect_retries: int =
                 _STATUS_RECONNECT_RETRIES) -> None:
        self.resolved = resolved
        from ..ppf.official_scene_bridge import prepare_for_solver, uses_official_bridge
        scene = prepare_for_solver(scene, resolved)
        self._official_bridge = uses_official_bridge(resolved)
        self.scene = scene
        self.work_directory = work_directory
        self.transport = transport or TransportConfig(connect_timeout=5.0,
                                                      read_timeout=30.0)
        self._emit = emit or (lambda event: None)
        self._cancel = cancel_event or threading.Event()
        self._frame_sink = frame_sink or (lambda frame: None)
        # Receives every validated raw solver output file (vertex map,
        # surface map, vert_<N>.bin) by its solver-relative path. The Cloud
        # test executor archives exactly these bytes; local Bakes ignore it.
        self._raw_output_sink = raw_output_sink or (lambda path, blob: None)
        # Already prepared hydrodynamic volumes (a Cloud package) belong to the
        # caller; a local Bake prepares its own in run() and deletes them.
        self._owns_hydrodynamic_volumes = False
        if hydrodynamic_environment:
            self._hydrodynamic_environment = dict(hydrodynamic_environment)
        self._poll_interval = poll_interval
        self._build_timeout = build_timeout
        self._simulate_timeout = simulate_timeout
        if status_reconnect_grace < 0 or status_reconnect_retries < 0:
            raise ValueError("status reconnect bounds must be non-negative")
        self._status_reconnect_grace = status_reconnect_grace
        self._status_reconnect_retries = status_reconnect_retries
        self._recovery = recovery_options
        self._recovery_record: recovery.ProjectRecord | None = None
        self._known_saved_states: tuple[int, ...] = ()
        self._manager: SolverProcessManager | None = None
        self._project_link = None
        self._health_project_link = None
        self._delete_link_after_join = False
        self._address: wire.ServerAddress | None = external_address
        self._logger = get_logger("solver.session")
        self._indices_by_uuid: dict[str, np.ndarray] = {}
        self._surface_maps_by_uuid: dict[str, results.SurfaceMap] = {}
        self.diagnostics = SessionDiagnostics(project_name=scene.project_name,
                                              solver_mode=resolved.mode.name,
                                              installation_id=(
                                                  resolved.installation_id),
                                              official_release_tag=(
                                                  resolved.installation.official_release_tag
                                                  if resolved.installation
                                                  else None),
                                              data_hash=scene.data_hash,
                                              param_hash=scene.param_hash)
        if resolved.ownership is ConnectionOwnership.EXTERNAL_SERVER:
            if external_address is None:
                raise ValueError("an external server requires an address")
        elif resolved.executable_path is None:
            raise ValueError("an owned solver requires an executable path")

    # -- helpers ------------------------------------------------------------

    def _check_cancel(self) -> None:
        if self._cancel.is_set():
            raise SessionCancelled()

    def _event(self, phase: str, message: str, **kwargs) -> None:
        self.diagnostics.active_operation = str(phase)
        frame = kwargs.get("frame_current")
        if isinstance(frame, int):
            self.diagnostics.current_logical_frame = frame
        self._emit(SessionEvent(phase=phase, message=message, **kwargs))

    def _metadata_event(self) -> None:
        self._event("RUNTIME_METADATA", "Solver runtime connected",
                    process_id=self.diagnostics.process_id,
                    solver_mode=self.diagnostics.solver_mode,
                    package_version=self.diagnostics.package_version,
                    protocol_version=self.diagnostics.protocol_version,
                    schema_version=self.diagnostics.schema_version,
                    host=self.diagnostics.host, port=self.diagnostics.port,
                    solver_name=self.diagnostics.solver_name,
                    solver_backend=self.diagnostics.solver_backend,
                    solver_device=self.diagnostics.solver_device,
                    solver_telemetry=dict(self.diagnostics.solver_telemetry))

    @staticmethod
    def _reported_text(response: dict, summary: dict, *keys: str) -> str:
        for source in (response, summary):
            for key in keys:
                value = source.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
        return ""

    def _verified_solver_name(self) -> str:
        installation = self.resolved.installation
        if installation is None or not installation.verified:
            return ""
        from ..updater.engines import engine_of
        return engine_of(installation)

    def _capture_solver_details(self, response: dict) -> None:
        """Capture verified identity and only values reported by status summary."""
        exemptions = response.get("exemptions", [])
        if isinstance(exemptions, list):
            self.diagnostics.exemptions = tuple(deepcopy(exemptions))
        known = {"status", "protocol_version", "error", "crash_kind", "frame", "exemptions"}
        self.diagnostics.additive_status_fields = deepcopy(
            {key: value for key, value in response.items() if key not in known})
        summary = response.get("summary")
        if not isinstance(summary, dict):
            summary = {}
        self.diagnostics.solver_name = self._verified_solver_name()
        self.diagnostics.solver_backend = self._reported_text(
            response, summary, "solver_backend", "runtime-backend",
            "compute-backend", "backend")
        self.diagnostics.solver_device = self._reported_text(
            response, summary, "solver_device", "device-name", "device",
            "gpu-name", "gpu_name")
        keys = {
            "time-per-frame": "FRAME_TIME",
            "time-per-step": "STEP_TIME",
            "matrix-assembly": "MATRIX_ASSEMBLY",
            "pcg-linsolve": "LINEAR_SOLVE",
            "line-search": "LINE_SEARCH",
            "toi-advanced": "STEP_ADVANCED",
            "dyn-consumed": "CONTACT_MEMORY",
            "stretch": "STRETCH",
        }
        captured = {}
        for source, target in keys.items():
            value = summary.get(source)
            if (isinstance(value, (str, int, float))
                    and not isinstance(value, bool) and str(value).strip()):
                captured[target] = str(value).strip()
        self.diagnostics.solver_telemetry = captured

    def _status(self, *, allow_server_error: bool = True) -> dict:
        assert self._address is not None
        started = time.monotonic()
        self.diagnostics.status_request_count += 1
        self.diagnostics.command_in_flight = "status"
        try:
            if allow_server_error:
                try:
                    response = wire.send_tcmd(
                        self._address, self.transport, self.scene.project_name,
                        allow_server_error=True)
                except TypeError as exc:
                    # Compatibility for injected transports implementing the
                    # historical send_tcmd signature.
                    if "allow_server_error" not in str(exc):
                        raise
                    response = wire.send_tcmd(
                        self._address, self.transport, self.scene.project_name)
            else:
                response = wire.send_tcmd(
                    self._address, self.transport, self.scene.project_name)
        except ClothNextError as exc:
            latency = (time.monotonic() - started) * 1000.0
            self.diagnostics.status_latency_ms = latency
            self.diagnostics.max_status_latency_ms = max(
                self.diagnostics.max_status_latency_ms, latency)
            self.diagnostics.status_failure_count += 1
            self.diagnostics.consecutive_status_failures += 1
            match = re.search(
                r"transport_failure_phase=([A-Z_]+)",
                exc.record.technical_message)
            self.diagnostics.transport_failure_phase = (
                match.group(1) if match else "UNCLASSIFIED")
            raise
        latency = (time.monotonic() - started) * 1000.0
        self.diagnostics.status_latency_ms = latency
        self.diagnostics.max_status_latency_ms = max(
            self.diagnostics.max_status_latency_ms, latency)
        self.diagnostics.status_success_count += 1
        self.diagnostics.consecutive_status_failures = 0
        self.diagnostics.last_status_success_monotonic = time.monotonic()
        self.diagnostics.transport_failure_phase = ""
        self.diagnostics.last_successful_command = "status"
        self.diagnostics.command_in_flight = ""
        # Status errors are successful transport responses. Route them through
        # the normal failed-status decoder, including contact sidecars, rather
        # than treating them as network failures. Some servers omit status.
        if response.get("error"):
            response = {**response, "status": STATUS_FAILED}
        status = str(response.get("status", ""))
        self._capture_solver_details(response)
        self.diagnostics.note_status(status)
        previous = (tuple(item.frame for item in self._recovery_record.checkpoints)
                    if self._recovery_record is not None else ())
        saved = self._saved_states(response)
        # Lumen writes periodic states atomically but its normal RunStatus does
        # not expose the legacy ``saved_states`` collection. The files are the
        # same durable authority already used by save-and-quit recovery; use
        # them during ordinary polling as well so Auto Save is visible before
        # an artist cancels or Blender exits unexpectedly.
        if self._recovery is not None and not saved:
            saved = self._checkpoint_frames_on_disk()
        checkpoint_response = (
            response if saved == self._saved_states(response)
            else {**response, "saved_states": saved})
        self._sync_checkpoints(checkpoint_response)
        current = (tuple(item.frame for item in self._recovery_record.checkpoints)
                   if self._recovery_record is not None else ())
        if current != previous and current:
            self._event(
                "RECOVERY_SAVED",
                f"Recovery checkpoint saved · Frame {current[-1]}",
                frame_current=current[-1],
                activity_code="RECOVERY_SAVED")
        output = self._checkpoint_output_directory()
        log_with_context(self._logger, logging.DEBUG,
            "Recovery checkpoint status observed", {
                "project": self.scene.project_name,
                "server_status": status,
                "saved_states": saved,
                "checkpoint_output_directory": str(output),
                "checkpoint_files_exist": {
                    int(frame): (output / f"state_{int(frame)}.bin.gz").is_file()
                    for frame in saved},
                "verified_before": previous,
                "verified_after": current,
                "metadata_updated": previous != current,
                "metadata_path": (str(self._recovery.metadata_path)
                                  if self._recovery is not None else ""),
            })
        return response

    def _poll_status(self) -> dict:
        """Poll with bounded reconnect grace; lifecycle commands are untouched."""
        poll_started = time.monotonic()
        degraded_at: float | None = None
        retries = 0
        while True:
            try:
                response = self._status()
                if degraded_at is not None:
                    log_with_context(self._logger, logging.INFO,
                        "Solver status transport recovered", {
                            "run_id": self.diagnostics.run_id,
                            "retries": retries,
                            "degraded_seconds": round(
                                time.monotonic() - degraded_at, 3),
                            "status_latency_ms": round(
                                self.diagnostics.status_latency_ms, 3),
                        })
                return response
            except ClothNextError as exc:
                if exc.record.category is not ErrorCategory.SOLVER_CONNECTION:
                    raise
                now = time.monotonic()
                degraded_at = (poll_started if degraded_at is None
                               else degraded_at)
                if self._manager is not None and not self._manager.poll().running:
                    raise
                if self.diagnostics.transport_failure_phase not in {
                        "CONNECT_TIMEOUT", "READ_TIMEOUT",
                        "CONNECTION_REFUSED", "CONNECTION_RESET",
                        "CONNECT_ERROR", "READ_ERROR", "SEND_ERROR",
                        "UNCLASSIFIED"}:
                    raise
                elapsed = now - degraded_at
                if (retries >= self._status_reconnect_retries
                        or elapsed >= self._status_reconnect_grace):
                    raise
                retries += 1
                delay = min(2.0, self._poll_interval * (4 ** (retries - 1)))
                self._emit(SessionEvent(
                    phase="RECONNECTING",
                    message="Solver connection interrupted; reconnecting",
                    indeterminate=True))
                log_with_context(self._logger, logging.WARNING,
                    "Solver status transport degraded", {
                        "run_id": self.diagnostics.run_id,
                        "failure_phase":
                            self.diagnostics.transport_failure_phase,
                        "consecutive_status_failures":
                            self.diagnostics.consecutive_status_failures,
                        "retry": retries,
                        "retry_delay_seconds": delay,
                        "grace_seconds": self._status_reconnect_grace,
                    })
                if self._cancel.wait(delay):
                    raise SessionCancelled()

    def _runtime_activity(self) -> tuple[str, str]:
        metric_root = self._checkpoint_output_directory() / "data"
        values = {name: _tail_numeric_metric(metric_root / filename)
                  for name, filename in _SOLVER_METRICS.items()}
        if any(value is not None for value in values.values()):
            contacts = values["contacts"]
            if contacts is not None:
                self.diagnostics.contact_last = contacts
                self.diagnostics.contact_peak = max(
                    self.diagnostics.contact_peak, contacts)
                self.diagnostics.contact_samples += 1
            parts = []
            if contacts is not None:
                parts.append(f"{contacts:,} contacts")
            if values["newton"] is not None:
                parts.append(f"Newton {values['newton']}")
            if values["iterations"] is not None:
                parts.append(f"{values['iterations']:,} linear iterations")
            return "SOLVING_CONSTRAINTS", "Solver · " + " · ".join(parts)
        if self._manager is None:
            return "", ""
        poll = self._manager.poll()
        return poll.activity_code, poll.activity_message

    def _server_data_root(self) -> Path:
        """Return the run's solver-data root independently of recovery."""
        return (
            self._recovery.server_data_root
            if self._recovery is not None
            else self.work_directory / "server-data")

    def _checkpoint_output_directory(self) -> Path:
        # RECOVERY INVARIANT -- project_root is the authoritative opaque
        # solver-project location.  Reconstructing it from scene.project_name
        # loses checkpoints when a cleared/resumed generation preserves a
        # different project id.
        if self._recovery_record is not None:
            return Path(self._recovery_record.project_root) / "session" / "output"
        return (self._server_data_root() / self.scene.project_name /
                "session" / "output")

    def _checkpoint_frames_on_disk(self) -> tuple[int, ...]:
        """Return complete solver states even after its status port closes."""
        frames = []
        for path in self._checkpoint_output_directory().glob(
                "state_*.bin.gz"):
            try:
                frames.append(int(path.name[len("state_"):-len(".bin.gz")]))
            except ValueError:
                continue
        return tuple(sorted(set(frames)))

    def _wait_for_checkpoint_frames_on_disk(
            self, timeout: float = 5.0) -> tuple[int, ...]:
        """Allow the solver's final atomic state rename to finish."""
        deadline = time.monotonic() + max(0.0, timeout)
        while True:
            frames = self._checkpoint_frames_on_disk()
            if frames or time.monotonic() >= deadline:
                return frames
            time.sleep(min(self._poll_interval, 0.1))

    def _request(self, request: str) -> dict:
        assert self._address is not None
        self.diagnostics.command_in_flight = request
        response = wire.send_tcmd(self._address, self.transport,
                                  self.scene.project_name, request)
        self.diagnostics.last_successful_command = request
        self.diagnostics.command_in_flight = ""
        self.diagnostics.note_status(str(response.get("status", "")))
        if request == wire.REQUEST_SAVE_AND_QUIT:
            log_with_context(self._logger, logging.INFO,
                "Recovery checkpoint request sent", {
                    "project": self.scene.project_name,
                    "request": request,
                    "output_directory": str(self._checkpoint_output_directory()),
                    "server_status": str(response.get("status", "")),
                    "saved_states": self._saved_states(response),
                })
        return response

    def _merge_process_contacts(self, poll) -> None:
        self.diagnostics.contact_peak = max(self.diagnostics.contact_peak, poll.contact_peak)
        if poll.contact_samples:
            self.diagnostics.contact_last = poll.contact_last
            self.diagnostics.contact_samples = max(self.diagnostics.contact_samples, poll.contact_samples)

    def _capture_process_tails(self) -> None:
        if self._manager is not None:
            poll = self._manager.poll()
            self.diagnostics.stdout_tail = poll.stdout_tail
            self.diagnostics.stderr_tail = poll.stderr_tail
            self._merge_process_contacts(poll)
            self.diagnostics.control_server_alive = getattr(
                poll, "running", None)
            self.diagnostics.control_server_exit_code = getattr(
                poll, "exit_code", None)
            self.diagnostics.owned_process_ids = tuple(
                getattr(poll, "owned_process_ids", ()))
        output = self._checkpoint_output_directory()
        frames = []
        try:
            for path in output.glob("vert_*.bin"):
                try:
                    frames.append(int(path.stem.removeprefix("vert_")))
                except ValueError:
                    continue
        except OSError:
            pass
        self.diagnostics.last_output_frame = max(frames, default=None)

    def _owned_connection_error(self, exc: ClothNextError) -> ClothNextError:
        """Replace opaque socket failures with owned-process evidence."""
        executable = self.resolved.executable_path
        worker = (None if executable is None else
                  _native_worker_path(executable))
        if worker is not None and not worker.is_file():
            return ClothNextError(ErrorRecord.create(
                category=ErrorCategory.SOLVER_INSTALLATION,
                user_message=(
                    "The native solver worker is missing. Security software "
                    "may have quarantined it."),
                technical_message=(
                    f"native solver worker disappeared during the Bake: "
                    f"{worker}; original_error={exc.record.technical_message}"),
                recommended_action=(
                    "Restore or reinstall the verified solver, allow its "
                    "installation folder in the security software, then "
                    "retry the Bake."),
                recoverable=True,
                context={"failure_kind": "NATIVE_WORKER_MISSING",
                         "worker_path": str(worker)}))
        if self._manager is None:
            return exc
        self._capture_process_tails()
        poll = self._manager.poll()
        self.diagnostics.stdout_tail = poll.stdout_tail
        self.diagnostics.stderr_tail = poll.stderr_tail
        operation = self.diagnostics.active_operation
        build_violations = (
            self._load_build_violation_sidecar(phase="building")
            if operation == "BUILDING" else ())
        count_matches = re.findall(
            r"(\d+)\s+self[- ]intersections?",
            " ".join((exc.record.technical_message, str(poll.stdout_tail),
                      str(poll.stderr_tail))), re.IGNORECASE)
        solver_total_count = max(
            [len(build_violations), *(int(value) for value in count_matches)],
            default=0)
        if not poll.running:
            error = self._manager.early_exit_error(poll)
            final_poll = getattr(self._manager, "final_poll", None)
            poll = final_poll() if final_poll is not None else poll
            record = error.record
            frame = self.diagnostics.current_logical_frame
            if operation == "STARTING_SOLVER":
                user_message = (
                    f"The solver exited during startup with code "
                    f"{format_windows_exit_code(poll.exit_code)}.")
                failure_kind = "CRASH_BEFORE_READY"
            elif operation == "RUNTIME_METADATA":
                user_message = (
                    "The solver exited immediately after becoming ready.")
                failure_kind = "CRASH_AFTER_READY"
            elif operation == "UPLOADING":
                user_message = "The solver crashed while transferring the scene."
                failure_kind = "CRASH_DURING_SCENE_TRANSFER"
            elif operation == "BUILDING":
                user_message = (
                    "The solver crashed while building the simulation project.")
                failure_kind = "CRASH_DURING_PROJECT_BUILD"
            elif operation == "FETCHING":
                user_message = "The solver crashed while fetching frame data."
                failure_kind = "CRASH_DURING_FRAME_FETCH"
            elif operation == "SIMULATING" and frame is not None:
                user_message = f"The solver exited while simulating frame {frame}."
                failure_kind = "CRASH_DURING_SIMULATION"
            else:
                user_message = record.user_message
                failure_kind = "UNEXPECTED_PROCESS_EXIT"
            return ClothNextError(ErrorRecord.create(
                category=record.category,
                user_message=user_message,
                technical_message=(
                    f"failure_kind={failure_kind}; "
                    f"run_id={self.diagnostics.run_id}; "
                    f"active_operation={operation}; "
                    f"current_logical_frame={frame}; "
                    f"last_completed_logical_frame="
                    f"{self.diagnostics.last_completed_logical_frame}; "
                    f"last_fetched_frame={self.diagnostics.last_fetched_frame}; "
                    f"last_successful_command="
                    f"{self.diagnostics.last_successful_command}; "
                    f"command_in_flight={self.diagnostics.command_in_flight}; "
                    f"last_valid_health_response="
                    f"{self.diagnostics.last_valid_health_response}; "
                    f"{record.technical_message}; ipc_endpoint="
                    f"{self._address.host}:{self._address.port}; "
                    f"last_output_frame={self.diagnostics.last_output_frame}"),
                recommended_action=record.recommended_action,
                recoverable=True,
                context={
                    "control_server_pid": poll.process_id,
                    "control_server_exit_code":
                        format_windows_exit_code(poll.exit_code),
                    "owned_process_ids": poll.owned_process_ids,
                    "failure_kind": failure_kind,
                    "solver_launch_id": getattr(poll, "launch_id", ""),
                    "active_operation": operation,
                    "current_logical_frame": frame,
                    "last_completed_logical_frame":
                        self.diagnostics.last_completed_logical_frame,
                    "last_fetched_frame": self.diagnostics.last_fetched_frame,
                    "last_output_frame": self.diagnostics.last_output_frame,
                    "ipc_host": self._address.host,
                    "ipc_port": self._address.port}),
                violations=build_violations,
                solver_total_count=solver_total_count)
        record = exc.record
        frame = self.diagnostics.current_logical_frame
        status_age = (None if self.diagnostics.last_status_success_monotonic
                      is None else max(
                          0.0, time.monotonic()
                          - self.diagnostics.last_status_success_monotonic))
        return ClothNextError(ErrorRecord.create(
            category=record.category,
            user_message=(
                "The solver connection was lost, but the process is still "
                "running."),
            technical_message=(
                f"failure_kind=TRANSPORT_LOST_PROCESS_ALIVE; "
                f"run_id={self.diagnostics.run_id}; "
                f"active_operation={operation}; "
                f"current_logical_frame={frame}; "
                f"last_completed_logical_frame="
                f"{self.diagnostics.last_completed_logical_frame}; "
                f"last_successful_command="
                f"{self.diagnostics.last_successful_command}; "
                f"command_in_flight={self.diagnostics.command_in_flight}; "
                f"transport_failure_phase="
                f"{self.diagnostics.transport_failure_phase}; "
                f"status_request_count="
                f"{self.diagnostics.status_request_count}; "
                f"status_success_count="
                f"{self.diagnostics.status_success_count}; "
                f"status_failure_count="
                f"{self.diagnostics.status_failure_count}; "
                f"consecutive_transport_failures="
                f"{self.diagnostics.consecutive_status_failures}; "
                f"seconds_since_last_valid_status={status_age}; "
                f"status_latency_ms="
                f"{self.diagnostics.status_latency_ms:.3f}; "
                f"max_status_latency_ms="
                f"{self.diagnostics.max_status_latency_ms:.3f}; "
                f"{record.technical_message}; "
                f"owned_process_id={poll.process_id}; "
                f"stdout_tail={poll.stdout_tail}; "
                f"stderr_tail={poll.stderr_tail}; "
                f"progress_tail={poll.progress.tail}"),
            recommended_action=record.recommended_action,
            recoverable=record.recoverable,
            context={"process_id": poll.process_id,
                     "exit_code": poll.exit_code,
                     "failure_kind": "TRANSPORT_LOST_PROCESS_ALIVE",
                     "transport_failure_phase":
                         self.diagnostics.transport_failure_phase,
                     "consecutive_transport_failures":
                         self.diagnostics.consecutive_status_failures,
                     "seconds_since_last_valid_status": status_age,
                     "control_server_alive": poll.running,
                     "owned_process_ids": poll.owned_process_ids,
                     "active_operation": operation,
                     "current_logical_frame": frame}),
            violations=build_violations,
            solver_total_count=solver_total_count)

    def _external_connection_error(
            self, exc: ClothNextError) -> ClothNextError:
        """Add endpoint/mode evidence without claiming ownership or cleanup."""
        assert self._address is not None
        record = exc.record
        status_age = (None if self.diagnostics.last_status_success_monotonic
                      is None else max(
                          0.0, time.monotonic()
                          - self.diagnostics.last_status_success_monotonic))
        if ("invalid response" in record.user_message.casefold()
                or "response was too large" in record.user_message.casefold()):
            message = record.user_message
            failure_kind = "MALFORMED_HEALTH_RESPONSE"
        elif self.diagnostics.active_operation == "STARTING_SOLVER":
            message = (
                "The configured external solver server could not be reached "
                f"at {self._address.host}:{self._address.port}.")
            failure_kind = "EXTERNAL_SERVER_UNREACHABLE"
        else:
            message = (
                "The solver connection was lost. The external process was "
                "not modified.")
            failure_kind = "EXTERNAL_TRANSPORT_LOST"
        return ClothNextError(ErrorRecord.create(
            category=record.category,
            user_message=message,
            technical_message=(
                f"failure_kind={failure_kind}; "
                f"run_id={self.diagnostics.run_id}; "
                f"active_operation={self.diagnostics.active_operation}; "
                f"last_successful_command="
                f"{self.diagnostics.last_successful_command}; "
                f"command_in_flight={self.diagnostics.command_in_flight}; "
                f"transport_failure_phase="
                f"{self.diagnostics.transport_failure_phase}; "
                f"consecutive_transport_failures="
                f"{self.diagnostics.consecutive_status_failures}; "
                f"seconds_since_last_valid_status={status_age}; "
                f"endpoint={self._address.host}:{self._address.port}; "
                f"original_error={record.technical_message}"),
            recommended_action=record.recommended_action,
            recoverable=record.recoverable,
            context={"failure_kind": failure_kind,
                     "ownership": "EXTERNAL_SERVER",
                     "transport_failure_phase":
                         self.diagnostics.transport_failure_phase,
                     "consecutive_transport_failures":
                         self.diagnostics.consecutive_status_failures,
                     "seconds_since_last_valid_status": status_age,
                     "host": self._address.host,
                     "port": self._address.port},
            exception=exc))

    def _with_recovery_evidence(
            self, exc: ClothNextError) -> ClothNextError:
        """Attach post-failure recovery facts without weakening the cause."""
        record = self._recovery_record
        if record is None:
            return exc
        options = self._recovery
        assert options is not None
        # The claim must match what the resume gate will accept: verify the
        # durable metadata through the same evaluator used at resume time.
        eligibility = recovery.evaluate_resumable(
            options.metadata_path, options.identity)
        checkpoint_frame = (
            eligibility.latest_checkpoint_frame
            if eligibility.latest_checkpoint_frame > 0 else None)
        partial_paths = tuple(
            path for _uuid, path in record.partial_pc2
            if Path(path).is_file())
        if checkpoint_frame is not None:
            recovery_message = (
                f"A recovery checkpoint is available from frame "
                f"{checkpoint_frame}.")
        else:
            recovery_message = (
                "No verified recovery checkpoint is available.")
        source = exc.record
        return ClothNextError(ErrorRecord.create(
            category=source.category,
            user_message=f"{source.user_message} {recovery_message}",
            technical_message=(
                f"{source.technical_message}; "
                f"recovery_state={record.state.value}; "
                f"recovery_checkpoint_frame={checkpoint_frame}; "
                f"recovery_resumable={eligibility.resumable}; "
                f"partial_cache_candidates={partial_paths}"),
            recommended_action=source.recommended_action,
            recoverable=source.recoverable,
            context={
                **{key: value for key, value in source.context},
                "recovery_state": record.state.value,
                "recovery_checkpoint_frame": checkpoint_frame,
                "partial_cache_candidates": partial_paths,
            },
            exception=exc), violations=exc.violations,
            solver_total_count=exc.solver_total_count)

    def _fail_from_status(self, response: dict, phase: str) -> ClothNextError:
        self._capture_process_tails()
        error_text = str(response.get("error", "") or "no server error text")
        executable = self.resolved.executable_path
        if (self.resolved.ownership is ConnectionOwnership.OWNED_PROCESS
                and executable is not None):
            worker = _native_worker_path(executable)
            if not worker.is_file():
                return _missing_worker_error(
                    worker, detail=f"server_error={error_text}")
        crash_kind_value = response.get("crash_kind", "")
        crash_kind = (crash_kind_value.strip()
                      if isinstance(crash_kind_value, str) else "")
        abnormal = re.search(
            r"Solver exited abnormally: pid\s+(\d+)\s+stopped after frame\s+"
            r"(\d+)\s+without writing a terminal outcome",
            error_text, re.IGNORECASE)
        if abnormal is not None:
            pid, completed = int(abnormal.group(1)), int(abnormal.group(2))
            self.diagnostics.last_completed_logical_frame = completed
            self.diagnostics.current_logical_frame = completed + 1
            return _session_error(
                f"The solver exited while simulating frame {completed + 1}.",
                f"failure_kind=SOLVER_WORKER_ABNORMAL_EXIT; "
                f"solver_worker_pid={pid}; "
                f"last_completed_logical_frame={completed}; "
                f"crash_kind={crash_kind or 'unclassified'}; "
                f"server_error={error_text}; "
                f"stdout_tail={self.diagnostics.stdout_tail}; "
                f"stderr_tail={self.diagnostics.stderr_tail}",
                category=ErrorCategory.SIMULATION,
                context={"failure_kind": "SOLVER_WORKER_ABNORMAL_EXIT",
                         "crash_kind": crash_kind,
                         "active_operation": "SIMULATING"})
        parsed_violations = list(_normalize_violation_payload(
            response.get("violations", ())))
        if not parsed_violations:
            parsed_violations = list(self._load_build_violation_sidecar(
                phase=phase))
        if not parsed_violations and phase == "simulating":
            parsed_violations = list(
                self._load_runtime_intersection_sidecar(phase=phase))
        reported_counts = []
        for key in ("total_count", "intersection_count",
                    "n_self_intersections_total"):
            try:
                reported_counts.append(int(response[key]))
            except (KeyError, TypeError, ValueError):
                pass
        reported_counts.extend(
            int(match.group(1)) for match in re.finditer(
                r"(\d+)\s+self[- ]intersections?", error_text,
                re.IGNORECASE))
        solver_total_count = max(
            [len(parsed_violations), *reported_counts], default=0)
        log_with_context(self._logger, logging.INFO,
            "Solver contact diagnostics decoded", {
                "phase": phase,
                "solver_total": solver_total_count,
                "status_payload_pairs": len(_normalize_violation_payload(
                    response.get("violations", ()))),
                "session_decoder_pairs": len(parsed_violations),
            })
        user_message = (
            f"The solver crashed while {phase} ({crash_kind})."
            if crash_kind else f"The solver reported a failure while {phase}.")
        error = _session_error(
            user_message,
            f"server status FAILED during {phase}: {error_text}; "
            f"crash_kind={crash_kind or 'none'}; "
            f"contacts(last={self.diagnostics.contact_last}, "
            f"peak={self.diagnostics.contact_peak}, "
            f"samples={self.diagnostics.contact_samples}); "
            f"stdout_tail={self.diagnostics.stdout_tail}; "
            f"stderr_tail={self.diagnostics.stderr_tail}",
            context={"crash_kind": crash_kind,
                     "active_operation": phase.upper()})
        if parsed_violations:
            log_with_context(self._logger, logging.ERROR,
                "Solver returned structured build violations", {
                    "project": self.scene.project_name,
                    "phase": phase,
                    "violation_count": len(parsed_violations),
                    "preview_count": min(10, len(parsed_violations)),
                })
            return ClothNextError(
                error.record, violations=tuple(parsed_violations),
                solver_total_count=solver_total_count)
        return ClothNextError(
            error.record, solver_total_count=solver_total_count)

    def _load_runtime_intersection_sidecar(
            self, *, phase: str) -> tuple[dict, ...]:
        """Capture the failed solver step before project cleanup removes it."""
        server_root = self._server_data_root().resolve()
        project_root = (server_root / self.scene.project_name).resolve()
        try:
            project_root.relative_to(server_root)
        except ValueError:
            return ()
        path = (
            project_root / "session" / "output"
            / "intersection_records.json")
        deadline = time.monotonic() + _VIOLATION_SIDECAR_CONFIRM_TIMEOUT
        while not path.is_file() and time.monotonic() < deadline:
            time.sleep(0.05)
        try:
            size = path.stat().st_size
            if size <= 0 or size > _MAX_VIOLATION_SIDECAR_BYTES:
                return ()
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, UnicodeError,
                json.JSONDecodeError, ValueError):
            return ()
        records = payload.get("records") if isinstance(payload, dict) else None
        if not isinstance(records, list):
            return ()
        violations = []
        for record in records:
            if not isinstance(record, dict):
                continue
            triangles = []
            for key in ("positions0", "positions1"):
                positions = record.get(key)
                if isinstance(positions, (list, tuple)):
                    if (len(positions) == 9
                            and all(isinstance(value, (int, float))
                                    for value in positions)):
                        positions = [positions[index:index + 3]
                                     for index in range(0, 9, 3)]
                    if (len(positions) == 3
                            and all(isinstance(point, (list, tuple))
                                    and len(point) == 3
                                    for point in positions)):
                        try:
                            triangle = [
                                [float(value) for value in point]
                                for point in positions]
                            if np.isfinite(np.asarray(triangle)).all():
                                triangles.append(triangle)
                        except (TypeError, ValueError):
                            pass
            if not triangles:
                continue
            violations.append({
                "type": str(record.get("type", "runtime_intersection")),
                "tris": triangles,
                "detection_method": "SOLVER_RUNTIME_RECORD",
                "runtime_elements": [
                    record.get("elem0"), record.get("elem1")],
            })
        previews = tuple(violations)
        if previews:
            log_with_context(
                self._logger, logging.ERROR,
                "Loaded runtime intersection records", {
                    "project": self.scene.project_name,
                    "phase": phase,
                    "path": str(path),
                    "record_count": len(records),
                    "preview_count": len(previews),
                })
        return previews

    def _load_build_violation_sidecar(self, *, phase: str) -> tuple[dict, ...]:
        """Read the managed frontend's structured build-error handoff.

        The pinned server does not expose this payload in its status response.
        Its build worker writes it beneath the already-known project root
        instead, so this is the authoritative local fallback for managed and
        other filesystem-visible solver installations.
        """
        server_root = self._server_data_root().resolve()
        project_root = (server_root / self.scene.project_name).resolve()
        try:
            project_root.relative_to(server_root)
        except ValueError:
            log_with_context(
                self._logger, logging.ERROR,
                "Rejected build violation sidecar outside server data root", {
                    "project": self.scene.project_name,
                    "phase": phase,
                    "server_data_root": str(server_root),
                    "project_root": str(project_root),
                })
            return ()
        path = project_root / "build_violations.json"
        mirror = server_root / (
            f"{self.scene.project_name}.build_violations.json")
        deadline = time.monotonic() + _VIOLATION_SIDECAR_CONFIRM_TIMEOUT
        while not path.is_file() and not mirror.is_file():
            if time.monotonic() >= deadline:
                break
            time.sleep(0.05)
        if not path.is_file() and mirror.is_file():
            path = mirror
        try:
            size = path.stat().st_size
        except FileNotFoundError:
            return ()
        except OSError as exc:
            log_with_context(
                self._logger, logging.WARNING,
                "Could not inspect build violation sidecar", {
                    "project": self.scene.project_name,
                    "phase": phase, "path": str(path), "reason": str(exc),
                })
            return ()
        if size <= 0 or size > _MAX_VIOLATION_SIDECAR_BYTES:
            log_with_context(
                self._logger, logging.WARNING,
                "Rejected invalid build violation sidecar size", {
                    "project": self.scene.project_name,
                    "phase": phase, "path": str(path), "size": size,
                    "maximum": _MAX_VIOLATION_SIDECAR_BYTES,
                })
            return ()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            log_with_context(
                self._logger, logging.WARNING,
                "Could not parse build violation sidecar", {
                    "project": self.scene.project_name,
                    "phase": phase, "path": str(path), "reason": str(exc),
                })
            return ()
        raw = payload.get("violations") if isinstance(payload, dict) else None
        if not isinstance(raw, list):
            log_with_context(
                self._logger, logging.WARNING,
                "Rejected malformed build violation sidecar", {
                    "project": self.scene.project_name,
                    "phase": phase, "path": str(path),
                })
            return ()
        previews = _normalize_violation_payload(raw)
        log_with_context(
            self._logger, logging.ERROR,
            "Loaded structured build violations from solver sidecar", {
                "project": self.scene.project_name,
                "phase": phase, "path": str(path),
                "violation_count": len(previews),
                "preview_count": len(previews),
            })
        return previews

    # -- lifecycle ----------------------------------------------------------

    def _recovery_start(self) -> None:
        options = self._recovery
        if options is None or not options.enabled:
            return
        path = options.metadata_path
        recovery.cleanup_temporary_files(path.parent)
        log_with_context(self._logger, logging.INFO,
            "Recovery checkpoint configuration", {
                "project": self.scene.project_name,
                "enabled": options.enabled,
                "auto_save_interval": options.auto_save_interval,
                "keep_saved_states": options.keep_saved_states,
                "save_on_cancel": options.save_on_cancel,
                "save_on_finish": options.keep_on_finish,
                "server_data_root": str(options.server_data_root),
                "checkpoint_output_directory": str(
                    self._checkpoint_output_directory()),
                "metadata_path": str(path),
                "resume": options.resume,
            })
        if options.resume:
            record = recovery.load_project(path)
            if record is None:
                raise _session_error(
                    "The recovery project is no longer available.",
                    f"invalid recovery metadata at {path}")
            match = recovery.compatibility(record.identity, options.identity)
            if not match.compatible:
                raise _session_error(
                    "The saved Bake is not compatible with this scene.",
                    match.reason)
            if record.project_id != self.scene.project_name:
                raise _session_error(
                    "The recovery project identity does not match.",
                    f"metadata project {record.project_id!r}, current "
                    f"{self.scene.project_name!r}")
            self._recovery_record = recovery.transition(
                path, record, recovery.ProjectState.RESUMING)
            return
        project_root = options.server_data_root / self.scene.project_name
        self._recovery_record = recovery.create_project(
            path, project_id=self.scene.project_name,
            identity=options.identity,
            server_data_root=options.server_data_root,
            project_root=project_root,
            partial_pc2=options.partial_pc2)
        self._recovery_record = recovery.transition(
            path, self._recovery_record, recovery.ProjectState.RUNNING)

    @staticmethod
    def _saved_states(response: dict) -> tuple[int, ...]:
        values = response.get("saved_states", ())
        if not isinstance(values, (list, tuple)):
            return ()
        return tuple(sorted({
            int(value) for value in values
            if isinstance(value, int) and value >= 0}))

    def _sync_checkpoints(self, response: dict) -> None:
        options, record = self._recovery, self._recovery_record
        if options is None or record is None:
            return
        saved = self._saved_states(response)
        self._known_saved_states = saved
        confirmed = tuple(item.frame for item in record.checkpoints)
        if saved == confirmed:
            return
        self._recovery_record = recovery.confirm_saved_states(
            options.metadata_path, record, saved,
            keep=options.keep_saved_states)

    def _start_owned_solver(self) -> None:
        executable = self.resolved.executable_path
        assert executable is not None
        worker = _native_worker_path(executable)
        if not worker.is_file():
            raise ClothNextError(ErrorRecord.create(
                category=ErrorCategory.SOLVER_INSTALLATION,
                user_message=(
                    "The native solver worker is missing. Security software "
                    "may have quarantined it."),
                technical_message=f"native solver worker is missing: {worker}",
                recommended_action=(
                    "Restore or reinstall the verified solver, allow its "
                    "installation folder in the security software, then "
                    "retry the Bake."),
                recoverable=True,
                context={"failure_kind": "NATIVE_WORKER_MISSING",
                         "worker_path": str(worker)}))
        root = bundle_root_for(executable)
        layout = BundledSolverLayout.from_root(root)
        server_data = self._server_data_root()
        io_path(server_data).mkdir(parents=True, exist_ok=True)
        environment = dict(layout.process_environment())
        environment.update(getattr(self, '_hydrodynamic_environment', {}))
        # GAIA's reproducible mode; inherited PPF_REPRO_* never reach a solver
        # (SolverProcessConfig.subprocess_environment drops them).
        environment.update(dict(getattr(self.resolved, "solver_environment", ()) or ()))
        if self._official_bridge:
            # Public scene preparation is a sibling of the control server.
            # The official worker mode prevents its native metadata probes
            # from being adopted as this server's solve (monitor.rs).
            environment['PPF_SOLVER_SCAN_DESCENDANTS'] = '1'
        from ..ppf.backend_selection import selected_backend, verify_backend_status
        backend_identity = selected_backend(root, executable)
        if backend_identity is not None:
            # Gaia's worker follows CARGO_TARGET_DIR, independently of the
            # control-server binary's directory. Pin both to one build.
            environment["CARGO_TARGET_DIR"] = str(backend_identity[1])
        # Pin the per-project server data below our own work directory so
        # the run's cache never lands in unrelated user locations.
        environment["PPF_CTS_DATA_ROOT"] = "" if self._official_bridge else str(server_data)
        port = free_port()
        config = SolverProcessConfig(
            executable_path=executable,
            working_directory=root,
            host="127.0.0.1",
            port=port,
            startup_timeout=120.0,
            connect_timeout=self.transport.connect_timeout,
            read_timeout=self.transport.read_timeout,
            ownership_mode=ConnectionOwnership.OWNED_PROCESS,
            environment=tuple(sorted(environment.items())),
        )
        self._manager = SolverProcessManager(config)
        # Startup errors are classified before start_owned_and_wait returns.
        # Keep the selected endpoint available to that diagnostic path too.
        self._address = wire.ServerAddress(config.host, config.port)
        if self._official_bridge:
            from ..ppf.project_links import ProjectLink, canonical_project_path
            project_link = ProjectLink(
                canonical_project_path(executable, self.scene.project_name,
                    environment=config.subprocess_environment()),
                (server_data / self.scene.project_name).resolve(),
                owned_root=server_data.resolve(), project_name=self.scene.project_name)
            project_link.ensure()
            self._project_link = project_link
        health_project = self.scene.project_name
        if self._recovery is not None and self._recovery.resume:
            # The saved project's terminal status describes the deliberately
            # interrupted worker, not the newly started control server. Probe
            # server identity on an isolated name, then reconcile the real
            # recovery project after readiness has been established.
            health_project = f"{self.scene.project_name}_health_probe"
            if self._official_bridge:
                health_link = ProjectLink(
                    self._project_link.path.with_name(health_project),
                    (server_data / "health" / health_project).resolve(),
                    owned_root=server_data.resolve(), project_name=health_project)
                health_link.ensure()
                self._health_project_link = health_link
        health = start_owned_and_wait(self._manager, health_project)
        if self._official_bridge:
            response = self._status()
            observed = Path(str(response["root"])).absolute()
            if observed != self._project_link.path:
                raise self._project_link._fail(
                    f"server project path differs from prepared alias: {observed}", owned=True)
        if backend_identity is not None:
            try:
                verify_backend_status(backend_identity, self._status())
            except ValueError as exc:
                raise ClothNextError(ErrorRecord.create(
                    category=ErrorCategory.SOLVER_INSTALLATION,
                    user_message="The selected solver backend did not start.",
                    technical_message=str(exc),
                    recommended_action="Reinstall the selected official solver release.",
                    recoverable=True,
                    exception=exc)) from exc
        poll = self._manager.poll()
        self.diagnostics.host, self.diagnostics.port = config.host, config.port
        self.diagnostics.process_id = poll.process_id
        self.diagnostics.solver_launch_id = poll.launch_id
        self.diagnostics.package_version = health.package_version
        self.diagnostics.protocol_version = health.protocol_version
        self.diagnostics.schema_version = health.schema_version
        self.diagnostics.last_valid_health_response = {
            "reachable": health.reachable,
            "compatible": health.compatible,
            "package_version": health.package_version,
            "protocol_version": health.protocol_version,
            "schema_version": health.schema_version,
            "wire_status": health.wire_status,
        }
        self.diagnostics.last_successful_stage = "READY"

    def _upload(self) -> None:
        assert self._address is not None
        def payload_size(payload) -> int:
            if isinstance(payload, (str, Path)):
                return Path(payload).stat().st_size
            return len(payload)

        data_bytes = payload_size(self.scene.data_payload)
        param_bytes = payload_size(self.scene.param_payload)
        total_bytes = data_bytes + param_bytes
        self.diagnostics.upload_data_bytes = data_bytes
        self.diagnostics.upload_param_bytes = param_bytes
        self.diagnostics.upload_total_bytes = total_bytes
        self._event(
            "UPLOADING",
            f"Uploading scene · {total_bytes / (1024 * 1024):.1f} MiB",
            indeterminate=True)
        log_with_context(
            self._logger, logging.INFO, "Uploading solver payloads", {
                "project": self.scene.project_name,
                "data_bytes": data_bytes,
                "param_bytes": param_bytes,
                "total_bytes": total_bytes,
                "upload_write_timeout_seconds":
                    self.transport.upload_write_timeout,
            })
        wire.upload_atomic(self._address, self.transport,
                           project_name=self.scene.project_name,
                           data_payload=self.scene.data_payload,
                           param_payload=self.scene.param_payload,
                           data_hash=self.scene.data_hash,
                           param_hash=self.scene.param_hash,
                           check_cancel=self._check_cancel)
        response = self._status()
        upload_id = str(response.get("upload_id", ""))
        if not upload_id:
            raise _session_error("The solver did not acknowledge the upload.",
                                 "status has no upload_id after upload_atomic")
        for label, expected, key in (("data", self.scene.data_hash, "data_hash"),
                                     ("param", self.scene.param_hash,
                                      "param_hash")):
            echoed = str(response.get(key, ""))
            if echoed != expected:
                raise _session_error(
                    "The solver acknowledged different payloads than were sent.",
                    f"{label} hash mismatch after upload: sent {expected}, "
                    f"server reports {echoed!r}")
        data_state = str(response.get("data", ""))
        if data_state == STATUS_NO_DATA:
            raise _session_error("The upload did not reach the solver project.",
                                 f"status.data == NO_DATA after upload "
                                 f"(status={response.get('status')!r})")
        self.diagnostics.upload_id = upload_id
        self.diagnostics.bytes_transferred += total_bytes
        self.diagnostics.last_successful_stage = "SCENE_TRANSFER"

    def _await_build(self) -> None:
        deadline = time.monotonic() + self._build_timeout
        while True:
            self._check_cancel()
            response = self._poll_status()
            status = str(response.get("status", ""))
            if status == STATUS_READY:
                self.diagnostics.last_successful_stage = "PROJECT_BUILD"
                return
            if status == STATUS_FAILED:
                raise self._fail_from_status(response, "building")
            if status == STATUS_BUILDING:
                progress = response.get("progress")
                info = str(response.get("info", "") or "Building solver project")
                activity_code, activity_message = self._runtime_activity()
                if activity_message:
                    info = activity_message
                if isinstance(progress, (int, float)):
                    self._event("BUILDING", info,
                                progress_current=int(progress * 100),
                                progress_total=100,
                                activity_code=activity_code)
                else:
                    self._event("BUILDING", info, indeterminate=True,
                                activity_code=activity_code)
            elif status == STATUS_BUSY:
                # Protocol 0.13 / Schema 2 may publish BUSY briefly after its
                # worker reports "Build complete" and before the project
                # settles on READY.  No start request has been sent yet, so
                # this is a bounded build-finalization state, not simulation.
                self._event(
                    "BUILDING", "Finalizing solver project",
                    indeterminate=True)
            elif status == STATUS_SAVE_AND_QUIT:
                raise _session_error(
                    "The solver project is unexpectedly busy.",
                    f"status {status} while waiting for the build")
            if time.monotonic() > deadline:
                raise _session_error("The solver build timed out.",
                                     f"no READY status within "
                                     f"{self._build_timeout}s")
            time.sleep(self._poll_interval)

    def _apply_official_bindings(self) -> None:
        if not self._official_bridge:
            return
        document = json.loads(self.scene.official_bridge_json)
        if (not document["stitches"] and not document["face_friction"]
                and not document.get("face_material_params")):
            return
        if self._manager is None or self.resolved.executable_path is None:
            raise _session_error(
                "This solver needs a local official frontend for Sewing.",
                "official per-row API requires the selected local installation",
                category=ErrorCategory.PROTOCOL_COMPATIBILITY)
        root = bundle_root_for(self.resolved.executable_path)
        python = (root / "python" / "python.exe" if os.name == "nt"
                  else root / "python" / "bin" / "python3")
        if not python.is_file():
            raise _session_error("The official solver Python runtime is missing.", str(python),
                                 category=ErrorCategory.SOLVER_INSTALLATION)
        bindings = self.work_directory / "official-scene-bindings.json"
        bindings.write_text(self.scene.official_bridge_json, encoding="utf-8")
        worker = Path(__file__).resolve().parents[1] / "ppf" / "official_scene_worker.py"
        project_root = self._server_data_root() / self.scene.project_name
        log = self.work_directory / "official-scene-bindings.log"
        self._event("BUILDING", "Preserving authored seam strengths", indeterminate=True)
        options = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        with log.open("wb") as stream:
            process = subprocess.Popen(
                [str(python), str(worker), "--project-name", self.scene.project_name,
                 "--project-root", str(project_root), "--bindings", str(bindings)],
                cwd=root, env=self._manager.config.subprocess_environment(),
                stdout=stream, stderr=stream, stdin=subprocess.DEVNULL, shell=False, **options)
            deadline = time.monotonic() + self._build_timeout
            try:
                while process.poll() is None:
                    self._check_cancel()
                    if time.monotonic() >= deadline:
                        raise _session_error("Official scene preparation timed out.", str(log))
                    time.sleep(self._poll_interval)
            finally:
                if process.poll() is None:
                    process.kill()
                process.wait()
        if process.returncode != 0:
            detail = log.read_text(encoding="utf-8", errors="replace")[-8192:]
            raise _session_error("The official solver could not preserve this scene.", detail)

    def _fetch_output_map(self) -> results.OutputMap:
        assert self._address is not None
        blob = wire.data_receive(self._address, self.transport,
                                 project_name=self.scene.project_name,
                                 path=results.MAP_PATH)
        schema_version = int(self.resolved.schema_version or "1")
        self.diagnostics.bytes_transferred += len(blob)
        targets = self.scene.dynamic_objects
        surface_blob = None
        if any(target.deformable_type == "SOLID" for target in targets):
            surface_blob = wire.data_receive(
                self._address, self.transport,
                project_name=self.scene.project_name,
                path=results.SURFACE_MAP_PATH)
            self.diagnostics.bytes_transferred += len(surface_blob)
        output_map, extraction = results.prepare_output_extraction(
            blob, surface_blob, _extraction_targets(targets),
            schema_version=schema_version)
        self._indices_by_uuid = dict(extraction.indices_by_uuid)
        self._surface_maps_by_uuid = dict(extraction.surface_maps_by_uuid)
        self._raw_output_sink(results.MAP_PATH, blob)
        if surface_blob is not None:
            self._raw_output_sink(results.SURFACE_MAP_PATH, surface_blob)
        return output_map

    def _fetch_frame(self, output_map: results.OutputMap,
                     frame: int) -> SolverFrame:
        assert self._address is not None
        step = time.monotonic()
        blob = wire.data_receive(self._address, self.transport,
                                 project_name=self.scene.project_name,
                                 path=results.frame_file_path(frame))
        self.diagnostics.timings["frame_transfer"] = (
            self.diagnostics.timings.get("frame_transfer", 0.0)
            + time.monotonic() - step)
        self.diagnostics.bytes_transferred += len(blob)
        step = time.monotonic()
        positions = results.decode_frame_payload_numpy(blob)
        self.diagnostics.timings["frame_decode"] = (
            self.diagnostics.timings.get("frame_decode", 0.0)
            + time.monotonic() - step)
        self._raw_output_sink(results.frame_file_path(frame), blob)
        step = time.monotonic()
        targets = self.scene.dynamic_objects
        positions_by_uuid = results.extract_dynamic_frame(
            positions, results.OutputExtraction(
                self._indices_by_uuid, self._surface_maps_by_uuid),
            _extraction_targets(targets), frame=frame)
        self.diagnostics.timings["frame_extract"] = (
            self.diagnostics.timings.get("frame_extract", 0.0)
            + time.monotonic() - step)
        first = positions_by_uuid[targets[0].uuid]
        return SolverFrame(frame, first, positions_by_uuid)

    def _simulate_and_fetch(self, *, resume: bool = False) -> None:
        if self.scene.water_stream_json:
            return self._stream_water_and_fetch(resume=resume)
        total = self.scene.solver_frame_count
        if resume:
            assert self._address is not None
            response = wire.send_tcmd(
                self._address, self.transport, self.scene.project_name,
                wire.REQUEST_RESUME)
            self.diagnostics.note_status(str(response.get("status", "")))
        else:
            self._request(REQUEST_START_ALIAS)
        output_map: results.OutputMap | None = None
        fetched: set[int] = set(
            self._recovery.completed_solver_frames
            if self._recovery is not None and resume else ())
        deadline = time.monotonic() + self._simulate_timeout
        finished_status: str | None = None
        while len(fetched) < total:
            self._check_cancel()
            wait_step = time.monotonic()
            response = self._poll_status()
            self.diagnostics.timings["simulation_wait"] = (
                self.diagnostics.timings.get("simulation_wait", 0.0)
                + time.monotonic() - wait_step)
            status = str(response.get("status", ""))
            solver_frame = response.get("frame")
            available = solver_frame if isinstance(solver_frame, int) else 0
            if status == STATUS_FAILED:
                raise self._fail_from_status(response, "simulating")
            if status in (STATUS_READY, STATUS_RESUMABLE):
                # Terminal without failure: everything produced is on disk.
                finished_status = status
                available = total
            if available > 0 and output_map is None:
                self._event("FETCHING", "Downloading solver output map",
                            indeterminate=True)
                output_map = self._fetch_output_map()
            for frame in range(1, min(available, total) + 1):
                if frame in fetched:
                    continue
                self._check_cancel()
                assert output_map is not None
                self._event("FETCHING",
                            f"Downloading frame {frame} of {total}",
                            frame_current=frame, frame_total=total)
                try:
                    solver_output = self._fetch_frame(output_map, frame)
                except ClothNextError as exc:
                    if finished_status is None:
                        raise
                    raise _session_error(
                        "The solver finished without producing every frame.",
                        "finished without producing every frame: "
                        f"status {finished_status}; frame {frame} could not be "
                        f"read after completion: {exc}") from exc
                self._frame_sink(solver_output)
                fetched.add(frame)
                self.diagnostics.fetched_frames.append(frame)
                self.diagnostics.last_fetched_frame = frame
                self.diagnostics.last_completed_logical_frame = frame
                deadline = time.monotonic() + self._simulate_timeout
            if len(fetched) >= total:
                break
            if finished_status is not None and len(fetched) < total:
                raise _session_error(
                    "The solver finished without producing every frame.",
                    f"status {finished_status} with only "
                    f"{sorted(fetched)} of {total} frames on disk")
            if status in (STATUS_BUSY, STATUS_SAVE_AND_QUIT, STATUS_BUILDING):
                current = min(available + 1, total)
                activity_code, activity_message = self._runtime_activity()
                self._event("SIMULATING",
                            activity_message or
                            f"Simulating frame {current} of {total}",
                            frame_current=available, frame_total=total,
                            activity_code=activity_code,
                            solver_name=self.diagnostics.solver_name,
                            solver_backend=self.diagnostics.solver_backend,
                            solver_device=self.diagnostics.solver_device,
                            solver_telemetry=dict(
                                self.diagnostics.solver_telemetry))
            else:
                self._event("SIMULATING",
                            f"Waiting for the solver ({status})",
                            indeterminate=True,
                            solver_name=self.diagnostics.solver_name,
                            solver_backend=self.diagnostics.solver_backend,
                            solver_device=self.diagnostics.solver_device,
                            solver_telemetry=dict(
                                self.diagnostics.solver_telemetry))
            if time.monotonic() > deadline:
                raise _session_error(
                    "The simulation stalled.",
                    f"no new frame within {self._simulate_timeout}s "
                    f"(status={status}, fetched={sorted(fetched)})")
            wait_step = time.monotonic()
            time.sleep(self._poll_interval)
            self.diagnostics.timings["simulation_wait"] = (
                self.diagnostics.timings.get("simulation_wait", 0.0)
                + time.monotonic() - wait_step)

    def _stream_water_and_fetch(self, *, resume=False):
        """Keep output validation/PC2 sinks; delegate public holds to owned Python."""
        if self._manager is None or self.resolved.executable_path is None:
            raise _session_error('Water Flow streaming requires a local GAIA solver.',
                                 'No owned official frontend process manager')
        root=bundle_root_for(self.resolved.executable_path)
        python=root/('python/python.exe' if os.name=='nt' else 'python/bin/python3')
        if not python.is_file():
            raise _session_error('The official solver Python runtime is missing.',str(python))
        run_id=uuid_module.uuid4().hex
        directory=self.work_directory/('water-stream-'+run_id)
        directory.mkdir(parents=True)
        descriptor=directory/'descriptor.json';params=directory/'params.pickle'
        status_file=directory/'status.json';cancel_file=directory/'cancel';gate=directory/'owned'
        descriptor.write_text(self.scene.water_stream_json,encoding='utf-8')
        params.write_bytes(self.scene.param_payload)
        log=directory/'helper.log'
        boundary=0
        if resume:
            if self._recovery_record is None or not self._recovery_record.checkpoints:
                raise _session_error('Water Flow recovery has no verified checkpoint.',
                                     'Cannot infer a resume boundary from UI progress')
            boundary=max(item.frame for item in self._recovery_record.checkpoints)
        worker=Path(__file__).resolve().parents[1]/'ppf'/'water_stream_worker.py'
        process=self._manager.start_owned_helper([
            str(python),str(worker),'--project-name',self.scene.project_name,
            '--project-root',str(self._server_data_root()/self.scene.project_name),
            '--descriptor',str(descriptor),'--params',str(params),'--status',str(status_file),
            '--cancel',str(cancel_file),'--startup-gate',str(gate),
            '--resume-boundary',str(boundary),
            '--native-worker',str(_native_worker_path(self.resolved.executable_path))],
            cwd=root,log_file=log,startup_gate=gate)
        total=self.scene.solver_frame_count
        fetched=set(self._recovery.completed_solver_frames if resume and self._recovery else ())
        output_map=None;last_state=None;deadline=time.monotonic()+self._simulate_timeout
        try:
            while True:
                self._check_cancel()
                # Native progress belongs to the official frontend's held run.
                # Control-server status adoption assumes its own run script;
                # polling it here can misclassify a healthy held process.
                poll=self._manager.poll()
                if not poll.running:raise self._manager.early_exit_error(poll)
                state={}
                from ..core.atomic_text import read_atomic_text
                try:state=json.loads(read_atomic_text(status_file))
                except (OSError,ValueError):pass
                phase=state.get('phase','STARTING')
                available=state.get('boundary',boundary)
                if type(available) is not int or not boundary<=available<=total:
                    raise _session_error('Invalid Water Flow streaming progress.',repr(state))
                if state and state!=last_state:
                    deadline=time.monotonic()+self._simulate_timeout
                    last_state=state
                    if self._recovery is not None and self._recovery_record is not None:
                        self._recovery_record=recovery.transition(
                            self._recovery.metadata_path,self._recovery_record,
                            self._recovery_record.state,water_stream_state=state)
                    if available>0 and output_map is None:output_map=self._fetch_output_map()
                    for frame in range(1,available+1):
                        if frame in fetched:continue
                        self._check_cancel()
                        self._frame_sink(self._fetch_frame(output_map,frame))
                        fetched.add(frame);self.diagnostics.fetched_frames.append(frame)
                        self.diagnostics.last_fetched_frame=frame
                        self.diagnostics.last_completed_logical_frame=frame
                source=json.loads(self.scene.water_stream_json)['first']+available
                activity_code, activity_message = self._runtime_activity()
                self._event('SIMULATING',
                            activity_message or f'Water Flow source frame {source}',
                            frame_current=available, frame_total=total,
                            activity_code=activity_code,
                            solver_name=self.diagnostics.solver_name,
                            solver_backend=self.diagnostics.solver_backend,
                            solver_device=self.diagnostics.solver_device,
                            solver_telemetry=dict(self.diagnostics.solver_telemetry))
                if phase=='FAILED':
                    raise _session_error('Water Flow cache streaming failed.',str(state.get('error','')))
                if phase=='CANCELLED':raise SessionCancelled()
                if phase=='FINISHED':
                    if len(fetched)!=total:
                        raise _session_error('Water Flow finished without every output frame.',repr(sorted(fetched)))
                    process.wait(timeout=30.)
                    if process.returncode!=0:
                        raise _session_error('Water Flow helper failed during cleanup.',str(log))
                    return
                if process.poll() is not None:
                    detail=log.read_text(encoding='utf-8',errors='replace')[-8192:]
                    raise _session_error('Water Flow helper exited before completion.',detail)
                if time.monotonic()>deadline:
                    raise _session_error('Water Flow streaming stalled.',repr(state))
                time.sleep(self._poll_interval)
        finally:
            if process.poll() is None:
                cancel_file.touch()
                try:process.wait(timeout=min(self._simulate_timeout,35.))
                except subprocess.TimeoutExpired:pass  # manager.stop reaps the owned tree
            if self._recovery is not None and self._recovery_record is not None:
                try:
                    from ..core.atomic_text import read_atomic_text
                    state=json.loads(read_atomic_text(status_file))
                    self._recovery_record=recovery.transition(
                        self._recovery.metadata_path,self._recovery_record,
                        self._recovery_record.state,water_stream_state=state)
                except (OSError,ValueError):pass
                self._sync_checkpoints({'saved_states':self._checkpoint_frames_on_disk()})

    def _cancel_server_side(self) -> None:
        """State-aware cancellation: cancel_build during builds, terminate
        during simulation; then delete only our unique project."""
        if self._address is None:
            return
        try:
            response = wire.send_tcmd(self._address, self.transport,
                                      self.scene.project_name)
            status = str(response.get("status", ""))
            if status == STATUS_BUILDING:
                self._request(REQUEST_CANCEL_BUILD_ALIAS)
            elif status in (STATUS_BUSY, STATUS_SAVE_AND_QUIT):
                self._request(REQUEST_TERMINATE_ALIAS)
        except (ClothNextError, OSError):
            pass  # the server may already be gone; process cleanup follows

    def _save_recovery_on_cancel(self) -> RecoveryOutcome:
        options, record = self._recovery, self._recovery_record
        if (options is None or record is None
                or not options.save_on_cancel):
            return RecoveryOutcome(
                checkpoint_saved=False,
                artist_message="Bake cancelled",
                technical_reason="",
                state_before="N/A",
                saved_states=(),
                kind=RecoveryOutcomeKind.NOT_ENABLED)

        if self._address is None:
            technical = (
                "cancel arrived before the solver connection was available")
            self._recovery_record = recovery.transition(
                options.metadata_path, record, recovery.ProjectState.FAILED,
                error=technical)
            return RecoveryOutcome(
                checkpoint_saved=False,
                artist_message=(
                    "Bake cancelled before a recovery checkpoint was available"),
                technical_reason=technical,
                state_before="STARTING_SOLVER",
                saved_states=(),
                kind=RecoveryOutcomeKind.NOT_AVAILABLE_YET)

        verified_before = tuple(
            sorted(item.frame for item in self._recovery_record.checkpoints))
        # First, check current server status to decide if checkpoint is feasible
        try:
            initial_response = self._status()
            initial_status = str(initial_response.get("status", ""))
        except ClothNextError as exc:
            initial_status = "CONNECTION_ERROR"
            technical = f"initial status query failed: {exc.record.technical_message}"
            # RECOVERY INVARIANT -- THE COMPANION CANCEL PATH MAY CLOSE THE
            # status port after already issuing save_and_quit.  Reconcile its
            # durable state before declaring that early disconnect a failure.
            disk_frames = self._wait_for_checkpoint_frames_on_disk(
                20.0 if self.diagnostics.last_successful_command ==
                wire.REQUEST_SAVE_AND_QUIT else 5.0)
            if disk_frames:
                self._sync_checkpoints({"saved_states": disk_frames})
                verified = tuple(sorted(
                    item.frame for item in self._recovery_record.checkpoints))
                if verified:
                    current = recovery.transition(
                        options.metadata_path, self._recovery_record,
                        recovery.ProjectState.SAVED)
                    self._recovery_record = recovery.transition(
                        options.metadata_path, current,
                        recovery.ProjectState.RESUMABLE)
                    outcome = RecoveryOutcome(
                        checkpoint_saved=True,
                        artist_message="Recovery checkpoint saved",
                        technical_reason=(
                            "Companion closed status after durable "
                            "save_and_quit"),
                        state_before=initial_status,
                        saved_states=verified,
                        kind=RecoveryOutcomeKind.SAVED)
                    self._event("RECOVERY_SAVED", outcome.artist_message,
                                activity_code="RECOVERY_SAVED")
                    return outcome
            log_with_context(self._logger, logging.WARNING,
                "Recovery checkpoint: cannot query server status",
                {"project": self.scene.project_name,
                 "mode": self.diagnostics.solver_mode,
                 "status": initial_status,
                 "reason": technical,
                 "metadata_path": str(options.metadata_path)})
            self._event("RECOVERY_WARNING",
                        "Could not query solver for checkpoint status",
                        activity_code="RECOVERY_FAILED")
            if verified_before:
                current = self._recovery_record
                if current.state is not recovery.ProjectState.SAVED:
                    current = recovery.transition(
                        options.metadata_path, current,
                        recovery.ProjectState.SAVED, error=technical)
                self._recovery_record = recovery.transition(
                    options.metadata_path, current,
                    recovery.ProjectState.RESUMABLE, error=technical)
            return RecoveryOutcome(
                checkpoint_saved=bool(verified_before),
                artist_message=(
                    "Existing checkpoint preserved; newest state could not "
                    "be saved" if verified_before else
                    "Recovery checkpoint unavailable"),
                technical_reason=technical,
                state_before=initial_status,
                saved_states=verified_before,
                kind=(RecoveryOutcomeKind.EXISTING_PRESERVED
                      if verified_before else RecoveryOutcomeKind.FAILED))

        if (verified_before and initial_status in {
                STATUS_RESUMABLE, STATUS_READY, STATUS_FAILED}):
            log_with_context(
                self._logger, logging.INFO,
                "Existing recovery checkpoint preserved", {
                    "project": self.scene.project_name,
                    "status": initial_status,
                    "raw_server_frames": self._saved_states(initial_response),
                    "verified_metadata_frames": verified_before,
                })
            current = self._recovery_record
            if current.state is recovery.ProjectState.FAILED:
                self._recovery_record = recovery.transition(
                    options.metadata_path, current,
                    recovery.ProjectState.RESUMABLE)
            elif current.state is not recovery.ProjectState.RESUMABLE:
                if current.state is not recovery.ProjectState.SAVED:
                    current = recovery.transition(
                        options.metadata_path, current,
                        recovery.ProjectState.SAVED)
                self._recovery_record = recovery.transition(
                    options.metadata_path, current,
                    recovery.ProjectState.RESUMABLE)
            return RecoveryOutcome(
                checkpoint_saved=True,
                artist_message="Existing recovery checkpoint preserved",
                technical_reason="", state_before=initial_status,
                saved_states=verified_before,
                kind=RecoveryOutcomeKind.EXISTING_PRESERVED)

        # States where no simulation state exists yet — skip save_and_quit
        if initial_status in (STATUS_NO_DATA, STATUS_NO_BUILD, STATUS_BUILDING):
            log_with_context(self._logger, logging.INFO,
                "Recovery checkpoint skipped: no simulation state yet",
                {"project": self.scene.project_name,
                 "mode": self.diagnostics.solver_mode,
                 "status": initial_status,
                 "metadata_path": str(options.metadata_path)})
            self._event("RECOVERY_WARNING",
                        "No recovery checkpoint available yet",
                        activity_code="RECOVERY_TOO_EARLY")
            if verified_before:
                current = self._recovery_record
                if current.state is not recovery.ProjectState.SAVED:
                    current = recovery.transition(
                        options.metadata_path, current,
                        recovery.ProjectState.SAVED,
                        error=(f"server status {initial_status} has no new "
                               "simulation state to save"))
                self._recovery_record = recovery.transition(
                    options.metadata_path, current,
                    recovery.ProjectState.RESUMABLE,
                    error=(f"server status {initial_status} has no new "
                           "simulation state to save"))
                return RecoveryOutcome(
                    checkpoint_saved=True,
                    artist_message=(
                        "Existing checkpoint preserved; newest state "
                        "could not be saved"),
                    technical_reason=(
                        f"server status {initial_status} has no new "
                        "simulation state to save"),
                    state_before=initial_status,
                    saved_states=verified_before,
                    kind=RecoveryOutcomeKind.EXISTING_PRESERVED)
            return RecoveryOutcome(
                checkpoint_saved=False,
                artist_message="Bake cancelled before a recovery checkpoint was available",
                technical_reason="",
                state_before=initial_status,
                saved_states=(),
                kind=RecoveryOutcomeKind.NOT_AVAILABLE_YET)

        # States where we can attempt save_and_quit
        if initial_status not in (STATUS_BUSY, STATUS_SAVE_AND_QUIT, STATUS_READY, STATUS_RESUMABLE, STATUS_FAILED):
            log_with_context(self._logger, logging.WARNING,
                "Recovery checkpoint: unexpected server status, attempting save",
                {"project": self.scene.project_name,
                 "mode": self.diagnostics.solver_mode,
                 "status": initial_status,
                 "metadata_path": str(options.metadata_path)})
            # Don't return; proceed to attempt

        # Try to request save_and_quit and wait for confirmation
        try:
            record = recovery.transition(
                options.metadata_path, record,
                recovery.ProjectState.CHECKPOINT_REQUESTED)
            self._recovery_record = record
            if initial_status != STATUS_SAVE_AND_QUIT:
                self._request(wire.REQUEST_SAVE_AND_QUIT)
            deadline = time.monotonic() + min(self._simulate_timeout, 120.0)
            last_known_status = initial_status
            while time.monotonic() < deadline:
                response = self._status()
                status = str(response.get("status", ""))
                last_known_status = status
                saved = self._saved_states(response)
                # RECOVERY INVARIANT -- DO NOT REMOVE THIS DISK FALLBACK.
                # save_and_quit may atomically finish the state file and then
                # close the solver status endpoint before the next poll.  The
                # durable state file is authoritative in that shutdown race.
                if not saved:
                    saved = self._checkpoint_frames_on_disk()
                if saved:
                    self._sync_checkpoints({**response,
                                            "saved_states": saved})
                verified = tuple(sorted(
                    item.frame for item in self._recovery_record.checkpoints))
                log_with_context(
                    self._logger, logging.DEBUG,
                    "Recovery checkpoint verification poll", {
                        "project": self.scene.project_name,
                        "status": status,
                        "raw_server_frames": saved,
                        "verified_metadata_frames": verified,
                    })
                newly_verified = tuple(
                    frame for frame in verified
                    if frame not in verified_before)
                if (status in (STATUS_RESUMABLE, STATUS_READY, STATUS_FAILED)
                        and (newly_verified or not verified_before)
                        and verified):
                    record = self._recovery_record
                    assert record is not None
                    record = recovery.transition(
                        options.metadata_path, record,
                        recovery.ProjectState.SAVED)
                    self._recovery_record = recovery.transition(
                        options.metadata_path, record,
                        recovery.ProjectState.RESUMABLE)
                    outcome = RecoveryOutcome(
                        checkpoint_saved=True,
                        artist_message="Recovery checkpoint saved",
                        technical_reason="",
                        state_before=initial_status,
                        saved_states=verified,
                        kind=RecoveryOutcomeKind.SAVED)
                    self._event("RECOVERY_SAVED", outcome.artist_message,
                                activity_code="RECOVERY_SAVED")
                    return outcome
                time.sleep(self._poll_interval)

            # Timeout waiting for confirmation
            verified = tuple(sorted(
                item.frame for item in self._recovery_record.checkpoints))
            technical = (f"timed out after {min(self._simulate_timeout, 120.0)}s "
                         f"waiting for a verified checkpoint; "
                         f"last status={last_known_status}; "
                         f"raw server frames={tuple(self._known_saved_states)}; "
                         f"verified metadata frames={verified}")
            log_with_context(self._logger, logging.WARNING,
                "Recovery checkpoint timed out",
                {"project": self.scene.project_name,
                 "mode": self.diagnostics.solver_mode,
                 "status": last_known_status,
                 "raw_server_frames": tuple(self._known_saved_states),
                 "verified_metadata_frames": verified,
                 "timeout_s": min(self._simulate_timeout, 120.0),
                 "metadata_path": str(options.metadata_path)})
            self._event("RECOVERY_WARNING",
                        "Recovery checkpoint could not be confirmed",
                        activity_code="RECOVERY_TIMEOUT")
            if verified:
                record = self._recovery_record
                assert record is not None
                record = recovery.transition(
                    options.metadata_path, record,
                    recovery.ProjectState.SAVED, error=technical)
                self._recovery_record = recovery.transition(
                    options.metadata_path, record,
                    recovery.ProjectState.RESUMABLE, error=technical)
                return RecoveryOutcome(
                    checkpoint_saved=True,
                    artist_message=(
                        "Existing checkpoint preserved; newest state "
                        "could not be saved"),
                    technical_reason=technical,
                    state_before=initial_status,
                    saved_states=verified,
                    timed_out=True,
                    kind=RecoveryOutcomeKind.EXISTING_PRESERVED)
            try:
                self._recovery_record = recovery.transition(
                    options.metadata_path, self._recovery_record,
                    recovery.ProjectState.FAILED,
                    error=technical)
            except (OSError, ValueError) as exc:
                log_with_context(self._logger, logging.WARNING,
                    "Failed to record recovery timeout in metadata",
                    {"project": self.scene.project_name,
                     "error": str(exc)})
            return RecoveryOutcome(
                checkpoint_saved=False,
                artist_message="Recovery checkpoint could not be saved",
                technical_reason=technical,
                state_before=initial_status,
                saved_states=verified,
                timed_out=True,
                kind=RecoveryOutcomeKind.FAILED)

        except (ClothNextError, OSError, ValueError) as exc:
            # The most common exception here is the expected connection close
            # immediately after save_and_quit.  Confirm the durable file before
            # classifying that successful shutdown as Recovery failure.
            # RECOVERY INVARIANT -- KEEP THE GRACE WINDOW.  The status socket
            # can close just before the final state file's atomic rename.
            disk_frames = self._wait_for_checkpoint_frames_on_disk(20.0)
            if disk_frames and self._recovery_record is not None:
                self._sync_checkpoints({"saved_states": disk_frames})
                verified = tuple(sorted(
                    item.frame for item in self._recovery_record.checkpoints))
                if verified:
                    record = recovery.transition(
                        options.metadata_path, self._recovery_record,
                        recovery.ProjectState.SAVED)
                    self._recovery_record = recovery.transition(
                        options.metadata_path, record,
                        recovery.ProjectState.RESUMABLE)
                    outcome = RecoveryOutcome(
                        checkpoint_saved=True,
                        artist_message="Recovery checkpoint saved",
                        technical_reason=(
                            "Solver status endpoint closed after durable "
                            "checkpoint publication"),
                        state_before=initial_status,
                        saved_states=verified,
                        kind=RecoveryOutcomeKind.SAVED)
                    self._event("RECOVERY_SAVED", outcome.artist_message,
                                activity_code="RECOVERY_SAVED")
                    return outcome
            # Preserve the actual exception for logging
            technical = f"{type(exc).__name__}: {exc}"
            log_with_context(self._logger, logging.WARNING,
                "Recovery checkpoint failed",
                {"project": self.scene.project_name,
                 "mode": self.diagnostics.solver_mode,
                 "status": initial_status,
                 "exception_type": type(exc).__name__,
                 "exception_message": str(exc),
                 "metadata_path": str(options.metadata_path)})
            self._event("RECOVERY_WARNING",
                        "Recovery checkpoint could not be saved",
                        activity_code="RECOVERY_FAILED")
            verified = tuple(sorted(
                item.frame for item in self._recovery_record.checkpoints
            )) if self._recovery_record is not None else ()
            if self._recovery_record is not None:
                try:
                    self._recovery_record = recovery.transition(
                        options.metadata_path, self._recovery_record,
                        recovery.ProjectState.FAILED,
                        error=f"save_and_quit failed: {technical}")
                except (OSError, ValueError) as meta_exc:
                    log_with_context(self._logger, logging.WARNING,
                        "Failed to record recovery failure in metadata",
                        {"project": self.scene.project_name,
                         "original_error": technical,
                         "meta_error": str(meta_exc)})
            return RecoveryOutcome(
                checkpoint_saved=bool(verified),
                artist_message=(
                    "Existing checkpoint preserved; newest state could not "
                    "be saved" if verified else
                    "Recovery checkpoint could not be saved"),
                technical_reason=technical,
                state_before=initial_status,
                saved_states=verified,
                kind=(RecoveryOutcomeKind.EXISTING_PRESERVED if verified
                      else RecoveryOutcomeKind.FAILED))

    def _delete_project(self) -> None:
        if self._address is None:
            return
        if self._project_link is not None:
            # TCMD delete removes the alias, not necessarily its target. CNX
            # is the sole alias authority; defer removal until all owned
            # processes have been joined by the existing process manager.
            self._delete_link_after_join = True
            try:
                self._request(wire.REQUEST_TERMINATE)
            except ClothNextError:
                pass
            return
        try:
            self._request(REQUEST_DELETE_ALIAS)
        except ClothNextError:
            pass

    def _stop_owned(self) -> None:
        manager = self._manager
        if manager is None:
            self._cleanup_project_link()
            return
        self.diagnostics.termination_requested = True
        self._capture_process_tails()
        poll = manager.stop()
        self.diagnostics.control_server_alive = poll.running
        self.diagnostics.control_server_exit_code = poll.exit_code
        self.diagnostics.owned_process_ids = tuple(poll.owned_process_ids)
        self.diagnostics.stdout_tail = poll.stdout_tail
        self.diagnostics.stderr_tail = poll.stderr_tail
        self._merge_process_contacts(poll)
        # Clear ownership only after stop() has reaped the process and joined
        # its reader threads. Keeping the reference on failure prevents the
        # session from falsely claiming no owned process remains.
        if self._manager is manager:
            self._manager = None
        self._cleanup_project_link()

    def _cleanup_project_link(self) -> None:
        """Reentrant cleanup after the process manager has confirmed join."""
        if self._manager is not None:
            raise _session_error("The solver is still running.",
                                 "project alias cleanup refused before process join")
        if self._health_project_link is not None:
            self._cleanup_link_target(self._health_project_link)
            self._health_project_link = None
        if self._delete_link_after_join and self._project_link is not None:
            self._cleanup_link_target(self._project_link)
            self._delete_link_after_join = False
            if self._recovery_record is not None and self._recovery is not None:
                self._recovery_record = recovery.transition(
                    self._recovery.metadata_path, self._recovery_record,
                    recovery.ProjectState.DELETED)

    @staticmethod
    def _cleanup_link_target(link) -> None:
        link.validate_target_ownership()
        link.remove()
        from ..ppf.project_links import inspect_project_link
        if inspect_project_link(link.target).kind not in {"directory", "absent"}:
            raise link._fail("owned project target changed type before cleanup", owned=True)
        outcome = delete_owned(
            link.target, root=link.root, ownership_authenticated=True,
            recursive=True, lifecycle_stage="PPF_SESSION_FINALIZE",
            artifact_type="solver_project")
        if not outcome.success:
            raise link._fail(outcome.technical_diagnostic(), owned=True)

    # -- entry point ---------------------------------------------------------

    def run(self) -> SessionDiagnostics:
        return self._run(contact_validation_only=False)

    def validate_contacts(self) -> SessionDiagnostics:
        """Upload and build contacts without starting frame simulation.

        The supported solver protocol has no separate validation request.  A
        normal project build is nevertheless a strict boundary: initial
        contact diagnostics are returned while awaiting BUILD, before START
        can advance the first simulation frame.
        """
        if self._recovery is not None:
            raise ValueError(
                "contact-only validation must not create Recovery state")
        return self._run(contact_validation_only=True)

    def _run(self, *, contact_validation_only: bool) -> SessionDiagnostics:
        """Execute the full vertical slice; raises on failure, returns
        diagnostics on success. Cleanup always runs."""
        started = time.monotonic()
        owned = self.resolved.ownership is ConnectionOwnership.OWNED_PROCESS
        completed = False
        preserved = False
        primary_error: BaseException | None = None
        try:
            # Establish durable Recovery ownership before observing Cancel.
            # The UI can request cancellation immediately after the worker is
            # published; checking first used to misreport that narrow window
            # as Recovery NOT_ENABLED and create no metadata at all.
            if not contact_validation_only:
                self._recovery_start()
            self._check_cancel()
            prepared = prepare_solver_inputs(
                self.scene, self.resolved, self.work_directory,
                check_cancel=self._check_cancel, event=self._event)
            if prepared.scene is not self.scene:
                self.scene = prepared.scene
                self.diagnostics.param_hash = prepared.scene.param_hash
            if prepared.environment:
                self._hydrodynamic_environment = dict(prepared.environment)
                self._owns_hydrodynamic_volumes = True
            if prepared.native_fluid_seconds is not None:
                self.diagnostics.timings['native_fluid_encoding'] = (
                    prepared.native_fluid_seconds)
            if owned:
                self._event("STARTING_SOLVER", "Starting simulation solver",
                            indeterminate=True)
                step = time.monotonic()
                try:
                    self._start_owned_solver()
                    self._metadata_event()
                finally:
                    self.diagnostics.timings["start_solver"] = (
                        time.monotonic() - step)
            else:
                assert self._address is not None
                self.diagnostics.host = self._address.host
                self.diagnostics.port = self._address.port
                self._event("STARTING_SOLVER", "Connecting to the simulation service",
                            indeterminate=True)
                self._status()
                self._metadata_event()
            self._check_cancel()
            resuming = bool(self._recovery and self._recovery.resume)
            if resuming:
                response = self._status(allow_server_error=True)
                server_state = reconcile_resume_server_state(response)
                self.diagnostics.note_status(server_state.status)
                water_resume=(bool(self.scene.water_stream_json)
                              and server_state.status==STATUS_READY
                              and bool(self._recovery_record and self._recovery_record.checkpoints))
                if not server_state.may_resume and not water_resume:
                    raise _session_error(
                        "Recovery could not resume the saved solver project.",
                        f"recovery_server_state={server_state.state.value}; "
                        f"status={server_state.status}; "
                        f"{server_state.message}")
                if (str(response.get("data_hash", "")) != self.scene.data_hash
                        or str(response.get("param_hash", ""))
                        != self.scene.param_hash):
                    raise _session_error(
                        "The saved solver project does not match this Bake.",
                        "server data/param hash differs from recovery identity")
                saved=self._saved_states(response)
                if self.scene.water_stream_json:saved=self._checkpoint_frames_on_disk()
                if not saved:
                    raise _session_error(
                        "The recovery project has no confirmed Saved State.",
                        "server status has no saved_states")
            else:
                self._event("UPLOADING", "Uploading scene",
                            indeterminate=True)
                step = time.monotonic()
                try:
                    self._upload()
                finally:
                    self.diagnostics.timings["upload"] = (
                        time.monotonic() - step)
                self._check_cancel()
                self._event("BUILDING", "Building solver project",
                            indeterminate=True)
                step = time.monotonic()
                try:
                    self._request(REQUEST_BUILD_ALIAS)
                    self._await_build()
                finally:
                    self.diagnostics.timings["build"] = (
                        time.monotonic() - step)
                if contact_validation_only:
                    # BUILD is the last request needed for initial contact
                    # diagnostics.  Do not send START, create Recovery state,
                    # fetch frames, or invoke the frame sink.
                    completed = True
                    return self.diagnostics
            self._check_cancel()
            step = time.monotonic()
            self._apply_official_bindings()
            self._simulate_and_fetch(resume=resuming)
            self.diagnostics.timings["simulation_and_import"] = time.monotonic() - step
            completed = True
            if self._recovery_record is not None and self._recovery is not None:
                self._recovery_record = recovery.transition(
                    self._recovery.metadata_path, self._recovery_record,
                    recovery.ProjectState.FINISHED,
                    last_frame=self.scene.solver_frame_count)
                preserved = self._recovery.keep_on_finish
            return self.diagnostics
        except SessionCancelled:
            self.diagnostics.cancelled = True
            self._event("CANCELLING", "Saving recovery checkpoint",
                        indeterminate=True)
            outcome = self._save_recovery_on_cancel()
            if not outcome.checkpoint_saved:
                self._cancel_server_side()
            primary_error = SessionCancelled(
                resumable=outcome.checkpoint_saved,
                recovery_outcome=outcome)
            raise primary_error
        except ClothNextError as exc:
            if self._recovery_record is not None and self._recovery is not None:
                try:
                    options = self._recovery
                    eligibility, _promoted = recovery.reconcile_resumable(
                        options.metadata_path, options.identity)
                    if eligibility.available:
                        # Preserve whatever verified checkpoint survived, even
                        # when the identity no longer matches, and refresh the
                        # in-memory record so cleanup sees the durable state.
                        self._recovery_record = recovery.load_project(
                            options.metadata_path)
                        if self._recovery_record is not None:
                            # Keep the failure reason on the durable record so
                            # a later panel or file load shows why the Bake
                            # stopped instead of a bare "Recovery available".
                            self._recovery_record = recovery.transition(
                                options.metadata_path,
                                self._recovery_record,
                                self._recovery_record.state,
                                error=exc.record.technical_message)
                        preserved = True
                    else:
                        self._recovery_record = recovery.transition(
                            options.metadata_path, self._recovery_record,
                            recovery.ProjectState.FAILED,
                            error=exc.record.technical_message)
                        preserved = False
                except (OSError, ValueError):
                    pass
            if owned and exc.record.category is ErrorCategory.SOLVER_CONNECTION:
                primary_error = self._with_recovery_evidence(
                    self._owned_connection_error(exc))
                raise primary_error from exc
            if (not owned
                    and exc.record.category is ErrorCategory.SOLVER_CONNECTION):
                primary_error = self._with_recovery_evidence(
                    self._external_connection_error(exc))
                raise primary_error from exc
            primary_error = self._with_recovery_evidence(exc)
            if primary_error is exc:
                raise
            raise primary_error from exc
        except BaseException as exc:
            primary_error = exc
            if self._recovery_record is not None and self._recovery is not None:
                # A hard abort (host kill, keyboard interrupt) leaves the
                # metadata mid-run. If a verified checkpoint already exists,
                # keep the project resumable instead of deleting it.
                try:
                    options = self._recovery
                    eligibility, _promoted = recovery.reconcile_resumable(
                        options.metadata_path, options.identity)
                    if eligibility.available:
                        preserved = True
                except (OSError, ValueError):
                    pass
            raise
        finally:
            try:
                if (self._recovery is None or completed) and not preserved:
                    self._delete_project()
                    if (self._project_link is None and self._recovery_record is not None
                            and self._recovery is not None):
                        try:
                            self._recovery_record = recovery.transition(
                                self._recovery.metadata_path,
                                self._recovery_record,
                                recovery.ProjectState.DELETED)
                        except (OSError, ValueError):
                            pass
            finally:
                if owned:
                    try:
                        self._stop_owned()
                    except BaseException as cleanup_exc:
                        message = (
                            "Additional process cleanup issue: "
                            f"{type(cleanup_exc).__name__}: {cleanup_exc}")
                        self.diagnostics.cleanup_issues.append(message)
                        log_with_context(
                            self._logger, logging.ERROR,
                            "owned process cleanup failed",
                            {"project": self.scene.project_name,
                             "primary_error": (
                                 type(primary_error).__name__
                                 if primary_error is not None else None),
                             "cleanup_error": str(cleanup_exc)})
                        if primary_error is None:
                            raise
                        primary_error.add_note(message)
                for payload in (self.scene.data_payload, self.scene.param_payload):
                    if not isinstance(payload, Path):
                        continue
                    try:
                        if payload.parent.resolve() == self.work_directory.resolve():
                            outcome = delete_owned(payload, root=self.work_directory,
                                ownership_authenticated=True,
                                lifecycle_stage='PPF_SESSION_FINALIZE', artifact_type='scene_payload')
                            if not outcome.success:
                                self.diagnostics.cleanup_issues.append(outcome.technical_diagnostic())
                    except OSError:
                        pass
                hydro = getattr(self, '_hydrodynamic_environment', {}).get(
                    'PPF_EXPERIMENTAL_HYDRO_VOLUME_DIR')
                if hydro and self._owns_hydrodynamic_volumes:
                    from ..gaia.hydrodynamic_session import is_shared_volume
                    if is_shared_volume(hydro):
                        # Reusable FLIP surfaces stay in their cache; only this
                        # run's model folder below the work directory goes.
                        hydro = str(Path(self._hydrodynamic_environment[
                            'PPF_EXPERIMENTAL_HYDRO_TEST_JSON']).parent / 'volumes')
                if hydro and self._owns_hydrodynamic_volumes:
                    # Prepared FLIP volumes are large and rebuilt by every run, resumes included.
                    try:
                        outcome = delete_owned(Path(hydro).parent, root=self.work_directory,
                            ownership_authenticated=True, recursive=True,
                            lifecycle_stage='PPF_SESSION_FINALIZE', artifact_type='hydrodynamic_volumes')
                        if not outcome.success:
                            self.diagnostics.cleanup_issues.append(outcome.technical_diagnostic())
                    except OSError:
                        pass
                self.diagnostics.timings["total"] = time.monotonic() - started
                log_with_context(self._logger, 20, "session finished", {
                    "run_id": self.diagnostics.run_id,
                    "project": self.scene.project_name,
                    "mode": self.diagnostics.solver_mode,
                    "fetched": len(self.diagnostics.fetched_frames),
                    "cancelled": self.diagnostics.cancelled,
                    "contact_peak": self.diagnostics.contact_peak,
                    "contact_last": self.diagnostics.contact_last,
                    "contact_samples": self.diagnostics.contact_samples,
                })


# Aliases keep the request spellings in one importable place for tests.
REQUEST_BUILD_ALIAS = wire.REQUEST_BUILD
REQUEST_CANCEL_BUILD_ALIAS = wire.REQUEST_CANCEL_BUILD
REQUEST_START_ALIAS = wire.REQUEST_START
REQUEST_TERMINATE_ALIAS = wire.REQUEST_TERMINATE
REQUEST_DELETE_ALIAS = wire.REQUEST_DELETE
