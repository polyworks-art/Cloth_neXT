# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Optional viewport presentation for the existing Simulation workflow.

Blender gizmos own the clickable areas; the draw handler only paints the bar.
Quick Assign owns a short-lived gesture; simulation state remains elsewhere.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import bpy

from ..bake.controller import shared_controller
from ..pull_detach import PullGesture, logo_hit
from ..solver_quality import matching_quality_preset
from . import object_properties, physics_operators, physics_ui, quick_assign
from .addon_identity import addon_preferences

_handle = None
_registered = False
_images = {}
_pull_sessions = {}
_toolbar_visible = True
_slide = 1.0
_animation_from = 1.0
_animation_start_time = None
_ANIMATION_DURATION = 0.135
_RESUME_ANIMATION_DURATION = 0.18
_RESUME_EXTENSION = 36
_RESUME_PULL_EXTENSION = 220
_resume_slide = 0.0
_resume_animation_from = 0.0
_resume_animation_target = False
_resume_animation_start_time = None
_last_enabled = False
_keymap = None
_keymap_item = None
_LAYOUT_SCALE = 0.65
_persistent = getattr(getattr(bpy.app, "handlers", None),
                      "persistent", lambda fn: fn)
_BG = (0.105, 0.119, 0.130, 0.94)  # charcoal
_SURFACE = (0.225, 0.245, 0.265, 0.97)
_CYAN = (0.06, 0.66, 0.85, 1.0)
_BLUE = (0.0, 0.60, 0.85, 1.0)
_TEXT = (0.93, 0.96, 0.98, 1.0)
_MUTED = (0.57, 0.64, 0.68, 1.0)
_DIR_READY = (0.37, 0.68, 0.17, 1.0)
_DIR_MISSING = (0.78, 0.19, 0.22, 1.0)


def _prefs(context):
    try:
        return addon_preferences(context, __package__)
    except (KeyError, AttributeError):
        return None


def enabled(context):
    prefs = _prefs(context)
    return bool(prefs and getattr(prefs, "new_look", False))


def visible(context):
    return enabled(context) and _slide_fraction() > 0.0


def _slide_fraction(now=None):
    """Current visible fraction; reversing F6 starts at this exact position."""
    global _slide, _animation_start_time
    if _animation_start_time is None:
        return _slide
    elapsed = max(0.0, (time.monotonic() if now is None else now)
                  - _animation_start_time)
    target = float(_toolbar_visible)
    duration = _ANIMATION_DURATION * abs(target - _animation_from)
    t = min(1.0, elapsed / duration) if duration else 1.0
    eased = 1.0 - (1.0 - t)**2 if target else t**2
    _slide = _animation_from + (target - _animation_from) * eased
    if t >= 1.0:
        _slide = target
        _animation_start_time = None
    return _slide


def _stop_animation():
    global _animation_start_time
    _animation_start_time = None
    if bpy.app.timers.is_registered(_animation_tick):
        bpy.app.timers.unregister(_animation_tick)


def _animation_tick():
    _slide_fraction()
    _tag_redraw(bpy.context)
    return 1.0 / 60.0 if _animation_start_time is not None else None


def _resume_fraction(context, now=None):
    """Animate the verified Resume segment out from behind the Bake pill."""
    global _resume_slide, _resume_animation_from
    global _resume_animation_target, _resume_animation_start_time
    target = _resume_available(context)
    current_time = time.monotonic() if now is None else now
    if _resume_animation_start_time is not None:
        elapsed = max(0.0, current_time - _resume_animation_start_time)
        destination = float(_resume_animation_target)
        duration = (_RESUME_ANIMATION_DURATION
                    * abs(destination - _resume_animation_from))
        t = min(1.0, elapsed / duration) if duration else 1.0
        eased = 1.0 - (1.0 - t)**3 if destination else t**3
        _resume_slide = (_resume_animation_from
                         + (destination - _resume_animation_from) * eased)
        if t >= 1.0:
            _resume_slide = destination
            _resume_animation_start_time = None
    if target != _resume_animation_target:
        _resume_animation_from = _resume_slide
        _resume_animation_target = target
        _resume_animation_start_time = current_time
        if not bpy.app.timers.is_registered(_resume_animation_tick):
            bpy.app.timers.register(_resume_animation_tick,
                                    first_interval=1.0 / 60.0)
    if _resume_animation_start_time is None:
        return _resume_slide
    return _resume_slide


def _resume_animation_tick():
    _resume_fraction(bpy.context)
    _tag_redraw(bpy.context)
    return (1.0 / 60.0
            if _resume_animation_start_time is not None else None)


def _scale(context):
    return max(0.75, float(context.preferences.system.ui_scale)) * _LAYOUT_SCALE


def _aether_quality(scene):
    """The AETHER Engine bake preset as a quality-like record, or None (other backend)."""
    from ..simulation.backends import BackendId
    from . import solver_backends
    if scene is None or solver_backends.active_backend_id(scene) is not BackendId.AETHER_ENGINE:
        return None
    from types import SimpleNamespace
    settings = getattr(scene, "cloth_next_solver", None)
    live = str(getattr(settings, "aether_run_mode", "LIVE")) == "LIVE"
    key = str(getattr(settings, "aether_live_quality" if live else "aether_bake_quality",
                      "NORMAL" if live else "FITTING"))
    return SimpleNamespace(identifier=key, label=key.title(), live=live)


def _aether_live_running():
    try:
        from . import aether_engine_live
        return aether_engine_live.is_running()
    except Exception:  # noqa: BLE001 - drawing must never fail
        return False


# AETHER main button: hold and pull right to choose Live or Bake (option pills right of the button)
_MODE_OPTIONS = (("LIVE", "LIVE"), ("BAKE", "BAKE"))
_MODE_PILL = 52          # option pill width (layout units)
_MODE_GAP = 6
_MODE_OPEN_PULL = 10     # pixels (layout units) of pull before the options appear


def _mode_option_rects(bounds, quality_width):
    """[(key, x, width)] of the Live / Bake option pills right of the main button."""
    bx, _by, _w, _h, s = bounds
    left = bx + (136 + quality_width + 82 + 10) * s
    return [(key, left + k * (_MODE_PILL + _MODE_GAP) * s, _MODE_PILL * s)
            for k, (key, _label) in enumerate(_MODE_OPTIONS)]


def _quality_width(context):
    scene = getattr(context, "scene", None)
    aether = _aether_quality(scene)
    if aether is not None:
        return 46   # the preset's icon only (as the folder button)
    elif scene is None:
        label = "Custom"
    else:
        preset = matching_quality_preset(
            object_properties.solver_quality_from(scene),
            has_pdrd=physics_operators.scene_has_pdrd(scene))
        label = preset.label if preset else "Custom"
    return max(66, 25 + 8 * len(label))


def _bounds(context):
    region = context.region
    if region is None or region.type != "WINDOW":
        return None
    scale = _scale(context)
    resume_extension = _RESUME_EXTENSION * _resume_fraction(context)
    base_width = (230 + _quality_width(context)) * scale
    width, height = (base_width + resume_extension * scale, 54 * scale)
    if (region.width < width + 24 * scale
            or region.height < height + 78 * (scale / _LAYOUT_SCALE)):
        return None
    return ((region.width - base_width) / 2, 28 * scale,
            width, height, scale)


def _animated_bounds(context):
    bounds = _bounds(context)
    if bounds is None:
        return None
    x, shown_y, width, height, scale = bounds
    # The WINDOW region clips the toolbar as it passes below its own edge.
    # Include the detached Quick Assign button in the fully clipped extent.
    hidden_y = -height - 50 * (scale / _LAYOUT_SCALE)
    y = hidden_y + (shown_y - hidden_y) * _slide_fraction()
    return x, y, width, height, scale


def _state(context):
    scene = getattr(context, "scene", None)
    snapshot = shared_controller.snapshot()
    if scene is None:
        return None, snapshot, None, False, "No scene"
    quality = _aether_quality(scene) or matching_quality_preset(
        object_properties.solver_quality_from(scene),
        has_pdrd=physics_operators.scene_has_pdrd(scene))
    model = physics_ui._bake_panel_model(
        context, physics_ui._active_backend_status(context))
    deformables = [obj for obj in scene.objects
                   if getattr(getattr(obj, "cloth_next", None), "enabled", False)
                   and obj.cloth_next.role in {"CLOTH", "ROD", "SOFT_BODY", "RIGID_BODY"}]
    # The same existing property and missing-directory rule used by Bake.
    directory_ok = bool(deformables) and all(
        path and os.path.isdir(bpy.path.abspath(path)) for path in
        (str(getattr(obj.cloth_next, "cache_directory", "") or "").strip()
         for obj in deformables))
    recovery = getattr(scene, "cloth_next_recovery", None)
    recovery_status = (str(getattr(recovery, "status", "") or "")
                       if getattr(recovery, "enabled", False) else "")
    message = snapshot.error_summary
    if not message and recovery_status in {
            "Recovery Check Failed", "Recovery Metadata Invalid",
            "Recovery Incompatible", "Recovery Project Missing"}:
        message = recovery_status
    message = message or (physics_ui._run_state_text(snapshot) if snapshot.active
                          else model.reason)
    return model, snapshot, quality, directory_ok, message


def _resume_available(context):
    settings = getattr(getattr(context, "scene", None),
                       "cloth_next_recovery", None)
    return bool(settings and getattr(settings, "resumable", False)
                and not shared_controller.snapshot().active)


def _resume_frame(context):
    settings = getattr(getattr(context, "scene", None),
                       "cloth_next_recovery", None)
    frame = int(getattr(settings, "latest_checkpoint_frame", 0) or 0)
    return frame if frame > 0 else None


def _resume_hit(bounds, x, y, quality_width):
    if bounds is None:
        return False
    bx, by, _width, height, scale = bounds
    visible_width = _RESUME_EXTENSION * _resume_slide
    left = bx + (218 + quality_width) * scale
    return (visible_width > 0.0
            and left <= x <= left + visible_width * scale
            and by <= y <= by + height)


def _rounded(shader, batch_for_shader, x, y, w, h, r, color):
    import math
    points = []
    for cx, cy, start in ((x+w-r, y+r, -90), (x+w-r, y+h-r, 0),
                          (x+r, y+h-r, 90), (x+r, y+r, 180)):
        for i in range(7):
            a = math.radians(start + i * 15)
            points.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    verts = [(x+w/2, y+h/2)] + points
    indices = [(0, i+1, (i+1) % len(points)+1) for i in range(len(points))]
    shader.bind()
    shader.uniform_float("color", color)
    batch_for_shader(shader, "TRIS", {"pos": verts}, indices=indices).draw(shader)


def _bake_resume_vertical_geometry(y, height, scale):
    """Return pixel-aligned Bake/Resume edges with a true four-UI-pixel inset."""
    bake_bottom = round(y + 8 * scale)
    bake_top = round(y + height - 8 * scale)
    inset = max(1, round(4 * scale / _LAYOUT_SCALE))
    return (bake_bottom, bake_top - bake_bottom,
            bake_bottom + inset, bake_top - bake_bottom - 2 * inset)


def _pull_fade_mesh(x, y, w, h, radius, color):
    """Rounded pill with horizontal opacity fading beneath the fixed logo."""
    import math
    points = []
    for cx, cy, start in ((x+w-radius, y+radius, -90),
                          (x+w-radius, y+h-radius, 0),
                          (x+radius, y+h-radius, 90),
                          (x+radius, y+radius, 180)):
        for i in range(7):
            angle = math.radians(start + i*15)
            points.append((cx+radius*math.cos(angle), cy+radius*math.sin(angle)))
    vertices = [(x+w/2, y+h/2)] + points
    colors = [(*color[:3], color[3]*max(0., min(1., 1.-(vx-x)/w)))
              for vx, _ in vertices]
    indices = [(0, i+1, (i+1) % len(points)+1) for i in range(len(points))]
    return vertices, colors, indices


def _pull_fade(batch, x, y, w, h, radius, color):
    import gpu
    vertices, colors, indices = _pull_fade_mesh(x, y, w, h, radius, color)
    shader = gpu.shader.from_builtin("SMOOTH_COLOR")
    shader.bind()
    batch(shader, "TRIS", {"pos": vertices, "color": colors}, indices=indices).draw(shader)


def _label(blf, text, x, y, size, color):
    import gpu
    blf.size(0, size)
    gpu.state.blend_set("ALPHA")
    blf.color(0, *color)
    blf.position(0, x, y, 0)
    blf.draw(0, text)
    # BLF may disable blending; subsequent PNGs need their alpha channel.
    gpu.state.blend_set("ALPHA")


def _centered_label(blf, text, x, y, width, size, color):
    blf.size(0, size)
    text_width, _ = blf.dimensions(0, text)
    _label(blf, text, x + (width - text_width) / 2, y, size, color)


def _centered_glyph(blf, text, cx, cy, size, color):
    blf.size(0, size)
    width, height = blf.dimensions(0, text)
    _label(blf, text, cx - width / 2, cy - height / 2, size, color)


def _asset_icon(gpu, batch_for_shader, name, x, y, size):
    image = _images.get(name)
    try:
        if image is not None and image.name not in bpy.data.images:
            image = None
    except ReferenceError:
        image = None
    if image is None:
        path = Path(__file__).resolve().parent.parent / "assets" / "icons" / f"{name}.png"
        if not path.is_file():
            return
        image = bpy.data.images.load(str(path), check_existing=False)
        _images[name] = image
    texture = gpu.texture.from_image(image)
    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(shader, "TRI_FAN", {
        "pos": ((x, y), (x+size, y), (x+size, y+size), (x, y+size)),
        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
    })
    shader.bind()
    shader.uniform_sampler("image", texture)
    batch.draw(shader)


@_persistent
def _scene_loading(_dummy):
    quick_assign.cancel_all()
    _cancel_pulls()


@_persistent
def _scene_loaded(_dummy):
    # Loading a .blend frees images from the old Main, invalidating RNA refs.
    _images.clear()
    if _registered:
        _tag_redraw(bpy.context)


def _message_anchor(bounds):
    """Detached diagnostics, aligned beside Bake and outside the pill."""
    x, y, width, height, scale = bounds
    return x + width + 18*(scale/_LAYOUT_SCALE), y + height/2


def _fit_label(blf, text, available, size):
    blf.size(0, size)
    if blf.dimensions(0, text)[0] <= available:
        return text
    if blf.dimensions(0, "…")[0] > available:
        return ""
    while text and blf.dimensions(0, text + "…")[0] > available:
        text = text[:-1]
    return text + "…"


def _draw():
    # The PATTERN NeXt 2D editor shows patterns only, never 3D overlays.
    from .pattern_next.workspace import is_pattern_area
    if is_pattern_area(bpy.context):
        return
    context = bpy.context
    if not visible(context):
        return
    bounds = _animated_bounds(context)
    if bounds is None:
        return
    import blf
    import gpu
    from gpu_extras.batch import batch_for_shader

    x, y, w, h, s = bounds
    quality_width = _quality_width(context)
    bake_x = 136 + quality_width
    model, snapshot, quality, directory_ok, message = _state(context)
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    try:
        _draw_pull(context, bounds, blf, shader, batch_for_shader)
        _rounded(shader, batch_for_shader, x, y, w, h, 25*s, _BG)
        shader.bind()
        shader.uniform_float("color", (0.56, 0.63, 0.68, 0.38))
        batch_for_shader(shader, "LINES", {"pos": ((x+57*s, y+12*s),
                                                 (x+57*s, y+42*s))}).draw(shader)
        _rounded(shader, batch_for_shader, x+68*s, y+8*s, 46*s, h-16*s,
                 17*s, _SURFACE)
        _rounded(shader, batch_for_shader, x+126*s, y+8*s,
                 quality_width*s, h-16*s,
                 17*s, _DIR_MISSING if quality and
                 quality.identifier == "EXTREME" else _SURFACE)
        bake_ready = bool((snapshot.active and snapshot.can_cancel) or
                          (not snapshot.active and model and model.enabled))
        resume_ready = _resume_available(context)
        resume_fraction = _resume_fraction(context)
        bake_y, bake_height, resume_y, resume_height = (
            _bake_resume_vertical_geometry(y, h, s))
        if resume_fraction > 0.0:
            # The complete green pill begins behind Bake. Its left cap remains
            # fully covered, so the visible part reads as a pull-out layer.
            _rounded(shader, batch_for_shader, x+(bake_x+66)*s, resume_y,
                     (16 + _RESUME_EXTENSION*resume_fraction)*s,
                     resume_height, 15*s, _DIR_READY)
        # Paint Bake last so Resume appears to slide out from behind it.
        _rounded(shader, batch_for_shader, x+bake_x*s, bake_y, 82*s, bake_height,
                 17*s, _BLUE if bake_ready else (0.12, 0.13, 0.14, 0.88))
        _rounded(shader, batch_for_shader, x+105*s, y+37*s, 18*s, 18*s,
                 9*s, _DIR_READY if directory_ok else _DIR_MISSING)
        _asset_icon(gpu, batch_for_shader, "cloth_next", x+14*s, y+10*s, 34*s)
        _asset_icon(gpu, batch_for_shader, "folder", x+81*s, y+17*s, 20*s)
        _centered_glyph(blf, "✓" if directory_ok else "×",
                        x+114*s, y+46*s, round(12*s), _TEXT)
        if quality is not None and getattr(quality, "live", None) is not None:
            # AETHER: the preset's icon only; the menu names the presets
            _asset_icon(gpu, batch_for_shader, f"quality_{quality.identifier.lower()}",
                        x+(126+11)*s, y+15*s, 24*s)
        else:
            _centered_label(blf, (quality.label if quality else "Custom") + " ▾",
                            x+126*s, y+23*s, quality_width*s, round(13*s), _TEXT)
        aether_live = bool(quality is not None and getattr(quality, "live", None) is not None)
        if snapshot.active:
            _centered_label(
                blf, "CANCEL", x+bake_x*s, y+23*s-1.5*(s/_LAYOUT_SCALE),
                82*s, round(14*s), _TEXT if snapshot.can_cancel else _MUTED)
        elif aether_live and _aether_live_running():
            # stop: a rounded white square
            _rounded(shader, batch_for_shader, x+(bake_x+33)*s, y+19*s, 16*s, 16*s, 3*s, _TEXT)
        elif aether_live and quality.live:
            _asset_icon(gpu, batch_for_shader, "play", x+(bake_x+29)*s, y+15*s, 24*s)
        else:
            # Icon only: croissant = This Computer, cloud = Cloud (as the panel).
            cloud = physics_ui.bake_location(context) == "CLOUD"
            _asset_icon(gpu, batch_for_shader, "cloud" if cloud else "bake",
                        x+(bake_x+29)*s, y+15*s, 24*s)
        if resume_ready and resume_fraction >= 0.55:
            alpha = min(1.0, (resume_fraction - 0.55) / 0.45)
            resume_text = (*_TEXT[:3], alpha)
            _centered_glyph(
                blf, "◷",
                x+(bake_x+82+_RESUME_EXTENSION/2)*s, y+27*s,
                            round(17*s), resume_text)
        mode_pull = _pull_sessions.get(quick_assign.region_key(context))
        if getattr(mode_pull, "kind", "") == "mode" and mode_pull.open:
            rects = _mode_option_rects(bounds, quality_width)
            # the options sit on their own toolbar-coloured backing, like the bar they come out of
            _rounded(shader, batch_for_shader, rects[0][1] - 6*s, y, rects[-1][1] + rects[-1][2] - rects[0][1] + 12*s,
                     h, 25*s, _BG)
            for key, ox, ow in rects:
                current = key == mode_pull.current
                hovered = key == mode_pull.hovered
                color = _CYAN if hovered else (_BLUE if current else _SURFACE)
                _rounded(shader, batch_for_shader, ox, bake_y, ow, bake_height, 17*s, color)
                icon = "play" if key == "LIVE" else ("cloud" if physics_ui.bake_location(context) == "CLOUD"
                                                     else "bake")
                _asset_icon(gpu, batch_for_shader, icon, ox + ow/2 - 12*s, y+15*s, 24*s)
        quick_assign.draw(context, blf, gpu, batch_for_shader, shader)
    finally:
        gpu.state.blend_set("NONE")


def _cancel_pulls():
    for operator in tuple(_pull_sessions.values()):
        operator.finish()


class CLOTHNEXT_OT_pull_detach(bpy.types.Operator):
    bl_idname = "clothnext.pull_detach"
    bl_label = "Remove Cloth NeXt Physics"
    bl_description = "Hold and pull left to remove Cloth NeXt Physics. Baked playback is preserved."
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    @classmethod
    def poll(cls, context):
        return (getattr(context.area, "type", None) == "VIEW_3D"
                and getattr(context.region, "type", None) == "WINDOW"
                and visible(context) and not shared_controller.snapshot().active)

    def invoke(self, context, event):
        bounds = _animated_bounds(context)
        if (event.type != "LEFTMOUSE" or event.value != "PRESS"
                or not self.poll(context) or _animation_start_time is not None
                or not logo_hit(bounds, event.mouse_region_x, event.mouse_region_y)):
            return {"CANCELLED"}
        targets = tuple(obj for obj in context.selected_objects
                        if getattr(getattr(obj, "cloth_next", None), "enabled", False))
        if not physics_operators.removal_targets_valid(targets):
            return {"CANCELLED"}
        self.key = quick_assign.region_key(context)
        if self.key in _pull_sessions:
            return {"CANCELLED"}
        self.window, self.area, self.region = context.window, context.area, context.region
        self.screen, self.workspace = self.window.screen, self.window.workspace
        self.scene, self.view_layer = context.scene, context.view_layer
        self.wm = context.window_manager
        self.bounds = bounds
        self.targets = targets
        self.kind = "detach"
        self.gesture = PullGesture(event.mouse_region_x, 160*bounds[4])
        self.timer = None
        _pull_sessions[self.key] = self
        try:
            self.wm.modal_handler_add(self)
        except Exception:
            self.finish()
            raise
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def valid_context(self, context):
        try:
            return (_registered and visible(context) and _animation_start_time is None
                    and context.window == self.window and self.window in tuple(self.wm.windows)
                    and self.window.screen == self.screen and self.window.workspace == self.workspace
                    and self.area in tuple(self.screen.areas) and self.region in tuple(self.area.regions)
                    and context.area == self.area and context.region == self.region
                    and context.scene == self.scene and context.view_layer == self.view_layer
                    and _animated_bounds(context) == self.bounds
                    and all(any(obj is candidate for candidate in self.scene.objects)
                            for obj in self.targets)
                    and physics_operators.removal_targets_valid(self.targets))
        except (ReferenceError, AttributeError):
            return False

    def modal(self, context, event):
        if _pull_sessions.get(getattr(self, "key", None)) is not self:
            return {"CANCELLED"}
        if (not self.valid_context(context) or event.type == "WINDOW_DEACTIVATE"
                or (event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS")):
            self.finish()
            return {"CANCELLED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "LEFTMOUSE"}:
            self.gesture.update(event.mouse_x - self.region.x)
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            armed = self.gesture.release(event.mouse_x - self.region.x)
            targets = self.targets
            self.finish()
            if armed and physics_operators.remove_physics_targets(context.scene, targets):
                return {"FINISHED"}
            return {"CANCELLED"}
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def finish(self):
        if _pull_sessions.get(getattr(self, "key", None)) is self:
            del _pull_sessions[self.key]
        self.targets = ()
        if hasattr(self, "gesture"):
            self.gesture.cancel()
        try:
            self.area.tag_redraw()
        except (ReferenceError, AttributeError):
            pass

    def cancel(self, context):
        self.finish()


class CLOTHNEXT_OT_pull_resume(bpy.types.Operator):
    bl_idname = "clothnext.pull_resume"
    bl_label = "Resume Bake"
    bl_description = "Hold the clock and pull right to resume the latest verified Bake"
    bl_options = {"REGISTER", "BLOCKING"}

    @classmethod
    def poll(cls, context):
        return (getattr(context.area, "type", None) == "VIEW_3D"
                and getattr(context.region, "type", None) == "WINDOW"
                and visible(context) and _resume_available(context))

    def invoke(self, context, event):
        bounds = _animated_bounds(context)
        quality_width = _quality_width(context)
        if (event.type != "LEFTMOUSE" or event.value != "PRESS"
                or not self.poll(context) or _animation_start_time is not None
                or not _resume_hit(bounds, event.mouse_region_x,
                                   event.mouse_region_y, quality_width)):
            return {"CANCELLED"}
        self.key = quick_assign.region_key(context)
        if self.key in _pull_sessions:
            return {"CANCELLED"}
        self.window, self.area, self.region = context.window, context.area, context.region
        self.screen, self.workspace = self.window.screen, self.window.workspace
        self.scene, self.view_layer = context.scene, context.view_layer
        self.wm = context.window_manager
        self.bounds = bounds
        self.kind = "resume"
        self.targets = ()
        self.gesture = PullGesture(event.mouse_region_x, -160*bounds[4])
        _pull_sessions[self.key] = self
        try:
            self.wm.modal_handler_add(self)
        except Exception:
            self.finish()
            raise
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def valid_context(self, context):
        try:
            return (_registered and visible(context) and _animation_start_time is None
                    and context.window == self.window and self.window in tuple(self.wm.windows)
                    and self.window.screen == self.screen and self.window.workspace == self.workspace
                    and self.area in tuple(self.screen.areas) and self.region in tuple(self.area.regions)
                    and context.area == self.area and context.region == self.region
                    and context.scene == self.scene and context.view_layer == self.view_layer
                    and _animated_bounds(context) == self.bounds
                    and _resume_available(context))
        except (ReferenceError, AttributeError):
            return False

    def modal(self, context, event):
        if _pull_sessions.get(getattr(self, "key", None)) is not self:
            return {"CANCELLED"}
        if (not self.valid_context(context) or event.type == "WINDOW_DEACTIVATE"
                or (event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS")):
            self.finish()
            return {"CANCELLED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "LEFTMOUSE"}:
            self.gesture.update(event.mouse_x - self.region.x)
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            armed = self.gesture.release(event.mouse_x - self.region.x)
            self.finish()
            if armed and _resume_available(context):
                result = bpy.ops.clothnext.recovery_resume_latest("EXEC_DEFAULT")
                return {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
            return {"CANCELLED"}
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def finish(self):
        if _pull_sessions.get(getattr(self, "key", None)) is self:
            del _pull_sessions[self.key]
        if hasattr(self, "gesture"):
            self.gesture.cancel()
        try:
            self.area.tag_redraw()
        except (ReferenceError, AttributeError):
            pass

    def cancel(self, context):
        self.finish()


class CLOTHNEXT_OT_aether_run_button(bpy.types.Operator):
    """The New Look toolbar's main button with the AETHER Engine."""
    bl_idname = "clothnext.aether_run_button"
    bl_label = "Live / Bake"
    bl_description = ("Click: start the Live Simulation or bake, as shown (STOP ends a running Live Simulation "
                      "and keeps the drape). Hold and pull right to switch between Live and Bake")
    bl_options = {"REGISTER", "BLOCKING"}

    @classmethod
    def poll(cls, context):
        return (getattr(context.area, "type", None) == "VIEW_3D"
                and getattr(context.region, "type", None) == "WINDOW"
                and visible(context) and _aether_quality(context.scene) is not None)

    def invoke(self, context, event):
        if event.type != "LEFTMOUSE" or event.value != "PRESS" or not self.poll(context):
            return {"CANCELLED"}
        if shared_controller.snapshot().active:
            return {"CANCELLED"}
        if _aether_live_running():
            from . import aether_engine_live
            aether_engine_live.stop(keep=True)
            _tag_redraw(context)
            return {"FINISHED"}
        self.key = quick_assign.region_key(context)
        if self.key in _pull_sessions:
            return {"CANCELLED"}
        self.window, self.area, self.region = context.window, context.area, context.region
        self.wm = context.window_manager
        self.bounds = _animated_bounds(context)
        if self.bounds is None:
            return {"CANCELLED"}
        self.kind = "mode"
        self.start_x = event.mouse_region_x
        self.open = False
        self.hovered = None
        self.current = str(context.scene.cloth_next_solver.aether_run_mode)
        self.targets = ()
        _pull_sessions[self.key] = self
        try:
            self.wm.modal_handler_add(self)
        except Exception:
            self.finish()
            raise
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def valid_context(self, context):
        try:
            return (_registered and visible(context) and context.window == self.window
                    and context.area == self.area and context.region == self.region)
        except (ReferenceError, AttributeError):
            return False

    def _hover(self, x):
        for key, ox, ow in _mode_option_rects(self.bounds, _quality_width(bpy.context)):
            if ox <= x <= ox + ow:
                return key
        return None

    def modal(self, context, event):
        if _pull_sessions.get(getattr(self, "key", None)) is not self:
            return {"CANCELLED"}
        if (event.type == "WINDOW_DEACTIVATE"
                or (event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS")):
            self.finish()
            return {"CANCELLED"}
        x = event.mouse_x - self.region.x
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if not self.open and x - self.start_x > _MODE_OPEN_PULL * self.bounds[4]:
                self.open = True
            if self.open:
                self.hovered = self._hover(x)
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            opened, chosen = self.open, self._hover(x) if self.open else None
            self.finish()
            settings = context.scene.cloth_next_solver
            if opened:   # a pull only switches the mode
                if chosen is not None and chosen != str(settings.aether_run_mode):
                    settings.aether_run_mode = chosen
                _tag_redraw(context)
                return {"FINISHED"} if chosen else {"CANCELLED"}
            if str(settings.aether_run_mode) == "LIVE":
                result = bpy.ops.clothnext.aether_live_start("EXEC_DEFAULT")
            else:
                result = bpy.ops.clothnext.bake("INVOKE_DEFAULT")
            _tag_redraw(context)
            return {"FINISHED"} if "FINISHED" in result or "RUNNING_MODAL" in result else {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def finish(self):
        if _pull_sessions.get(getattr(self, "key", None)) is self:
            del _pull_sessions[self.key]
        try:
            self.area.tag_redraw()
        except (ReferenceError, AttributeError):
            pass

    def cancel(self, context):
        self.finish()


def _draw_pull(context, bounds, blf, shader, batch):
    operator = _pull_sessions.get(quick_assign.region_key(context))
    if operator is None or getattr(operator, "kind", "") == "mode":
        return
    x, y, _, h, s = bounds
    gesture = operator.gesture
    armed = gesture.state == "ARMED"
    if getattr(operator, "kind", "detach") == "resume":
        extension = (38 + _RESUME_PULL_EXTENSION*gesture.progress)*s
        right = x + bounds[2] + extension
        color = (0.02, .62, .82, 1.0) if armed else (0.02, .42, .62, .96)
        _rounded(shader, batch, x+bounds[2]-27*s, y+10*s,
                 extension+27*s, h-20*s, 17*s, color)
        _centered_glyph(blf, "◷", right-17*s, y+h/2,
                        round(18*s), _TEXT)
        if armed:
            frame = _resume_frame(context)
            text = (f"Let go to resume from frame {frame}"
                    if frame is not None else "Let go to resume")
            size = round(12*s)
            text = _fit_label(blf, text, max(0., extension-42*s), size)
            blf.size(0, size)
            width, _ = blf.dimensions(0, text)
            _label(blf, text, right-35*s-width, y+23*s,
                   size, _TEXT)
        return
    extension = (38 + 160*gesture.progress)*s
    left = x-extension
    color = (1.0, .12, .15, 1.0) if armed else (.80, .06, .09, .96)
    _pull_fade(batch, left, y+10*s, extension+27*s, h-20*s, 17*s, color)
    # White silhouette matching the supplied trash SVG, painted beneath the pill.
    ix, iy = left+14*s, y+18*s
    _rounded(shader, batch, ix, iy, 12*s, 15*s, 2*s, _TEXT)
    _rounded(shader, batch, ix-2*s, iy+17*s, 16*s, 2*s, s, _TEXT)
    _rounded(shader, batch, ix+4*s, iy+20*s, 4*s, 2*s, s, _TEXT)
    if armed:
        text = "Release to detach" if len(operator.targets) == 1 else f"Release to detach {len(operator.targets)} objects"
        size = round(13*s)
        text = _fit_label(blf, text, max(0., extension-42*s), size)
        _label(blf, text, left+35*s, y+23*s, size, _TEXT)


def _draw_aether_menu(layout, context) -> None:
    """New Look toolbar menu with the AETHER Engine selected: the preset of the current mode (Live or Bake)."""
    from . import aether_engine_live
    settings = context.scene.cloth_next_solver
    live = str(settings.aether_run_mode) == "LIVE"
    prop = "aether_live_quality" if live else "aether_bake_quality"
    locked = shared_controller.snapshot().active or (live and aether_engine_live.is_running())
    from . import icon_registry
    current = str(getattr(settings, prop))
    for key, label in (("NORMAL", "Normal"), ("ANIMATION", "Animation"), ("FITTING", "Fitting")):
        row = layout.row()
        row.enabled = not locked
        op = row.operator("wm.context_set_enum", text=label, depress=key == current,
                          **icon_registry.icon_kwargs(f"quality_{key.lower()}", "NONE"))
        op.data_path = f"scene.cloth_next_solver.{prop}"
        op.value = key


class CLOTHNEXT_MT_floating_quality(bpy.types.Menu):
    bl_idname = "CLOTHNEXT_MT_floating_quality"
    bl_label = "Quality"

    def draw(self, context):
        if _aether_quality(context.scene) is not None:
            _draw_aether_menu(self.layout, context)
            return
        pdrd = physics_operators.scene_has_pdrd(context.scene)
        ids = (physics_operators.PDRD_QUALITY_PRESET_OPERATOR_IDS if pdrd
               else physics_operators.QUALITY_PRESET_OPERATOR_IDS)
        for key in ("LOW", "MEDIUM", "HIGH", "EXTREME"):
            row = self.layout.row()
            row.enabled = key in ids and not shared_controller.snapshot().active
            if key in ids:
                row.operator(ids[key], text=key.title())


class CLOTHNEXT_OT_toggle_floating_ui(bpy.types.Operator):
    bl_idname = "clothnext.toggle_floating_ui"
    bl_label = "Show/Hide Cloth NeXt Toolbar"
    bl_description = "Temporarily show or hide the New Look viewport toolbar"

    def execute(self, context):
        global _toolbar_visible, _animation_from, _animation_start_time
        if not enabled(context):
            return {"CANCELLED"}
        _animation_from = _slide_fraction()
        _toolbar_visible = not _toolbar_visible
        quick_assign.cancel_all()
        _cancel_pulls()
        _animation_start_time = time.monotonic()
        if not bpy.app.timers.is_registered(_animation_tick):
            bpy.app.timers.register(_animation_tick, first_interval=1.0 / 60.0)
        _tag_redraw(context)
        return {"FINISHED"}


class CLOTHNEXT_GT_pill_button(bpy.types.Gizmo):
    """A click target exactly the size of a painted toolbar pill (the built-in 2D button is a small circle)."""
    bl_idname = "CLOTHNEXT_GT_pill_button"
    __slots__ = ("half_w", "half_h", "radius", "glow")

    def setup(self):
        self.half_w = self.half_h = self.radius = 10.0
        self.glow = True

    def _rect(self):
        t = self.matrix_basis.translation
        return t.x - self.half_w, t.y - self.half_h, 2 * self.half_w, 2 * self.half_h

    def test_select(self, context, location):
        x, y, w, h = self._rect()
        return 0 if x <= location[0] <= x + w and y <= location[1] <= y + h else -1

    def draw(self, context):
        if not (self.is_highlight and self.glow):
            return
        import gpu
        from gpu_extras.batch import batch_for_shader
        x, y, w, h = self._rect()
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        gpu.state.blend_set("ALPHA")
        _rounded(shader, batch_for_shader, x, y, w, h, min(self.radius, h / 2, w / 2), (*_CYAN[:3], 0.22))
        gpu.state.blend_set("NONE")


class CLOTHNEXT_GT_floating_simulation(bpy.types.GizmoGroup):
    bl_idname = "CLOTHNEXT_GT_floating_simulation"
    bl_label = "Cloth NeXt New Look"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"PERSISTENT", "SCALE"}

    @classmethod
    def poll(cls, context):
        return visible(context) and _bounds(context) is not None

    def setup(self, context):
        self._buttons = []
        for operator in ("clothnext.set_cache_directory", "wm.call_menu",
                         "clothnext.bake", "clothnext.bake_cancel",
                         "clothnext.companion_open_logs", "clothnext.quick_assign",
                         "clothnext.pull_detach", "clothnext.pull_resume", "clothnext.aether_run_button"):
            gizmo = self.gizmos.new(CLOTHNEXT_GT_pill_button.bl_idname)
            props = gizmo.target_set_operator(operator)
            if operator == "wm.call_menu":
                props.name = CLOTHNEXT_MT_floating_quality.bl_idname
            self._buttons.append(gizmo)
        self.refresh(context)

    def refresh(self, context):
        from mathutils import Matrix
        if not visible(context):
            for gizmo in self._buttons:
                gizmo.hide = True
            return
        bounds = _animated_bounds(context)
        if bounds is None:
            return
        x, y, _w, _h, s = bounds
        quality_width = _quality_width(context)
        model, snapshot, quality, _directory_ok, message = _state(context)
        ui = s / _LAYOUT_SCALE
        resume_fraction = _resume_fraction(context)
        resume_center = (218 + quality_width
                         + (_RESUME_EXTENSION * resume_fraction) / 2)
        positions = ((91, 27), (126 + quality_width/2, 27),
                     (177 + quality_width, 27),
                     (177 + quality_width, 27),
                     ((_w+18*ui)/s, 27),
                     (_w/(2*s), 54 + 31*ui/s), (27, 27),
                     (resume_center, 27), (177 + quality_width, 27))
        # half extents (layout units) of each painted shape: folder, quality, bake, cancel, logs,
        # quick assign, logo, resume, AETHER main button
        bake_h = (_h - 16*s) / (2*s)
        halves = ((23, bake_h), (quality_width/2, bake_h), (41, bake_h), (41, bake_h), (12, 12),
                  (16*ui/s, 16*ui/s), (27, 27), (_RESUME_EXTENSION*resume_fraction/2 + 1, bake_h - 2),
                  (41, bake_h))
        for gizmo, (dx, dy), (hw, hh) in zip(self._buttons, positions, halves):
            gizmo.matrix_basis = Matrix.Translation((x+dx*s, y+dy*s, 0))
            gizmo.half_w, gizmo.half_h = hw*s, hh*s
            gizmo.radius = 17*s
            gizmo.scale_basis = max(gizmo.half_w, gizmo.half_h)
        self._buttons[6].hide = snapshot.active
        self._buttons[6].glow = False
        self._buttons[0].hide = snapshot.active
        self._buttons[1].hide = snapshot.active
        aether = quality is not None and getattr(quality, "live", None) is not None
        self._buttons[2].hide = snapshot.active or not (model and model.enabled) or aether
        self._buttons[8].hide = snapshot.active or not aether
        self._buttons[3].hide = not snapshot.active or not snapshot.can_cancel
        self._buttons[4].hide = True
        self._buttons[5].hide = not bool(quick_assign.valid_roles(context))
        self._buttons[7].hide = (not _resume_available(context)
                                 or resume_fraction < 0.55)
        self._buttons[7].glow = False
        # Blender does not guarantee refresh() for each timer-driven redraw.
        # Keep hit targets at the same translated position as the painted bar.
        for gizmo in self._buttons:
            if gizmo.matrix_basis.translation.y + gizmo.half_h < 0:
                gizmo.hide = True

    def draw_prepare(self, context):
        self.refresh(context)


CLASSES = quick_assign.CLASSES + (CLOTHNEXT_OT_pull_detach, CLOTHNEXT_OT_pull_resume, CLOTHNEXT_OT_aether_run_button,
           CLOTHNEXT_MT_floating_quality, CLOTHNEXT_OT_toggle_floating_ui, CLOTHNEXT_GT_pill_button,
           CLOTHNEXT_GT_floating_simulation)


def _tag_redraw(context):
    wm = getattr(context, "window_manager", None)
    for window in getattr(wm, "windows", ()):
        for area in getattr(window.screen, "areas", ()):
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _pulse():
    quick_assign.prune_sessions()
    for operator in tuple(_pull_sessions.values()):
        try:
            with bpy.context.temp_override(window=operator.window, area=operator.area, region=operator.region):
                alive = operator.valid_context(bpy.context)
        except (ReferenceError, RuntimeError, AttributeError):
            alive = False
        if not alive:
            operator.finish()
    if enabled(bpy.context):
        _tag_redraw(bpy.context)
    return 0.5


def sync(context=None):
    global _handle, _toolbar_visible, _last_enabled, _slide
    if not _registered:
        return
    context = context or bpy.context
    active = enabled(context)
    if active and not _last_enabled:
        _stop_animation()
        _toolbar_visible = True
        _slide = 1.0
    elif not active:
        _stop_animation()
        quick_assign.cancel_all()
        _cancel_pulls()
    _last_enabled = active
    if active and _handle is None:
        _handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw, (), "WINDOW", "POST_PIXEL")
        if not bpy.app.timers.is_registered(_pulse):
            bpy.app.timers.register(_pulse, first_interval=0.5)
    elif not active and _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, "WINDOW")
        _handle = None
        if bpy.app.timers.is_registered(_pulse):
            bpy.app.timers.unregister(_pulse)
    _tag_redraw(context)


def register():
    global _registered, _keymap, _keymap_item
    _registered = True
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_post", None)
    if handlers is not None and _scene_loaded not in handlers:
        handlers.append(_scene_loaded)
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_pre", None)
    if handlers is not None and _scene_loading not in handlers:
        handlers.append(_scene_loading)
    kc = getattr(getattr(bpy.context.window_manager, "keyconfigs", None),
                 "addon", None)
    if kc is not None and _keymap_item is None:
        _keymap = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        _keymap_item = _keymap.keymap_items.new(
            CLOTHNEXT_OT_toggle_floating_ui.bl_idname, "F6", "PRESS")
    sync()


def unregister():
    global _registered, _handle, _keymap, _keymap_item, _last_enabled
    _registered = False
    quick_assign.cancel_all()
    _cancel_pulls()
    _stop_animation()
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_post", None)
    if handlers is not None and _scene_loaded in handlers:
        handlers.remove(_scene_loaded)
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_pre", None)
    if handlers is not None and _scene_loading in handlers:
        handlers.remove(_scene_loading)
    if _keymap is not None and _keymap_item is not None:
        _keymap.keymap_items.remove(_keymap_item)
    _keymap = _keymap_item = None
    _last_enabled = False
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, "WINDOW")
        _handle = None
    if bpy.app.timers.is_registered(_pulse):
        bpy.app.timers.unregister(_pulse)
    for image in _images.values():
        try:
            if image.name in bpy.data.images:
                bpy.data.images.remove(image)
        except ReferenceError:
            pass
    _images.clear()
    _tag_redraw(bpy.context)
